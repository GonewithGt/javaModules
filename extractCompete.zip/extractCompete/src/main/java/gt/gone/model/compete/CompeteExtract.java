package gt.gone.model.compete;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Set;

import gt.gone.model.compete.barriers.ExtraBarriers;
import gt.gone.model.compete.brand.ExtraBrand;
import gt.gone.model.compete.marketshare.MarketShare;
import gt.gone.model.compete.patent.ExtraPatent;
import gt.gone.model.compete.team.ExtractTeam;
import gt.gone.util.FileUtil;
import gt.gone.util.JsonTool;
import gt.gone.util.MongoDBUtil;
import gt.gone.util.PreProcess;
import gt.gone.util.PropertyUtil;
import gt.gone.util.WordTree;
import gt.gone.util.WordTreeCase;
import gt.gone.util.XmlUtil;
import net.sf.json.JSONObject;

public class CompeteExtract {

	public static final String HAVE = "have";
	public static final String NOTHAVE = "not_have";
	// 市场份额：定性与定量
	// 4种团队类型
	public static WordTree teamResearchTypeWordTree = WordTreeCase.getTeamResearchTypeWordTree();
	public static WordTree teamManageTypeWordTree = WordTreeCase.getTeamManageTypeWordTree();
	public static WordTree teamSaleTypeWordTree = WordTreeCase.getTeamSaleTypeWordTree();
	public static WordTree teamOtherTypeWordTree = WordTreeCase.getTeamOtherTypeWordTree();
	// 4种团队优势（有经验的使用正则匹配）
	public static WordTree experienceWordTree = WordTreeCase.getExperienceWordTree();
	public static WordTree capableWordTree = WordTreeCase.getCapableWordTree();
	public static WordTree scaleWordTree = WordTreeCase.getScaleWordTree();
	public static WordTree qualityWordTree = WordTreeCase.getQualityWordTree();

	// 门槛barriers（障碍、门槛、壁垒）返回是与否
	public static WordTree barriersWordTree = WordTreeCase.getBarriersWordTree();
	// 专利
	public static WordTree patentWordTree = WordTreeCase.getPatentWordTree();
	// 品牌
	public static WordTree brandWordTree = WordTreeCase.getBrandWordTree();
	public static XmlUtil xml = new XmlUtil("compete", "marketshare", "marketshare.xml");

	public String extractCompete(String input) throws Exception {
		return extractCompete(input, xml);
	}

	public String extractCompete(String input, XmlUtil marketXml) throws Exception {

		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		MarketShare marketShare = new MarketShare(input, marketXml);
		result.put("inputSentence", input);
		result.put("marketShare", marketShare.getResultMap());

		if (input.toLowerCase().contains("team")) {
			String[] teams = input.split("\\.");
			ArrayList teamList = new ArrayList<Object>();
			for (String team : teams) {
				if (team.toLowerCase().contains("team"))
					teamList.add(
							ExtractTeam.extractTeam(PreProcess.competeTeamPreProcess(team), teamResearchTypeWordTree,
									teamManageTypeWordTree, teamSaleTypeWordTree, teamOtherTypeWordTree,
									experienceWordTree, capableWordTree, scaleWordTree, qualityWordTree));
			}

			result.put("team", teamList);
		}

		else
			result.put("team", new HashMap());

		if (ExtraPatent.extractPatent(input, patentWordTree) == null)
			result.put("patent", NOTHAVE);
		else
			result.put("patent", HAVE);

		if (ExtraBrand.extractbrand(input, brandWordTree) == null)
			result.put("brand", NOTHAVE);
		else{
			result.put("brand", HAVE);
				//当句子中出现了brand,处理brand与retail，customer一起出现的情况
//				String[] inputArray = input.split("\\.");
//				int hasBrand = 0;
//				for(String aString : inputArray){
//					//customer得去掉，sale也得去掉，retail得加强限制
//					if(aString.toLowerCase().contains("brand") && !aString.toLowerCase().contains("retail"))
//						hasBrand++;
//				}
//				if(hasBrand >0){
//					result.put("brand", HAVE);
//				}else{
//					result.put("brand", NOTHAVE);
//				}
				
			
		}
			

		if (ExtraBarriers.extractBarriers(input, barriersWordTree) == null)
			result.put("barriers", NOTHAVE);
		else
			result.put("barriers", HAVE);

		return JSONObject.fromObject(result).toString();
	}

	public static void main(String[] args) throws Exception {

		PrintStream ps;

		ps = new PrintStream(new FileOutputStream(PropertyUtil.getValue("compete.output80M")));

		System.setOut(ps);

		String fileTest2 = PropertyUtil.getValue("compete.input80M");

		CompeteExtract conpeteExtract = new CompeteExtract();

		ArrayList<String> input = FileUtil.importData(fileTest2);

		int i = 1;
		for (String string : input) {

			ps.println(i++);
			String ans = conpeteExtract.extractCompete(string);

			ps.println(JsonTool.formatJson(ans, "\t"));
			ps.println();
			ps.println();
//			if (i == 10) {
//				break;
//			}
		}
	}
}
