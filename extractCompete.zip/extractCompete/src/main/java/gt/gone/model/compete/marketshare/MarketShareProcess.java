package gt.gone.model.compete.marketshare;

import gt.gone.util.PercentUtil;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

public class MarketShareProcess {
	
	public LinkedHashMap<String, Object> commonProcess(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		String[] tokens = matchedString.split("\\s");
		ArrayList<String> marketShareQuality = new ArrayList<String>(); //定性
		ArrayList<String> marketShareQuatity = new ArrayList<String>(); //定量
		for(String token : tokens){
			token = token.trim();
			if(token.contains("定性")){
				
				marketShareQuality.add((String) keyToInfo.get(token));
	
			}else if(token.contains("定量")){
				
				marketShareQuatity.add((String) keyToInfo.get(token.trim()));
				
			}
		}
		result.put("marketShareQuality", marketShareQuality);
		result.put("marketShareQuantity", PercentUtil.percentToFloatStr(marketShareQuatity));
		return result;
	}
	
	public Map<String, Object> rule1(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		result = commonProcess(matchedString, keyToInfo);
		return result;
	}
	
	public Map<String, Object> rule2(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		result = commonProcess(matchedString, keyToInfo);
		return result;
	}
	
	public Map<String, Object> rule3(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		result = commonProcess(matchedString, keyToInfo);
		return result;
	}

}
