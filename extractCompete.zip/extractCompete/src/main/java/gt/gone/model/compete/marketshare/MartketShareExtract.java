package gt.gone.model.compete.marketshare;

import gt.gone.util.FileUtil;
import gt.gone.util.JsonTool;
import gt.gone.util.PropertyUtil;
import gt.gone.util.XmlUtil;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;

import org.apache.commons.io.ByteOrderMark;
import org.apache.commons.io.input.BOMInputStream;

import net.sf.json.JSONObject;

public class MartketShareExtract {
	
	public  String extractMarketShare(String input){
		MarketShare ms = new MarketShare(input);
		String resultStr ="";
		//resultStr = JSONObject.fromObject(sentence.getEntityNameToEntityMap()).toString();
		resultStr = JSONObject.fromObject(ms.getResultMap()).toString();
		//System.out.println(JsonTool.formatJson(sentence.getKeyToInfoMap().toString(), " "));
		return resultStr;
	}
	
	public  String extractMarketShare(String input, XmlUtil xml){
		MarketShare ms = new MarketShare(input, xml);
		String resultStr ="";
		//resultStr = JSONObject.fromObject(sentence.getEntityNameToEntityMap()).toString();
		resultStr = JSONObject.fromObject(ms.getResultMap()).toString();
		//System.out.println(JsonTool.formatJson(sentence.getKeyToInfoMap().toString(), " "));
		return resultStr;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//String fileTest2 = "D:\\java\\cashFlow\\extractCashFlow3\\src\\main\\resources\\test2.txt";
		//String input = FileUtil.importData(fileTest2, 1);
		
		MartketShareExtract pe = new MartketShareExtract();
		 XmlUtil xml = new XmlUtil("compete","marketshare","marketshare.xml");
		 PrintStream ps;
			try {
				//ps = new PrintStream(new FileOutputStream("C:\\extractMarketShareJson.txt"));
				ps = new PrintStream(new FileOutputStream(PropertyUtil.getValue("compete.marketshare.output")));
				System.setOut(ps);  
				
				//String fileTestMarketShare = "C:\\Users\\nlp\\workspace\\extractCashFlow3\\src\\main\\resources\\testMarketShare.txt";
				String fileTestMarketShare = PropertyUtil.getValue("compete.marketshare.input");
				//System.out.println("abc");
				String line = null;
				  //  int n = 3;//从第三行开始读取
				    try {
				    	//FileInputStream fileInputStream  = new FileInputStream(filePath);
				    	//InputStreamReader isr = new InputStreamReader(fileInputStream, "UTF-8");
				    	// ClassLoader classLoader = XmlUtil.class.getClassLoader();
				    	// FileInputStream fis = (FileInputStream) classLoader.getResourceAsStream(filePath); 
				    	 
				    	FileInputStream fis = new FileInputStream(fileTestMarketShare);
			        	   //可检测多种类型，并剔除bom
			        	BOMInputStream bomIn = new BOMInputStream(fis, false,ByteOrderMark.UTF_8, ByteOrderMark.UTF_16LE, ByteOrderMark.UTF_16BE);
			        	String charset = "utf-8";
			        	   //若检测到bom，则使用bom对应的编码
			        	if(bomIn.hasBOM()){
			        		charset = bomIn.getBOMCharsetName();
			        	 }
			        	BufferedReader br = new BufferedReader(new InputStreamReader(bomIn, charset));
						//br = new BufferedReader(new InputStreamReader(new FileInputStream(filePath), "UTF-8"));
						
						 while ((line = br.readLine()) != null) {
							 String ans = pe.extractMarketShare(line,xml);
								//JsonFormatTool jst = new JsonFormatTool();
								System.out.println(JsonTool.formatJson(ans, "\t"));
								System.out.println();
								System.out.println();
							}
						 br.close();
						 
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
				/*for(int i = 1 ; i < 460 ; i++){
					
					String input = FileUtil.importData(fileTestMarketShare, i);	
					if(input!=null){
						MartketShareExtract pe = new MartketShareExtract();
						String ans = pe.extractMarketShare(input);
						//JsonFormatTool jst = new JsonFormatTool();
						System.out.println(JsonTool.formatJson(ans, "\t"));
						System.out.println();
						System.out.println();
					}
					
				}*/
		
			/*	String input = FileUtil.importData(fileTestProduct, 1);
				ProductExtract pe = new ProductExtract();
				String ans = pe.extractProduct(input);
				JsonFormatTool jst = new JsonFormatTool();
				System.out.println(JsonTool.formatJson(ans, " "));*/
				
			
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 

	}
	

}
