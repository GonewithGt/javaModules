package gt.gone.model.compete.team;

import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;

import gt.gone.util.FileUtil;
import gt.gone.util.JsonTool;
import gt.gone.util.MongoDBUtil;
import gt.gone.util.PreProcess;
import gt.gone.util.PropertyUtil;
import gt.gone.util.TeamAddAdjectiveUtil;
import gt.gone.util.WordTree;
import gt.gone.util.WordTreeCase;
import net.sf.json.JSONObject;

public class ExtractTeam {

	public static HashMap<String, Object> extractTeam(String input, WordTree teamResearchTypeWordTree,
			WordTree teamManageTypeWordTree, WordTree teamSaleTypeWordTree, WordTree teamOtherTypeWordTree,
			WordTree experienceWordTree, WordTree capableWordTree, WordTree scaleWordTree, WordTree qualityWordTree) {
		LinkedHashMap<String, Object> resultMap = new LinkedHashMap<String, Object>();
		Map<String, Object> teamTypeMap = new HashMap<String, Object>();
		List teamResearchList = new LinkedList<String>();
		Set teamResearchSet = new HashSet<>();
		List teamManageList = new LinkedList<String>();
		Set teamManageSet = new HashSet<>();
		List teamSaleList = new LinkedList<String>();
		Set teamSaleSet = new HashSet<>();
		List teamOtherList = new LinkedList<String>();
		Set teamOtherSet = new HashSet<>();

		Map<String, Object> teamAdvantageMap = new HashMap<String, Object>();
		List experienceAdvantageList = new LinkedList<String>();
		Set experienceAdvantageSet = new HashSet<>();
		List capableAdvantageList = new LinkedList<String>();
		Set capableAdvantageSet = new HashSet<>();
		List scaleAdvantageList = new LinkedList<String>();
		Set scaleAdvantageSet = new HashSet<>();
		List qualityAdvantageList = new LinkedList<String>();
		Set qualityAdvantageSet = new HashSet<>();

		//todo 1：-的处理，well-trained之类的 2：结果的格式的处理，没有数据的不显示
		// 用几个规则抽取8个子类，然后进行分类判断

		// 形容词
		//String ajectiveWords = "(" + "busy|well|significant|rich industry|rich|highly|Fully|Highly|fully" + ")?";
		String ajectiveWords = "(" + "combined|necessary|automotive|collective|busy|well|Very|very|self|smoothly|extremely|very highly|rich|significant|rich industry|highly|Fully|Highly|fully|high|profound|extensive|famous|more" + ")?";
		
		// 团队优势词
		// 有经验
		String teamExperienceAdvantageWords = "established|professional|seasoned|specialised|Senior|senior|experienced|Experienced|experience";
		// 有能力
		/* "Professional", */
		//todo:目前大小写没有统一
		//String teamCapableAdvantageWords = "supportive|specialized|skills|talented|certified|Award Winning|qualified|efficient|Outstanding|superb|skilled consultants|scientists|qualifications|qualification|skilled|technical elites|expertise|Strong|trained|capable|Strong knowledgeable|knowledgeable|strong|excellent|mature|superb|Talented|competent|technology-leading|highly skilled|skilled|profound knowledge|knowledge|extensive expertise";
		String teamCapableAdvantageWords = "growing|knowhow|specialized|specialised|supportive|konwledgeable|great|good|ambitious|certified|Award Winning|qualified|efficient|Outstanding|superb|qualifications|qualification|skilled|technical|expertise|Strong|trained|capable|knowledgeable|strong|excellent|mature|superb|Talented|talented|competent|technology leading|knowledge|educated|specialized|skills|skill";

		// 有规模
		String teamScaleAdvantageWords = "Large|large|a number of|a high number of|many";
		// 有素质
		//String teamQualityAdvantageWords = "trusted|tried|Long term|long term|Long standing|long standing|enthusiastic|quality|impressive|dedicated|stable|loyal staff|loyal|well motivated|motivated|Active|more aggressive|solid|friendly|educated|friendly|cohesive|cooperative|long-standing|dynamic";
		String teamQualityAdvantageWords = "disciplinary|superior|longstanding|tried|passionate|Long standing|long standing|enthusiastic|trusted|trustworthy|Long term|long term|quality|impressive|dedicated|stable|loyal|motivated|proactive|Active|active|aggressive|solid|friendly|educated|cohesive|cooperative|dynamic|vibrant|performing|reliable";
		
		//将？去掉，必须出现
		// 团队优势词
		String AdvantageWords = "(" + teamExperienceAdvantageWords + "|" + teamCapableAdvantageWords + "|"
				+ teamScaleAdvantageWords + "|" + teamQualityAdvantageWords + ")?";

		// 研发类
		//String teamResearchTypeWord = "Developers|Designers|Design|Planning|technical|R&D|design|developers|production|Project Manager|SEO Team|Content Team|Pay Per Click Team|Web Developer";
		String teamResearchTypeWord = "Developers|Designers|research|Planning|technicians|technical|R&D|Design|design|developers|production|Project Manager|SEO Team|Content Team|Pay Per Click Team|Web Developer";
		
		// 管理类
		String teamManageTypeWord = "Management|management|operations|operation|MANAGEMENT|operating";
		// 销售类
		String teamSaleTypeWord = "retail|franchise|sales|marketing";
		// 其他类
		//String teamOtherTypeWord = "functioning|cleaning|doctors|advisers|Manufacturing|adviser team|Adviser team|security team|development team|recruitment team|support";
		String teamOtherTypeWord = "service|functioning|cleaning|doctors|advisers|care|carpentry|Manufacturing|adviser|Adviser|security|development|recruitment|support|installation|maintenance|healthcare|health care|fitting|media|Fine Art|Manufacturing|manufacturing|racing";
		
		//将？去掉，必须出现
		// 团队类型词
		String teamTypeWord = "(" + teamResearchTypeWord + "|" + teamManageTypeWord + "|" + teamSaleTypeWord + "|"
				+ teamOtherTypeWord + ")?";
		
		//将？去掉，必须出现
		// 员工
		//String staffWord = "(" + "staff|consultants|developers|elites|employees" + ")";
		String staff = "(practitioners|carers|engineers|work force|workforce|scientists|scientist|specialists|specialist|experts|famous experts|expert|technicians|personnel|seamstresses|managers|fitters|handlers|sub contractors|people|software engineers|staff|consultants|developers|elites|elite|employees|individuals|individual|professionals|professional)";
		// 数字
		String number = "[0-9]+\\d*\\.?\\d*(,\\d+)*";
		// 团队
		String teamWord = "(teams|team|Teams|Team|TEAM)";
		// 正则
		String[] teamReg = {
				
				//team supported by a host of highly qualified and dedicated early years practitioners.
				teamWord + " supported by a host of " + ajectiveWords + " " + AdvantageWords + " and " + AdvantageWords + " early years " + staff,
				
				
				//team, loyal to或者team, capable of
				teamWord + " , " + AdvantageWords + " (to|of)",
				
				//management team and workforce with a wealth of experience, knowledge and knowhow
				staff + " with " + "(a wealth of )?" + AdvantageWords + "( , )?" + AdvantageWords + "( and )?" + AdvantageWords,
				
				//strong, experienced, motivated and highly qualified team
				//处理多个，分割的情况
				ajectiveWords + "( )?" + AdvantageWords + "( , )?"  
			+	ajectiveWords + "( )?" + AdvantageWords + "( , )?"
			+	ajectiveWords + "( )?" + AdvantageWords + "( , )?"
			+   ajectiveWords + "( )?" + AdvantageWords + "( and )?"
			+   ajectiveWords + "( )?" + AdvantageWords + " " + teamWord,
			
				//highly trained and experienced workforce
				//没有team的限制可能会有噪音
				
				//A strong, well motivated KPI orientated management team
				//后期考虑是否将无关词替换成"(\\s)*(\\b\\w*\\s+){0,3}(\\s)*"
				AdvantageWords + " , " + ajectiveWords + " " + AdvantageWords + " KPI orientated " + teamTypeWord + " " + teamWord,
				
				//team and a highly professional workforce
				teamWord + " and a " + ajectiveWords + " " + AdvantageWords + " " + staff,
				
				//team due to their automotive experience and their superior management skills. 
				teamWord + " due to their " + ajectiveWords + " " + AdvantageWords + " and their " + AdvantageWords + " " + teamTypeWord + " " +AdvantageWords,
				
				//team with a collective experience
				teamWord + " with a " + ajectiveWords + " " + AdvantageWords, 
				
				//team of well-trained, experienced staff
				teamWord + " of " + ajectiveWords + " " + AdvantageWords + " (,|and) " + AdvantageWords + " " + staff,
				
				//a highly qualified, self motivated team
				ajectiveWords + " " + AdvantageWords + " , " + ajectiveWords + " " + AdvantageWords + " " + teamWord,
			
				//a highly specialised team with many years of expertise,
				//todo:这里的team with many years of expertise为什么匹配不出来呢 因为many years替换成了years
				ajectiveWords + "(\\s)*" + AdvantageWords + "(\\s)*" + teamWord,
				//teamWord + "(\\s)*with(\\s)*many(\\s)*years(\\s)*of(\\s)*" + AdvantageWords,
				//team with many years experience,team with many years of expertise
				teamWord + " with years (of )?" + AdvantageWords,
				
				//a very highly qualified team
				ajectiveWords + " " + AdvantageWords + " " + teamWord,
				
				//team of highly-trained personnel
				teamWord + " of " + ajectiveWords + " " + AdvantageWords + " " + staff,
				 
				//team of professionals experienced in...
				//todo:professionals目前即在有经验，又在员工里，后期看是否需要去掉有经验里面的
				teamWord + " of " + staff + " " + AdvantageWords,
				
				
				//team of tried and trusted seamstresses
				teamWord + " of " + AdvantageWords + " and " + AdvantageWords + " " + staff,
				
				//Large well-trained staff organized into installation teams
				//todo:well既在形容词里也在有素质里
				AdvantageWords + " " + ajectiveWords + " " + AdvantageWords + " " + staff + " organized into " + teamTypeWord + " " + teamWord,
				
				//team with highly-specialised experience
				teamWord + " with " + ajectiveWords + " " + AdvantageWords + " " + AdvantageWords,
				
				//Team of Creative Designers, Developers
				teamWord + " of Creative " + teamTypeWord + " , " + teamTypeWord,
				
				//team of four experienced, full time employees.
				teamWord + " of " + "(\\b\\w*\\s+){1,2}" + "(\\s)*" + AdvantageWords + " , full time " + staff,
				
				//team of dedicated
				teamWord + " of " + AdvantageWords,
				
				//35条
				
				//team of experienced, expertly trained, self-employed security operatives.
				teamWord + " of " + AdvantageWords + " , expertly " + AdvantageWords + " ,",
				
				//team with over 30 years combined experience
				teamWord + " with over " + number + " years " + ajectiveWords + " " + AdvantageWords,
				
				//team with decades of industry experience
				teamWord + " with decades of industry " + AdvantageWords,
				
				//team of employees with over 100 years of manufacturing experience
				teamWord + " of " + staff + " with over " + number + " years of manufacturing " + AdvantageWords,
				
				//team with extensive network of fully trained handlers
				teamWord + " with extensive network of " + ajectiveWords + " " + AdvantageWords + " " + staff,
				
				//team with the necessary skills and expertise
				//team with the skills and experience
				teamWord + " with the " + "(\\s)*" + ajectiveWords + "(\\s)*" + AdvantageWords + " and " + AdvantageWords,
				
				//Team of trained technicians
				teamWord + " of " + AdvantageWords + " " + staff,
				
				//team with decades of industry experience
				teamWord + " with decades of industry " + AdvantageWords,
				
				//team knowledgeable
				teamWord + "(\\s)*" + AdvantageWords,
				
				//team of certified and professional technicians.
				teamWord + " of " + AdvantageWords +" and " + AdvantageWords + "(\\s)*" + teamTypeWord,
				
				//MANAGEMENT TEAM
				teamTypeWord + "(\\s)*" + teamWord,
				
				//years of experience on our technical team
				"years of "+AdvantageWords+" on our "+teamTypeWord+"(\\s)*"+teamWord,
				
				
				//a well-trained, experienced Design, Planning and Manufacturing Team
				AdvantageWords+" , "+AdvantageWords+"(\\s)*"+teamTypeWord+" , "+teamTypeWord+" and "+teamTypeWord + "(\\s)*" + teamWord,
				
				//team of contractors that highly skilled
				teamWord + " of contractors that " + ajectiveWords + "(\\s)*"
				+ AdvantageWords,
				
				//team is populated by specialized experts
				teamWord + " (is|are) populated by " + AdvantageWords +" "+ staff,

				// team are impressive, with several highly skilled Master Technicians
				teamWord + "(\\s)*(is|are)(\\s)*" + AdvantageWords + "(\\s)*, with several " + ajectiveWords + "(\\s)*"
						+ AdvantageWords+" Master Technicians",

				// team size is of more than 125 experienced members
				teamWord + " size is of more than " + number + "(\\s)*" + AdvantageWords + " members",

				// team is capable
				teamWord + "(\\s)*(is|are)(\\s)*" + AdvantageWords,

				// team of experts,team of retail experts.
				teamWord + "(\\s)*(of|with)(\\s)*" + teamTypeWord + "(\\s)*" + staff,

				// knowledge and expertise of the team
				AdvantageWords + "(\\s)*and(\\s)*" + AdvantageWords + " of the " + teamWord,

				// Team comprises highly experienced and respected individuals
				teamWord + "(\\s)*comprises(\\s)*" + ajectiveWords + "(\\s)*" + AdvantageWords
						+ "(\\s*)and(\\s*)(\\b\\w*\\s+){1,2}(\\s)*" + staff,

				// team of loyal members of staff
				teamWord + "(\\s)*(of|with)(\\s)*" + AdvantageWords + " members of " + staff,

				// team of 4 skilled employees,team of 175 talented software engineers
				// team前面的部分与team后面的部分分开抽取
				teamWord + "(\\s)*(of|with)(\\s)*" + number + "(\\s)*" + AdvantageWords + "(\\s)*" + staff,

				// management team has over 60 years of combined experience
				// working with these agencies
				// 处理team与experience中间有大段间隔的情况
				teamTypeWord + "(\\s)*" + teamWord + " has over " + "[0-9]+\\d*\\.?\\d*(,\\d+)*" + "(\\s)*years of combined experience",
				

				//Long-standing second-tier management team
				// Highly experienced and long-standing management team in place
				ajectiveWords + "(\\s)*" + AdvantageWords + "(\\s*)(and)?(\\s*)(\\b\\w*\\s+){1,2}(\\s)*" + teamTypeWord + "(\\s)*" + teamWord,

				// expertise and highly qualified team
				ajectiveWords + "(\\s)*" + AdvantageWords + "(\\s*)and(\\s*)" + ajectiveWords + "(\\s)*"
						+ AdvantageWords + "(\\s)*" + teamWord,

				// very strong management and support team
				ajectiveWords + "(\\s)*" + teamTypeWord + "(\\s*)and(\\s*)" + teamTypeWord + "(\\s)*" + teamWord,

				// highly qualified , dedicated and experienced team
				ajectiveWords + "(\\s)*" + AdvantageWords + "(\\s)*,(\\s)*" + AdvantageWords + "(\\s*)and(\\s*)"
						+ AdvantageWords + "(\\s)*" + teamWord,

				// Strong second-tier management team
				//这个句子可能有噪音
				ajectiveWords + "(\\s)*(\\b\\w*\\s+){0,3}(\\s)*" + teamTypeWord + "(\\s)*" + teamWord,

				// Highly talented and skilled design team .
				ajectiveWords + "(\\s)*" + AdvantageWords + "(\\s*)and(\\s*)" + AdvantageWords + "(\\s)*"
						+ teamWord,

				// highly skilled , educated and knowledgeable employees
				ajectiveWords + "(\\s)*" + AdvantageWords + "(\\s)*,(\\s)*" + AdvantageWords + "(\\s*)and(\\s*)"
						+ AdvantageWords + "(\\s)*" + staff,
						
				// highly qualified, dedicated and experienced team
				ajectiveWords + "(\\s)*" + AdvantageWords + "(\\s)*,(\\s)*" + AdvantageWords + "(\\s*)and(\\s*)"
						+ AdvantageWords + "(\\s)*" + teamWord,
						
				// Highly efficient management team
				ajectiveWords + "(\\s)*" + AdvantageWords + "(\\s)*" + teamTypeWord + "(\\s)*" + teamWord,

				// strong & loyal team
				AdvantageWords + "(\\s)*" + "(and|&)?(\\s)*" + AdvantageWords + "(\\s)*" + teamWord,

				// Adviser team have significant experience and qualifications
				// within
				AdvantageWords + "(\\s)*" + teamTypeWord + "(\\s)*" + teamWord + "(\\s)*have(\\s)*" + ajectiveWords + "(\\s)*" + AdvantageWords + "(\\s)*(and)?(\\s)*" + ajectiveWords + "(\\s)*" + AdvantageWords,

				//highly trained and experienced workforce
				//没有team的限制可能会有噪音
				ajectiveWords + "( )?" + AdvantageWords + "( and | , )?" + ajectiveWords + "( )?" + AdvantageWords.replace("?", "") + " " +staff,
				
				// 句子中只要有team,有优势词+员工的优势词就抽取
				AdvantageWords.replace("?", "") + "(\\s)*" + staff,

				AdvantageWords + "(\\s)*(,)?(\\s)*" + AdvantageWords + "(\\s)*(and)?(\\s)*" + AdvantageWords + "(\\s)*" + teamTypeWord + "(\\s)*" + teamWord,

//				staffWord + "(\\s)*(with)?(\\s)*" + "technical expertise" 
				};

		// 通过规则抽取的list
		ArrayList<String> extractedStringList0 = (ArrayList<String>) MongoDBUtil.extractByReg(input, teamReg);

		// 对规则抽取的list进行拼接
		StringBuilder match = new StringBuilder();
		for (String team : extractedStringList0) {
			//System.out.println("team:" + team);
			match.append(team);
			match.append(" ");
		}

		// 将拼接后的字符串与词库匹配
		ArrayList<String> extractedResearchTypeList = (ArrayList<String>) MongoDBUtil.extract(match.toString(),
				teamResearchTypeWordTree);
		for (String string : extractedResearchTypeList)
			teamResearchSet.add(string);

		teamTypeMap.put("teamResearchList", teamResearchSet);

		ArrayList<String> extractedManageTypeList = (ArrayList<String>) MongoDBUtil.extract(match.toString(),
				teamManageTypeWordTree);
		for (String string : extractedManageTypeList)
			teamManageSet.add(string);
		teamTypeMap.put("teamManageList", teamManageSet);

		ArrayList<String> extractedSaleTypeList = (ArrayList<String>) MongoDBUtil.extract(match.toString(),
				teamSaleTypeWordTree);
		for (String string : extractedSaleTypeList)
			teamSaleSet.add(string);
		teamTypeMap.put("teamSaleList", teamSaleSet);

		ArrayList<String> extractedOtherTypeList = (ArrayList<String>) MongoDBUtil.extract(match.toString(),
				teamOtherTypeWordTree);
		for (String string : extractedOtherTypeList)
			teamOtherSet.add(string);
		teamTypeMap.put("teamOtherList", teamOtherSet);

		if (teamTypeMap.get("teamResearchList").toString().equals("[]")
				&& teamTypeMap.get("teamManageList").toString().equals("[]")
				&& teamTypeMap.get("teamSaleList").toString().equals("[]")
				&& teamTypeMap.get("teamOtherList").toString().equals("[]"))
			resultMap.put("teamType", new HashMap<>());
		else
			resultMap.put("teamType", teamTypeMap);

		ArrayList<String> extractedExperienceList = (ArrayList<String>) MongoDBUtil.extract(match.toString(),
				experienceWordTree);
		for (String string : extractedExperienceList)
			experienceAdvantageSet.add(string);
		// 匹配之后加上可能的搭配
		teamAdvantageMap.put("experienceAdvantageList",
				TeamAddAdjectiveUtil.teamAddAdjectiveUtil(experienceAdvantageSet, input));

		ArrayList<String> extractedCapableList = (ArrayList<String>) MongoDBUtil.extract(match.toString(),
				capableWordTree);
		for (String string : extractedCapableList)
			capableAdvantageSet.add(string);

		// 去重之后的结果
		// teamAdvantageMap.put("capableAdvantageList",TeamAddAdjectiveUtil
		// .teamAddAdjectiveUtil(capableAdvantageSet, input) );

		teamAdvantageMap.put("capableAdvantageList", TeamAddAdjectiveUtil
				.removeCompete(TeamAddAdjectiveUtil.teamAddAdjectiveUtil(capableAdvantageSet, input)));

		ArrayList<String> extractedScaleList = (ArrayList<String>) MongoDBUtil.extract(match.toString(), scaleWordTree);
		for (String string : extractedScaleList)
			scaleAdvantageSet.add(string);
		teamAdvantageMap.put("scaleAdvantageList", TeamAddAdjectiveUtil.teamAddAdjectiveUtil(scaleAdvantageSet, input));

		ArrayList<String> extractedQualityList = (ArrayList<String>) MongoDBUtil.extract(match.toString(),
				qualityWordTree);
		for (String string : extractedQualityList)
			qualityAdvantageSet.add(string);
		teamAdvantageMap.put("qualityAdvantageList",
				TeamAddAdjectiveUtil.teamAddAdjectiveUtil(qualityAdvantageSet, input));

		if (teamAdvantageMap.get("experienceAdvantageList").toString().equals("[]")
				&& teamAdvantageMap.get("capableAdvantageList").toString().equals("[]")
				&& teamAdvantageMap.get("scaleAdvantageList").toString().equals("[]")
				&& teamAdvantageMap.get("qualityAdvantageList").toString().equals("[]"))
			resultMap.put("teamAdvantage", new HashMap<>());
		else
			resultMap.put("teamAdvantage", teamAdvantageMap);

		// todo1:结果的去重
		// todo2:一段文本只抽取一个结果，将多个结果的合并
		// todo3：去掉大段的正则，改成一段的正则，去除噪音
		return resultMap;
		// // 后面每一个小类存到map<String,List>
		// // 抽取研发类(团队类型)
		// ArrayList<String> extractedResearchList = (ArrayList<String>)
		// MongoDBUtil
		// .extract(input, teamResearchTypeWordTree);
		// if (extractedResearchList.size() == 0) {
		// // teamResearchList.add("");
		// } else {
		// for (String str : extractedResearchList) {
		// teamResearchList.add(str.replaceAll(" team| Team", ""));
		// }
		// }
		// teamTypeMap.put("teamResearchList", teamResearchList);
		//
		// // 抽取管理类(团队类型)
		// ArrayList<String> extractedManageList = (ArrayList<String>)
		// MongoDBUtil
		// .extract(input, teamManageTypeWordTree);
		// if (extractedManageList.size() == 0) {
		// // teamManageList.add("");
		// } else {
		// for (String str : extractedManageList) {
		// teamManageList.add(str);
		// }
		// }
		// teamTypeMap.put("teamManageList", teamManageList);
		//
		// // 抽取销售类(团队类型)
		// ArrayList<String> extractedSaleList = (ArrayList<String>) MongoDBUtil
		// .extract(input, teamSaleTypeWordTree);
		// if (extractedSaleList.size() == 0) {
		// // teamSaleList.add("");
		// } else {
		// for (String str : extractedSaleList) {
		// teamSaleList.add(str);
		// }
		// }
		// teamTypeMap.put("teamSaleList", teamSaleList);
		//
		// // 抽取其他类(团队类型)
		// ArrayList<String> extractedOtherList = (ArrayList<String>)
		// MongoDBUtil
		// .extract(input, teamOtherTypeWordTree);
		// if (extractedOtherList.size() == 0) {
		// // teamOtherList.add("");
		// } else {
		// for (String str : extractedOtherList) {
		// teamOtherList.add(str.replaceAll(" team| Team", ""));
		// }
		// }
		// teamTypeMap.put("teamOtherList", teamOtherList);
		// resultMap.put("teamType", teamTypeMap);
		//
		// // 抽取有经验(团队优势)
		// String[] experienceAdvantageReg = {
		// "(rich|significant|rich(\\s)*industry|highly|Fully|Highly|industry)?(\\s)*(experienced|Senior|senior|experience|Experienced)"
		// };
		// ArrayList<String> extractedExperienceList = (ArrayList<String>)
		// MongoDBUtil
		// .extractByReg(input, experienceAdvantageReg);
		// if (extractedExperienceList.size() == 0) {
		// // experienceAdvantageList.add("");
		// } else {
		// for (String str : extractedExperienceList) {
		// experienceAdvantageList.add(str);
		// }
		// }
		// teamAdvantageMap
		// .put("experienceAdvantageList", experienceAdvantageList);
		//
		// // 抽取有能力(团队优势)
		// String[] capableAdvantageReg = {
		// "(rich|significant|rich(\\s)*industry|highly|Fully|Highly)?(\\s)*(professionals|professional|Professional|efficient|Outstanding|superb|skilled(\\s)*consultants|scientists|qualifications|qualification(\\s)*skilled|technical(\\s)*elites|expertise|trained|capable|knowledgeable|excellent|mature|superb|Talented|competent|knowledgeable|strong|Strong|technology-leading|skilled|qualified)\\s"
		// };
		// ArrayList<String> extractedCapableList = (ArrayList<String>)
		// MongoDBUtil
		// .extractByReg(input, capableAdvantageReg);
		// if (extractedCapableList.size() == 0) {
		// // capableAdvantageList.add("");
		// } else {
		// for (String str : extractedCapableList) {
		// capableAdvantageList.add(str);
		// }
		// }
		// teamAdvantageMap.put("capableAdvantageList", capableAdvantageList);
		//
		// // 抽取有规模(团队优势)
		// String[] scaleAdvantageReg = {
		// "(over)?(\\s)*\\d+(,\\d+)*\\.?\\d*(,\\d+)*(\\s)*(\\b\\w*\\s+|,\\s+){0,2}(\\s)*employees"
		// };
		// ArrayList<String> extractedScaleList0 = (ArrayList<String>)
		// MongoDBUtil
		// .extractByReg(input, scaleAdvantageReg);
		// ArrayList<String> extractedScaleList1 = (ArrayList<String>)
		// MongoDBUtil
		// .extract(input, scaleWordTree);
		// extractedScaleList1.addAll(extractedScaleList0);
		// if (extractedScaleList0.size() == 0 && extractedScaleList1.size() ==
		// 0) {
		// // scaleAdvantageList.add("");
		// } else {
		// for (String str : extractedScaleList1) {
		// scaleAdvantageList.add(str);
		// }
		// }
		// teamAdvantageMap.put("scaleAdvantageList", scaleAdvantageList);
		//
		// // 抽取有素质(团队优势)
		// String[] qualityAdvantageReg = {};
		// ArrayList<String> extractedQualityList = (ArrayList<String>)
		// MongoDBUtil
		// .extract(input, qualityWordTree);
		// if (extractedQualityList.size() == 0) {
		// // qualityAdvantageList.add("");
		// } else {
		// for (String str : extractedQualityList) {
		// qualityAdvantageList.add(str);
		// }
		// }
		// teamAdvantageMap.put("qualityAdvantageList", qualityAdvantageList);
		// if (teamAdvantageMap.size() == 0)
		// resultMap.put("teamAdvantage", new HashMap<>());
		// else
		// resultMap.put("teamAdvantage", teamAdvantageMap);
		// return resultMap;
	}

	public static void main(String[] args) throws Exception {

		PrintStream ps;
		// ps = new PrintStream(new FileOutputStream(
		// "C:\\extractCompeteTeam4w.txt"));
		ps = new PrintStream(new FileOutputStream(PropertyUtil.getValue("compete.team.output")));
		System.setOut(ps);
		// String fileTest2 =
		// "C:\\Users\\nlp\\workspace1\\extractCashFlow3\\src\\main\\resources\\seller_4w.txt";
		String fileTest2 = PropertyUtil.getValue("compete.team.input");
		WordTree teamResearchTypeWordTree = WordTreeCase.getTeamResearchTypeWordTree();
		WordTree teamManageTypeWordTree = WordTreeCase.getTeamManageTypeWordTree();
		WordTree teamSaleTypeWordTree = WordTreeCase.getTeamSaleTypeWordTree();
		WordTree teamOtherTypeWordTree = WordTreeCase.getTeamOtherTypeWordTree();
		// 4种团队优势（有经验的使用正则匹配）
		WordTree experienceWordTree = WordTreeCase.getExperienceWordTree();
		WordTree capableWordTree = WordTreeCase.getCapableWordTree();
		WordTree scaleWordTree = WordTreeCase.getScaleWordTree();
		WordTree qualityWordTree = WordTreeCase.getQualityWordTree();

		ArrayList<String> input = FileUtil.importData(fileTest2);

		for (String string : input) {

			if (string.toLowerCase().contains("team")) {
				System.out.println(string);
				String[] teams = string.split("\\.");
				ArrayList teamList = new ArrayList<Object>();
				for (String team : teams) {
					if (team.toLowerCase().contains("team"))
						System.out.println(JsonTool.formatJson(JSONObject
								.fromObject(
										extractTeam(PreProcess.competeTeamPreProcess(team), teamResearchTypeWordTree,
												teamManageTypeWordTree, teamSaleTypeWordTree, teamOtherTypeWordTree,
												experienceWordTree, capableWordTree, scaleWordTree, qualityWordTree))
								.toString(), "\t")

						);
				}

			}

			// String ans = conpeteExtract.extractCompete(string);
			// JsonFormatTool jst = new JsonFormatTool();
			// System.out.println(JsonTool.formatJson(ans, "\t"));
			// System.out.println();
			// System.out.println();
		}
	}
	// PrintStream ps = new PrintStream(new FileOutputStream(
	// "C:\\extractCompeteTeam.txt"));
	// System.setOut(ps);
	// String fileTest =
	// "C:\\Users\\nlp\\workspace1\\extractCashFlow3\\src\\main\\resources\\compete_team.txt";
	// Map<String, String> map = new HashMap<String, String>();
	// // 4种团队类型
	// WordTree teamResearchTypeWordTree = WordTreeCase
	// .getTeamResearchTypeWordTree();
	// WordTree teamManageTypeWordTree = WordTreeCase
	// .getTeamManageTypeWordTree();
	// WordTree teamSaleTypeWordTree = WordTreeCase.getTeamSaleTypeWordTree();
	// WordTree teamOtherTypeWordTree = WordTreeCase
	// .getTeamOtherTypeWordTree();
	// // 4种团队优势（有经验的使用正则匹配）
	// WordTree experienceWordTree = WordTreeCase.getExperienceWordTree();
	// WordTree capableWordTree = WordTreeCase.getCapableWordTree();
	// WordTree scaleWordTree = WordTreeCase.getScaleWordTree();
	// WordTree qualityWordTree = WordTreeCase.getQualityWordTree();
	//
	// for (int i = 1; i < 41; i++) {
	// String input = PreProcess.competeTeamPreProcess(FileUtil
	// .importData(fileTest, i));
	// System.out.println(input);
	//
	// if (input.toLowerCase().contains("team")) {
	// String[] teams = input.split("\\.");
	// ArrayList teamList = new ArrayList<Object>();
	// for (String team : teams) {
	// if (team.toLowerCase().contains("team"))
	// System.out.println(JsonTool.formatJson(
	// JSONObject.fromObject(
	// extractTeam(team,
	// teamResearchTypeWordTree,
	// teamManageTypeWordTree,
	// teamSaleTypeWordTree,
	// teamOtherTypeWordTree,
	// experienceWordTree,
	// capableWordTree, scaleWordTree,
	// qualityWordTree)).toString(),
	// "\t")
	//
	// );
	// }
	//
	// }
	//
	// System.out.println();
	// }
	// }

}
