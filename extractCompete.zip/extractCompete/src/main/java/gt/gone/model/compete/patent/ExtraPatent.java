package gt.gone.model.compete.patent;

import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import gt.gone.util.FileUtil;
import gt.gone.util.JsonTool;
import gt.gone.util.MongoDBUtil;
import gt.gone.util.PropertyUtil;
import gt.gone.util.WordTree;
import gt.gone.util.WordTreeCase;
import net.sf.json.JSONObject;

public class ExtraPatent {

	public static String preProcess(String str) {
		return str.toLowerCase().replaceAll("\\.|,|!|\\?|\"|\\|/", " ").replace("no patent", "")
				.replace("no patents", "").replace("no patented", "").replace("unpatent", "").replace("unpatented", "");
	}

	public static HashMap<String, Object> extractPatent(String input, WordTree patentWordTree) {
		LinkedHashMap<String, Object> resultMap = new LinkedHashMap<String, Object>();
		List patentList = new LinkedList<String>();
		ArrayList<String> extractedPatentList = (ArrayList<String>) MongoDBUtil.extract(preProcess(input),
				patentWordTree);
		if (extractedPatentList.size() == 0) {
			return null;
		} else {
			for (String str : extractedPatentList) {
				patentList.add(str);
			}
		}
		resultMap.put("patentList", patentList);
		return resultMap;
	}

	public static void main(String[] args) throws Exception {
		//PrintStream ps = new PrintStream(new FileOutputStream("C:\\extractCompetePatent.txt"));
		PrintStream ps = new PrintStream(new FileOutputStream(PropertyUtil.getValue("compete.patent.output")));
		System.setOut(ps);
		//String fileTest = "C:\\Users\\nlp\\workspace\\extractCashFlow3\\src\\main\\resources\\compete_patent.txt";
		String fileTest = PropertyUtil.getValue("compete.patent.input");
		Map<String, String> map = new HashMap<String, String>();

		WordTree patentWordTree = WordTreeCase.getPatentWordTree();

		for (int i = 1; i < 28; i++) {
			String input = preProcess(FileUtil.importData(fileTest, i));
			System.out.println(input);
			System.out.println(
					JsonTool.formatJson(JSONObject.fromObject(extractPatent(input, patentWordTree)).toString(), "\t"));
			System.out.println();
		}
	}

}
