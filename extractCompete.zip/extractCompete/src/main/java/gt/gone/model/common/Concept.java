package gt.gone.model.common;

import java.util.List;

public class Concept {
	private String name; //xml file's concept name
	private List<String> keywords; //concept's keywords list
		
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public List<String> getKeywords() {
		return keywords;
	}
	public void setKeywords(List<String> keywords) {
		this.keywords = keywords;
	}

}
