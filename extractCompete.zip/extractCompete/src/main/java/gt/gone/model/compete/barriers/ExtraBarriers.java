package gt.gone.model.compete.barriers;

import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import gt.gone.util.FileUtil;
import gt.gone.util.JsonTool;
import gt.gone.util.MongoDBUtil;
import gt.gone.util.PropertyUtil;
import gt.gone.util.WordTree;
import gt.gone.util.WordTreeCase;
import net.sf.json.JSONObject;

public class ExtraBarriers {

	public static String preProcess(String str) {
		return str.toLowerCase().replaceAll("\\.|,|!|\\?|\"|\\|/|;", " ").replace("no barriers", "")
				.replace("barriers to enter do not exist", "").replace("barrier to enter do not exist", "")
				.replace("no entry barrier", "").replace("no entry barriers", "").replace("no barriers", "")
				.replace("no barrier", "");
	}

	public static HashMap<String, Object> extractBarriers(String input, WordTree barriersWordTree) {
		LinkedHashMap<String, Object> resultMap = new LinkedHashMap<String, Object>();
		List barriersList = new LinkedList<String>();
		ArrayList<String> extractedBarriersList = (ArrayList<String>) MongoDBUtil.extractTrueOrFlase(preProcess(input),
				barriersWordTree);
		if (extractedBarriersList.size() == 0) {
			return null;
		} else {
			for (String str : extractedBarriersList) {
				barriersList.add(str);
			}
		}
		resultMap.put("barriersList", barriersList);

		return resultMap;
	}

	public static void main(String[] args) throws Exception {
		//PrintStream ps = new PrintStream(new FileOutputStream("C:\\extractCompeteBarriers.txt"));
		PrintStream ps = new PrintStream(new FileOutputStream(PropertyUtil.getValue("compete.barriers.output")));
		System.setOut(ps);
		String fileTest = "C:\\Users\\nlp\\workspace\\extractCashFlow3\\src\\main\\resources\\compete_barriers.txt";
		//String fileTest2 = "C:\\TestData\\TestBarriersAll.txt";
		String fileTest2 = PropertyUtil.getValue("compete.barriers.input");
		Map<String, String> result = new HashMap<String, String>();
		final String HAVE = "have";
		final String NOTHAVE = "not_have";
		WordTree barriersWordTree = WordTreeCase.getBarriersWordTree();
		
		for (int i = 1; i < 169; i++) {
			String rawInput = FileUtil.importData(fileTest2, i);
			if(rawInput!=null){
				
			
			String input = preProcess(rawInput);
			System.out.println(i + " " + rawInput);
			if (ExtraBarriers.extractBarriers(input, barriersWordTree) == null)
				result.put("barriers", NOTHAVE);
			else
				result.put("barriers", HAVE);
			System.out.println(JsonTool.formatJson(JSONObject.fromObject(
					result/* extractBarriers(input, barriersWordTree) */).toString(), "\t"));
			System.out.println();
			}
		}
	}

}
