package gt.gone.model.compete;

import java.io.FileOutputStream;
import java.io.PrintStream;

import gt.gone.util.FileUtil;
import gt.gone.util.JsonTool;

public class CompeteExtractFromStr {
	public static void main(String[] args) throws Exception {		
		CompeteExtract conpeteExtract = new CompeteExtract();
		String input = "profit 50% and 15% market share.";
		if (input != null) {
			String ans = conpeteExtract.extractCompete(input);
			// JsonFormatTool jst = new JsonFormatTool();
			System.out.println(JsonTool.formatJson(ans, "\t"));
			System.out.println();
			System.out.println();
		}		
	}

}
