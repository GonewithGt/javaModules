package gt.gone.util;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class MoneyUtil {
	//得到钱数短语的类型
	public static String getMoneyCurrencyType(String money){
		if(money.contains("$")||money.contains("USD")||money.contains("US")||money.contains("pound")||money.contains("dollar")){
			return "$";
		}else if(money.contains("£")||money.contains("c£")||money.contains("c. £")||money.contains("c £")){
			return "£";
		}else if(money.contains("Dhs")){//阿拉伯联合酋长国的流通货币
			return "Dhs";
		}else if(money.contains("INR")){
			return "INR";
		}
		else if(money.contains("baht")){
			return "baht";
		}
		else if(money.contains("euros")||money.contains("EUR")){
			return "EUR";
		}else if(money.contains("DKK")){
			return "DKK";
		}else if(money.contains("Swiss")){
			return "Swiss francs";
		}else if(money.contains("JPY")){
			return "JPY";
		}else if(money.contains("AED")){
			return "AED";
		}else if(money.contains("Rs")){
			return "Rs.";
		}else if(money.contains("RMB")||money.contains("rmb")||money.contains("R")||money.contains("yuan")){
			return "RMB";
		}
			
		return null;
	}
	//得到钱数短语的数字部分
	
	public static String getMoneyNum(String money,PatternUtil pu, XmlUtil xml){
		if(money.contains("thousand")){
			return money.replace("dollars", "").trim();
		}
		if(money.toLowerCase().startsWith("r")){
			money = money.substring(1);
		}
		String moneyTypeKeyWord = pu.templateToRegex("单位",xml.conceptMap).getReg();//"(USD|\\$|US|pounds|c. £|c £|c£|£|cr|Dhs|INR|baht|euros|DKK|EUR|eur|euros|EUROS|JPY|AED)";
		String moneyRangeKeyWord = "(from |to |- |between )";
		String yueShuCi = "约数词";
		String regex = "plus|" + pu.templateToRegex(yueShuCi,xml.conceptMap).getReg() +"|"+ moneyTypeKeyWord+"|"+ moneyRangeKeyWord;
		//System.out.println(regex);
		return money.toLowerCase().replaceAll(regex.toLowerCase(), "").trim();
	}
	public static String getMoneyNum(String money,LinkedHashMap<String,String> regexs){
		if(money.contains("thousand")){
			return money.replace("dollars", "").trim();
		}
		if(money.toLowerCase().startsWith("r")){
			money = money.substring(1);
		}
		String moneyTypeKeyWord = "(USD|\\$|US|pounds|c. £|c £|c£|£|cr|Dhs|INR|baht|euros|DKK|EUR|eur|euros|EUROS|JPY|AED)";
		String moneyRangeKeyWord = "(from |to |- |between )";
		String yueShuCi = "约数词";
		String yueShuCiRegex = "";
		if(regexs.containsKey(yueShuCi)){
		 yueShuCiRegex =regexs.get(yueShuCi) ;
		}else {
			System.out.println("something wrong");
		}
		
		if(regexs.containsKey("单位")){
			moneyTypeKeyWord =regexs.get("单位") ;
		}else {
			System.out.println("something wrong");
		}
		
		String regex = "plus|" +yueShuCiRegex+"|"+ moneyTypeKeyWord+"|"+ moneyRangeKeyWord;;
		
		//System.out.println(regex);
		return money.toLowerCase().replaceAll(regex.toLowerCase(), "").trim();
	}
	
	public static String getMoneyModifier(String money,PatternUtil pu, XmlUtil xml){
		//String moneyTypeKeyWord = pu.templateToRegex("单位",xml.conceptMap).getReg();//"(USD|\\$|US|pounds|c. £|c £|c£|£|cr|Dhs|INR|baht|euros|DKK|EUR|eur|euros|EUROS|JPY|AED)";
		String yueShuCi = "约数词";
		String regex = pu.templateToRegex(yueShuCi,xml.conceptMap).getReg(); //+"|"+ moneyTypeKeyWord;
		//System.out.println(regex);
		Pattern pattern = Pattern.compile(regex.toLowerCase());
		Matcher matcher = pattern.matcher(money.toLowerCase());
		if(matcher.find()){
			return matcher.group(0).trim();
		}
		return null;
	}
	
	public static String getMoneyModifierType(String moneyModifier,String moneyText){
		String[] aboveKeyWords = {"above","over","more than","in excess of","exceeded","just over","at least","+","exceed"};
		String[] aboutKeyWords = {"about","around","nearly","circa","In The Vicinity Of","approximately"};
		String[] daYuDengyuKeyWords = {"no less","no less than","no fewer than"};
		//String[] lessKeyWords = {"approaching","up to","in the mid"};
		String[] equalKeyWords = {"approaching","up to","in the mid"};
		if(moneyText.contains("+")){
			return "ABOVE";
		}
		if(moneyModifier!=null && !moneyModifier.isEmpty()){
			//System.out.println(moneyModifier+" "+moneyText);
			for(String daYuCi: aboveKeyWords){
				if(moneyModifier.contains(daYuCi)){
					return "ABOVE";
				}
			}
			
			for(String about: aboutKeyWords){
				if(moneyModifier.contains(about) ){
					return "ABOUT";
				}
			}
			for(String daYuDengYu: daYuDengyuKeyWords){
				if(moneyModifier.contains(daYuDengYu) ){
					return "DAYUDENGYU";
				}
			}
			for(String equal: equalKeyWords){
				if(moneyModifier.contains(equal) ){
					return "EQUAL";
				}
			}
			
			

		}
		return null;
	}
	
	public static void main(String []args){
		XmlUtil xml = new XmlUtil("profitability","cashflow","CashFlow.xml");
		PatternUtil pu = new PatternUtil();
		String moneyTypeKeyWord = "(USD|\\$|US|pounds|£|c£|Dhs|INR|bahteuros)";
		//System.out.println("no fewer than £ -$5000".replaceAll(moneyTypeKeyWord, "-"));
		System.out.println(getMoneyNum("no fewer than £ -$5000",pu,xml));
		
		if("1.24+".contains("+")){
			System.out.println("abc");
		}
	}
	
	//0 表示非范围 1表示一个范围
	public static int getMoneyType(String oldChar,LinkedHashMap<String,String> regexs) {
		// TODO Auto-generated method stub		
		String moneyRange = "钱数范围";
		//String regex = pu.toRegex(xml.conceptMap).get(moneyRange);
		String regex = regexs.get(moneyRange);
		Pattern pattern = Pattern.compile(regex.toLowerCase());
		Matcher matcher = pattern.matcher(oldChar.toLowerCase());
		if(matcher.find()){
			return 1;
		}
		return 0;
	}
	//如果表示范围抽出范围的小值
	public static String getMoneyMin(String oldChar,LinkedHashMap<String,String> regexs) {
		// TODO Auto-generated method stub
		String moneyNum = null;
		if(getMoneyType(oldChar,regexs) == 1){
			if(oldChar.contains("-")){
				moneyNum = oldChar.substring(0,oldChar.indexOf("-")).trim();
				if(moneyNum.contains("from ")){
					moneyNum = moneyNum.substring(moneyNum.indexOf("from ")+"from ".length()).trim();
				}else if(moneyNum.contains("between ")){
					moneyNum = moneyNum.substring(moneyNum.indexOf("between ")+"between ".length()).trim();
				}
				return getMoneyNum(moneyNum, regexs).trim();
			}else if(oldChar.contains(" to ")){
				moneyNum = oldChar.substring(0,oldChar.indexOf(" to ")).trim();
				if(moneyNum.contains("from ")){
					moneyNum = moneyNum.substring(moneyNum.indexOf("from ")+"from ".length()).trim();
				}else if(moneyNum.contains("between ")){
					moneyNum = moneyNum.substring(moneyNum.indexOf("between ")+"between ".length()).trim();
				}
				return getMoneyNum(moneyNum, regexs).trim();
			}else if(oldChar.contains("/")){
				moneyNum = oldChar.substring(0,oldChar.indexOf("/")).trim();
				
				return getMoneyNum(moneyNum, regexs).trim();
			}else if(oldChar.contains(" and ")){
				moneyNum = oldChar.substring(0,oldChar.indexOf(" and ")).trim();
				if(moneyNum.contains("from ")){
					moneyNum = moneyNum.substring(moneyNum.indexOf("from ")+"from ".length()).trim();
				}else if(moneyNum.contains("between ")){
					moneyNum = moneyNum.substring(moneyNum.indexOf("between ")+"between ".length()).trim();
				}
				return getMoneyNum(moneyNum, regexs).trim();
			}
			
		}
		return moneyNum;
	}
	//如果表示范围抽取范围的大值
	public static String getMoneyMax(String oldChar,LinkedHashMap<String,String> regexs) {
		// TODO Auto-generated method stub
		String moneyNum = null;
		if(getMoneyType(oldChar,regexs) == 1){
			if(oldChar.contains("-")){
				//System.out.println("gtt");
				moneyNum = oldChar.substring(oldChar.indexOf("-")+1).trim();
				return getMoneyNum(moneyNum, regexs).trim();
			}else if(oldChar.contains(" to ")){
				moneyNum = oldChar.substring(oldChar.indexOf(" to ")+" to ".length()).trim();
				return getMoneyNum(moneyNum, regexs).trim();
			}else if(oldChar.contains("/")){
				moneyNum = oldChar.substring(oldChar.indexOf("/")+"/".length()).trim();
				
				return getMoneyNum(moneyNum, regexs).trim();
			}else if(oldChar.contains(" and ")){
				moneyNum = oldChar.substring(oldChar.indexOf(" and ")+" and ".length()).trim();
				return getMoneyNum(moneyNum, regexs).trim();
			}
		}
		return moneyNum;
	}
	//对于钱数定性的描述 0 表示没有定性词 1 表示高 2表示一般
	public static int getMoneyQualityCategory(String oldChar ,LinkedHashMap<String,String> regexs) {
		// TODO Auto-generated method stub
		String qualityDes = getMoneyQualityDes(oldChar,regexs);
		String[] amazingWords = {"incredible","amazing","great","excellent","outstanding","Tremendous","significant","top","highest","superb","terrific","consummate","preeminent","flawless"};
		if(qualityDes!=null && !qualityDes.isEmpty()){
			for(String amazingWord: amazingWords){
				if(qualityDes.contains(amazingWord)|| qualityDes.contains(amazingWord)){
					return 1;
				}else{
					return 2;
				}
			}
		}
		return 0;
	}

	public static String getMoneyQualityDes(String oldChar, LinkedHashMap<String,String> regexs) {
		// TODO Auto-generated method stub
		//System.out.println("oldChar"+oldChar);
		String moneyQualityDes = "定性描述词";
		//String moneyQualityDes = "定性描述词";
		String regex = "( |^)("+(regexs.get("并列定性描述词")+"|"+regexs.get(moneyQualityDes)).toLowerCase()+")( |$)";
		Pattern pattern = Pattern.compile(regex.toLowerCase());
		Matcher matcher = pattern.matcher(oldChar.toLowerCase());
		if(matcher.find()){
			//int end = matcher.end();
			//if(end < oldChar.length() && oldChar.charAt(end)==' ')
			return oldChar.substring(matcher.start(), matcher.end()).trim();
		}
		return null;
	}
	
	public static String  getCorrectMoneyQualityDes(String matchedSen, LinkedHashMap<String,String> regexs, String keyWord) {
	//	System.out.println("matchedSen="+matchedSen);
	//	System.out.println(keyWord+"\\s*"+"(#达到类词语|#预计达到)");
	//	System.out.println(matchedSen.replaceAll("\\d", ""));
	//	System.out.println(matchedSen.replaceAll("\\d", "").contains(keyWord+" "+"#达到类词语"));
		if(matchedSen.contains("#周期")){
			if(matchedSen.indexOf("#周期")-15 >= 0 ){
				matchedSen = matchedSen.substring(matchedSen.indexOf("#周期")-15);
			}
		
		String xiushiciString = getMoneyQualityDes(matchedSen,regexs);
	//	System.out.println("xiushiciString="+xiushiciString);
		if(xiushiciString!=null && !xiushiciString.isEmpty()){
	//		System.out.println(matchedSen.indexOf("#周期"));
			
			xiushiciString = " "+xiushiciString.trim()+" ";
	//		System.out.println(matchedSen.indexOf(xiushiciString)+xiushiciString.length());
			if((matchedSen.indexOf("#周期")- matchedSen.indexOf(xiushiciString)-xiushiciString.length())<3
				&&(matchedSen.indexOf("#周期")- matchedSen.indexOf(" "+xiushiciString.trim()+" "))-xiushiciString.length()>=0
				&&(matchedSen.indexOf(keyWord)- matchedSen.indexOf(" "+xiushiciString.trim()+" "))-xiushiciString.length()>=0){
				return xiushiciString.trim();
			}
		}
		}else if (matchedSen.replaceAll("\\d", "").contains(keyWord+" "+"#达到类词语")
				||matchedSen.replaceAll("\\d", "").contains(keyWord+" "+"#预计达到")) {
			
			if(matchedSen.indexOf("#达到类词语")>= 0 ){
				matchedSen = matchedSen.substring(matchedSen.indexOf("#达到类词语"));
				String xiushiciString = getMoneyQualityDes(matchedSen,regexs);
			//	System.out.println("xiushiciString="+xiushiciString);
				if(xiushiciString!=null && !xiushiciString.isEmpty()){
			//		System.out.println(matchedSen.indexOf("#周期"));
					
					xiushiciString = " "+xiushiciString.trim()+" ";
			//		System.out.println(matchedSen.indexOf(xiushiciString)+xiushiciString.length());
					if(( matchedSen.indexOf(xiushiciString)-matchedSen.indexOf("#达到类词语")-"#达到类词语".length()-2)< 8
						&& matchedSen.contains("#时间")
						||(matchedSen.indexOf(xiushiciString)-matchedSen.indexOf("#达到类词语")-"#达到类词语".length()-2)< 3){
						return xiushiciString.trim();
					}
				}
			}else if(matchedSen.indexOf("#预计达到")>= 0){
				matchedSen = matchedSen.substring(matchedSen.indexOf("#预计达到"));
				String xiushiciString = getMoneyQualityDes(matchedSen,regexs);
		//		System.out.println("xiushiciString="+xiushiciString);
				if(xiushiciString!=null && !xiushiciString.isEmpty()){
			//		System.out.println(matchedSen.indexOf("#周期"));
					
					xiushiciString = " "+xiushiciString.trim()+" ";
			//		System.out.println(matchedSen.indexOf(xiushiciString)+xiushiciString.length());
					if(( matchedSen.indexOf(xiushiciString)-matchedSen.indexOf("#预计达到")-"#预计达到".length()-2)< 8
							&& matchedSen.contains("#时间")
							||(matchedSen.indexOf(xiushiciString)-matchedSen.indexOf("#预计达到")-"#预计达到".length()-2)< 3){
							return xiushiciString.trim();
						}
				}
			}
			
		}
		return null;
		
	}
	
	public static LinkedHashMap<String, Object> addFarXiuShiCi(String longestMatchString, String keyWord, LinkedHashMap<String,String> regexs, LinkedHashMap<String, Object> keyToInfoMap) {
		//System.out.println("longestMatchString==>"+longestMatchString);
		//LinkedHashMap<String,String> regexs = (new PatternUtil()).toRegex(xml.conceptMap);
		String farXiushiciString = getCorrectMoneyQualityDes(longestMatchString, regexs, keyWord);
		//System.out.println("farXiushiciString==>"+farXiushiciString);
		if(farXiushiciString != null){			
			int cashFlowKeyStart = longestMatchString.indexOf(keyWord);
			String keyTokenString = "";
			if(cashFlowKeyStart>=0 && cashFlowKeyStart+keyWord.length()+2 <= longestMatchString.length()){
				keyTokenString = longestMatchString.substring(cashFlowKeyStart, cashFlowKeyStart+keyWord.length()+2).trim();
			}else if (cashFlowKeyStart>=0 && cashFlowKeyStart+keyWord.length()+1 <= longestMatchString.length()) {
				keyTokenString = longestMatchString.substring(cashFlowKeyStart, cashFlowKeyStart+keyWord.length()+1).trim();
				
			}else{
				return keyToInfoMap;
			}
			
			if(longestMatchString.contains(keyTokenString) && keyToInfoMap.get(keyTokenString) instanceof LinkedHashMap<?, ?>){
				LinkedHashMap<String, Object> cashFlowTokenMap = (LinkedHashMap<String, Object>) keyToInfoMap.get(keyTokenString);
				if(cashFlowTokenMap!=null && cashFlowTokenMap.get("cfDescripWord") ==null){
					cashFlowTokenMap.put("cfDescripWord", farXiushiciString);
					cashFlowTokenMap.put("cfDescripWordCategory", MoneyUtil.getMoneyQualityCategory(farXiushiciString,regexs));	
				}
			}
			
		}
		return keyToInfoMap;
		
	}
	
	
	public static String getTokenStr(String longestMatchString, String keyWord) {
						
			int cashFlowKeyStart = longestMatchString.indexOf(keyWord);
			String keyTokenString = "";
			if(cashFlowKeyStart>=0 && cashFlowKeyStart+keyWord.length()+2 <= longestMatchString.length()){
				keyTokenString = longestMatchString.substring(cashFlowKeyStart, cashFlowKeyStart+keyWord.length()+2).trim();
			}else if (cashFlowKeyStart>=0 && cashFlowKeyStart+keyWord.length()+1 <= longestMatchString.length()) {
				keyTokenString = longestMatchString.substring(cashFlowKeyStart, cashFlowKeyStart+keyWord.length()+1).trim();	
			}
			return keyTokenString;
		
	}
	
	


}
