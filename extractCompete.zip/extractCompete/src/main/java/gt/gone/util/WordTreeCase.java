package gt.gone.util;

import java.io.FileInputStream;
import java.io.InputStream;

import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;

public class WordTreeCase {
	public static WordTree getClientScaleWordTree() {
		final WordTree wordTree = new WordTree();
		String[] wordsList = { /*
								 * "a large base of", "an extensive database of"
								 * , "a wide variety of","a variety of",
								 * "variety of", "a number of", "large base of",
								 */
				"hundreds of", "High number of", "greatest", "diverse mix of", "Data Base of", "array of",
				"a wide range of", "a long list of", "a large roster of", "a large base of", "multitude of",
				"all manner of", "hundreds of", "a thousand of", "thousands of", "a series of", "series of", "tons of",
				"a ton of", "chains of", "a chain of", "parts of", "a part of", "pieces of", "a piece of", "lots of",
				"a lot of", "a broad range of", "many", "a long list of" };
		for (String word : wordsList) {
			wordTree.addPhrase(word.split("\\s"));
			wordTree.addPhrase(TeamAddAdjectiveUtil.toUpperCaseFirstOne(word).split("\\s"));
		}
		return wordTree;
	}

	public static WordTree getClientGrowWordTree() {
		final WordTree wordTree = new WordTree();
		String[] wordsList = {
				/* "Growing", *//* "up", *//* "is up", "are up", "was up", */
				"find more", "huge potential to expand", "huge potential to increase", "huge potential to grow",
				"increment percent", "growth rates", "growth rate", "enhance", "enhanced", "enhances", "enhancement",
				"grew", "grow", "growing", "grows", "growth", "improve", "improved", "improvement", "improves",
				"improving", "increase", "increased", "increases", "increasing", "has increased", "have increased",
				"has grew", "have grew", "has enhanced", "have enhanced", "has improved", "have improved",
				"increasing to", "growing to", "enhancing to", "improving to", "make improvements to",
				"running back up", "expand" };
		for (String word : wordsList) {
			wordTree.addPhrase(word.split("\\s"));
			wordTree.addPhrase(TeamAddAdjectiveUtil.toUpperCaseFirstOne(word).split("\\s"));
		}
		return wordTree;
	}

	public static WordTree getSteadyClientFeaturesWordTree() {
		final WordTree wordTree = new WordTree();

		String[] wordsList = { "client retention", "client retention rate", "clients retention",
				"clients retention rate", "clientele retention", "clientele retention rate", "clienteles retention",
				"clienteles retention rate", "customer retention", "customer retention rate", "customers retention",
				"customers retention rate", "traditional", "Steady", "solidify", "solid", "established", "fixed",
				"existing", "deep", "secure", "Well-established", "long established", "strong" };
		for (String word : wordsList) {
			wordTree.addPhrase(word.split("\\s"));
			wordTree.addPhrase(TeamAddAdjectiveUtil.toUpperCaseFirstOne(word).split("\\s"));
		}
		return wordTree;
	}

	public static WordTree getLoyalClientFeaturesWordTree() {
		final WordTree wordTree = new WordTree();
		String[] wordsList = {
				/* "Loyal", */
				"returning", "loyalty", "longstanding", "long-standing", "long standing", "long term", "fan", "loyal",
				"regular", "active", "repeat" };
		for (String word : wordsList) {
			wordTree.addPhrase(word.split("\\s"));
			wordTree.addPhrase(TeamAddAdjectiveUtil.toUpperCaseFirstOne(word).split("\\s"));
		}
		return wordTree;
	}

	public static WordTree getHighQualityClientFeaturesWordTree() {
		final WordTree wordTree = new WordTree();
		String[] wordsList = {
				/* "Impressive", */
				"well-known", "larger Fortune", "great reputation", "500 type", "blue-chip", "blue chip", "corporate",
				"large", "impressive", "high-value", "high quality", "high-end", "desirable", "high value", "great",
				"good", "excellent", "astounding", };
		for (String word : wordsList) {
			wordTree.addPhrase(word.split("\\s"));
			wordTree.addPhrase(TeamAddAdjectiveUtil.toUpperCaseFirstOne(word).split("\\s"));
		}
		return wordTree;
	}

	public static WordTree getVariousClientFeaturesWordTree() {
		final WordTree wordTree = new WordTree();
		String[] wordsList = { "widespread", "international", "extensive", "diversified", "diverse", "Broad overall", };
		for (String word : wordsList) {
			wordTree.addPhrase(word.split("\\s"));
			wordTree.addPhrase(TeamAddAdjectiveUtil.toUpperCaseFirstOne(word).split("\\s"));
		}
		return wordTree;
	}

	public static WordTree getWordTreeFromExcel() throws Exception {
		final WordTree wordTree = new WordTree();
		Workbook readwb = null;
		InputStream instream = new FileInputStream(
				"D:\\whh-spaces\\extractCashFlow3\\src\\main\resources\\industry_classification.xls");
		readwb = Workbook.getWorkbook(instream);
		Sheet readsheet = readwb.getSheet(0);
		for (int i = 4; i <= 318; i += 2) {
			Cell cell = readsheet.getCell(7, i);
			wordTree.addPhrase(cell.toString().split("\\s"));
		}
		return wordTree;
	}

	public static WordTree getIndustryWordTree() {
		final WordTree wordTree = new WordTree();

		String[] wordsList = { "automotive", "aerospace", "government", "aerospace", "armament", "optics",
				"performance automotive parts", "aerospace", "nuclear", "motorsports", "defence", "Aerospace", "Rail",
				"Automotive", "Medical", "Pneumatics", "manufacturing", "machinery and equipment",
				"industrial automation", "assembly", "metal cutting equipment", "underground mining", "demining",
				"fire-fighting management", "industrial", "IOT", "fire extinguishing", "mining", "mine clearance",
				"surgery", "automotive", "industrial electronics", "advertisement", "media", "teaching demonstration",
				"exhibition", "film", "television", "steel", "metal", "automotive", "wind energy",
				"civil and military aerospace", "electrical", "mining", "fast food", "automotive", "aerospace",
				"medical", "military", "Military Satellites", "Defense Electronics", "Automotive", "NASA Satellites",
				"International Aerospace", "OEM", "Computers", "Electronic", "Pharmaceuticals", "Cosmetics",
				"Painted Coatings", "Plastics", "Cleaning Supplies", "Food" };
		for (String word : wordsList) {
			wordTree.addPhrase(word.split("\\s"));
			wordTree.addPhrase(TeamAddAdjectiveUtil.toUpperCaseFirstOne(word).split("\\s"));
		}
		return wordTree;
	}

	public static WordTree getMarketGrowWordTree() {
		final WordTree wordTree = new WordTree();

		String[] wordsList = {
				/* "Growth", *//* "up", *//* "is up", "are up", "was up", */
				"expand", "growing", "growth rate", "growth", "increment percent", "growth rates", "growth rate",
				"enhance", "enhanced", "enhances", "enhancement", "enhancing", "grew", "grow", "growing", "grows",
				"growth", "improve", "improved", "improvement", "improves", "improving", "increase", "increased",
				"increases", "increasing", "has increased", "have increased", "has grew", "have grew", "have enhanced",
				"has enhanced", "has improved", "have improved", "increasing to", "growing to", "cenhancing to",
				"improving to", "make improvements to", "running back up" };
		for (String word : wordsList) {
			wordTree.addPhrase(word.split("\\s"));
			wordTree.addPhrase(TeamAddAdjectiveUtil.toUpperCaseFirstOne(word).split("\\s"));
		}
		return wordTree;
	}

	public static WordTree getPotentialWordTree() {
		final WordTree wordTree = new WordTree();

		String[] wordsList = { /* "Potentiality", "Potential" */
				"potentiality", "potential" };
		for (String word : wordsList) {
			wordTree.addPhrase(word.split("\\s"));
			wordTree.addPhrase(TeamAddAdjectiveUtil.toUpperCaseFirstOne(word).split("\\s"));
		}
		return wordTree;
	}

	public static WordTree getBarriersWordTree() {
		final WordTree wordTree = new WordTree();

		String[] wordsList = { "technical barriers", "technical barrier", "barriers-to-entry", "barrier-to-entry",
				"technology barriers", "technology barrier", "barriers of", "barrier of", "barriers to", "barrier to",
				"high barriers", "high barrier", "with barriers", "with barrier", "entry barriers", "entry barrier",
				"barriers for", "barrier for", "competitive barriers", "competitive barrier" };
		for (String word : wordsList) {
			wordTree.addPhrase(word.split("\\s"));
			wordTree.addPhrase(TeamAddAdjectiveUtil.toUpperCaseFirstOne(word).split("\\s"));
		}
		return wordTree;
	}

	public static WordTree getTeamResearchTypeWordTree() {
		final WordTree wordTree = new WordTree();

//		String[] wordsList = {
//				/* "development", */ /* , "technical" */
//				"Developers", "Designers", "research", "planning", "technicians", "R&D", "design", "developers",
//				"project manager", "SEO Team", "content team", "Pay Per Click Team", "web developer"
//
//		};
		String[] wordsList = {"Developers", "Designers", "research", "planning", "technicians", "technical","R&D", "design", "developers","production",
				"project manager", "SEO Team", "content team", "Pay Per Click Team", "web developer"};
		
		for (String word : wordsList) {
			wordTree.addPhrase(word.split("\\s"));
			wordTree.addPhrase(TeamAddAdjectiveUtil.toUpperCaseFirstOne(word).split("\\s"));

		}
		return wordTree;
	}

	public static WordTree getTeamManageTypeWordTree() {
		final WordTree wordTree = new WordTree();

		String[] wordsList = { "management", "operations", "operating", "operation", "MANAGEMENT" };
		for (String word : wordsList) {
			wordTree.addPhrase(word.split("\\s"));
			wordTree.addPhrase(TeamAddAdjectiveUtil.toUpperCaseFirstOne(word).split("\\s"));
		}
		return wordTree;
	}

	public static WordTree getTeamSaleTypeWordTree() {
		final WordTree wordTree = new WordTree();

		String[] wordsList = { "franchise", "sales", "marketing", "retail" };
		for (String word : wordsList) {
			wordTree.addPhrase(word.split("\\s"));
			wordTree.addPhrase(TeamAddAdjectiveUtil.toUpperCaseFirstOne(word).split("\\s"));
		}
		return wordTree;
	}

	public static WordTree getTeamOtherTypeWordTree() {
		final WordTree wordTree = new WordTree();

//		String[] wordsList = {
//				/*
//				 * "adviser team", "Adviser team", "security team",
//				 * "development team", "recruitment team"
//				 */"functioning", "cleaning", "doctors", "advisers", "care", "carpentry", "production", "adviser",
//				"security", "development", "recruitment", "support", "installation", "maintenance", "healthcare",
//				"fitting", "media", "Fine Art", "manufacturing", "racing" };
		
		String[] wordsList = {
		"service","functioning", "cleaning", "doctors", "advisers", "care", "carpentry","adviser",
		"security", "development", "recruitment", "support", "installation", "maintenance", "healthcare","health care"
		,"fitting", "media", "Fine Art", "manufacturing", "racing"};
		for (String word : wordsList) {
			wordTree.addPhrase(word.split("\\s"));
			wordTree.addPhrase(TeamAddAdjectiveUtil.toUpperCaseFirstOne(word).split("\\s"));
		}
		return wordTree;
	}

	public static WordTree getExperienceWordTree() {
		final WordTree wordTree = new WordTree();

		String[] wordsList = {
				/*
				 * "rich experience", "significant experience",
				 * "rich industry experience", "highly experience",
				 * "Fully experience",
				 */
				"established","specialise", "senior", "experienced", "experience", "seasoned", "professionals", "professional"

		};
		for (String word : wordsList) {
			wordTree.addPhrase(word.split("\\s"));
			// 将大写情况也加入词库
			wordTree.addPhrase(TeamAddAdjectiveUtil.toUpperCaseFirstOne(word).split("\\s"));
		}
		return wordTree;
	}

	public static WordTree getCapableWordTree() {
		final WordTree wordTree = new WordTree();

//		String[] wordsList = {
//				/* "Strong", *//* "Talented", "smoothly functioning",*/
//				"specialised","supportive", "elite", "konwledgeable", "great", "specialist", "good", "ambitious", "certified",
//				 "Award Winning", "qualified", "efficient", "outstanding", "superb",
//				"skilled consultants", "scientists", "qualifications", "qualification", "skilled", "technical elites",
//				"professional", "expertise", "trained", "capable", "Strong knowledgeable", "knowledgeable", "strong",
//				"excellent", "mature", "superb", "talented", "competent", "technology-leading", "highly skilled",
//				"skilled", "profound knowledge", "knowledge", "extensive expertise", "famous experts", "educated",
//				"experts", "expert", "skills", "skill" };
		
		String[] wordsList = {
		"growing","knowhow","specialists","specialist","specialized","specialised","supportive", "konwledgeable", "great", "good", "ambitious", "certified",
		"Award Winning", "qualified", "efficient", "outstanding", "superb",
						"consultants", "scientists", "qualifications", "qualification", "skilled", "technical","elites","elite", "expertise", "strong","trained", "capable", "knowledgeable", 
						"excellent", "mature", "superb", "talented", "competent", "technology leading", 
						"knowledge",  "educated",
						"experts", "expert", "skills", "skill"};
		for (String word : wordsList) {
			wordTree.addPhrase(word.split("\\s"));
			wordTree.addPhrase(TeamAddAdjectiveUtil.toUpperCaseFirstOne(word).split("\\s"));
		}
		return wordTree;
	}

	// 单纯的一个数字 表示规模与否
	public static WordTree getScaleWordTree() {
		final WordTree wordTree = new WordTree();

		String[] wordsList = { "large", "a number of", "a high number of", "many" };
		for (String word : wordsList) {
			wordTree.addPhrase(word.split("\\s"));
			wordTree.addPhrase(TeamAddAdjectiveUtil.toUpperCaseFirstOne(word).split("\\s"));
		}
		return wordTree;
	}

	public static WordTree getQualityWordTree() {
		final WordTree wordTree = new WordTree();

//		String[] wordsList = {
//				/*
//				 * "loyal staff" ,
//				 */
//				"tried", "passionate", "Long standing", "enthusiastic", "trusted", "trustworthy", "Long term",
//				"quality", "long standing", "impressive", "dedicated", "stable", "loyal", "well motivated", "motivated",
//				"active", "more aggressive", "solid", "friendly", "educated", "friendly", "cohesive", "cooperative",
//				"long-standing", "dynamic", "vibrant", "performing", "reliable" };
		String[] wordsList = {"disciplinary","superior","longstanding","tried", "passionate", "Long standing","long standing", "enthusiastic", "trusted", "trustworthy", "Long term","long term"
				,"quality", "impressive", "dedicated", "stable", "loyal", "motivated",
				"proactive","active", "aggressive", "solid", "friendly", "educated",  "cohesive", "cooperative",
				"dynamic", "vibrant", "performing", "reliable" };
		for (String word : wordsList) {
			wordTree.addPhrase(word.split("\\s"));
			wordTree.addPhrase(TeamAddAdjectiveUtil.toUpperCaseFirstOne(word).split("\\s"));
		}
		return wordTree;
	}

	public static WordTree getPatentWordTree() {
		final WordTree wordTree = new WordTree();

		String[] wordsList = { "patents", "patented", "patent" };
		for (String word : wordsList) {
			wordTree.addPhrase(word.split("\\s"));
			wordTree.addPhrase(TeamAddAdjectiveUtil.toUpperCaseFirstOne(word).split("\\s"));
		}
		return wordTree;
	}

	public static WordTree getBrandWordTree() {
		final WordTree wordTree = new WordTree();

		String[] wordsList = { "brand", "brands", "branded", "branding" };
		for (String word : wordsList) {
			wordTree.addPhrase(word.split("\\s"));
			wordTree.addPhrase(TeamAddAdjectiveUtil.toUpperCaseFirstOne(word).split("\\s"));
		}
		return wordTree;
	}

}
