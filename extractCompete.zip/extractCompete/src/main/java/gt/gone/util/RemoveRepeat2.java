package gt.gone.util;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.collections.functors.ForClosure;

import gt.gone.model.compete.CompeteExtract;

public class RemoveRepeat2 {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		PrintStream ps;
		ps = new PrintStream(new FileOutputStream("C:\\4w_new.txt"));
		System.setOut(ps);
		String fileTest2 = "C:\\Users\\nlp\\workspace\\extractCashFlow3\\src\\main\\resources\\4w_new.txt";
		CompeteExtract conpeteExtract = new CompeteExtract();
		Set<String> strings = new HashSet<String>();
		ArrayList<String> input = FileUtil.importData(fileTest2);
		for(String string : input)
				strings.add(string);
		for(String string : strings){
			System.out.println(string);
		}

	}

}
