package gt.gone.util;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.HashSet;
import java.util.Set;

import org.apache.commons.collections.functors.ForClosure;

import gt.gone.model.compete.CompeteExtract;

public class RemoveRepeat {

	public static void main(String[] args) throws Exception {
		// TODO Auto-generated method stub
		PrintStream ps;
		ps = new PrintStream(new FileOutputStream("C:\\seller_4w.txt"));
		System.setOut(ps);
		String fileTest2 = "C:\\Users\\nlp\\workspace\\extractCashFlow3\\src\\main\\resources\\seller_4w.txt";
		CompeteExtract conpeteExtract = new CompeteExtract();
		Set<String> strings = new HashSet<String>();
		for (int i = 1; i < 45377; i++) {
			String input = FileUtil.importData(fileTest2, i);
			if (input != null) {
				//String ans = conpeteExtract.extractCompete(input);
				// JsonFormatTool jst = new JsonFormatTool();
				strings.add(input);
				//System.out.println(JsonTool.formatJson(ans, "\t"));
			}
		}
		for(String string : strings){
			System.out.print(string);
		}

	}

}
