package gt.gone.util;

import java.io.*;
import java.lang.reflect.Array;
import java.net.URL;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeSet;


public class Word2VEC {

	
	public static void main(String[] args) throws IOException {
		long startTime=System.currentTimeMillis();   //获取开始时间
        Word2VEC w1 = new Word2VEC() ;
        //w1.loadGoogleModel("library/corpus.bin") ;
       // w1.loadGoogleModel("D:\\Word2vectorData\\PubMed-w2v.bin") ;
        
        w1.loadJavaModel(PropertyUtil.getValue("word2VecPath"));
       
        //System.out.println(w1.distance("love"));
        System.out.println( "components"+" "+"sensors" + "="+ w1.distanceWith2Words("components", "sensors"));
        System.out.println();
        System.out.println("residential"+" "+"commercial" + "="+ w1.distanceWith2Words("residential", "commercial"));
        System.out.println();
        System.out.println("fruits"+" "+"vegetables" + "="+ w1.distanceWith2Words("fruits", "vegetables"));
        System.out.println();
        System.out.println("frames"+" "+"panels" + "="+ w1.distanceWith2Words("frames", "panels"));
        System.out.println();
        System.out.println("civil"+" "+"military" + "="+ w1.distanceWith2Words("civil", "military"));
        System.out.println();
        System.out.println("programs"+" "+"prototype" + "="+ w1.distanceWith2Words("programs", "prototype"));
        System.out.println();
        System.out.println("robots"+" "+"related" + "="+ w1.distanceWith2Words("robots", "related"));
        System.out.println();
        System.out.println("travel"+" "+"lifts" + "="+ w1.distanceWith2Words("hot", "cold"));
        System.out.println();
        System.out.println("love"+" "+"hate" + "="+ w1.distanceWith2Words("love", "hate"));
        System.out.println();
        System.out.println("glass"+" "+"frame" + "="+ w1.distanceWith2Words("new", "brand"));
        System.out.println();
       
        long endTime=System.currentTimeMillis(); //获取结束时间
        
        System.out.println("程序运行时间： "+(endTime-startTime)/1000.0+"s");
		
	}
	
	public Word2VEC(String word2VecPath) {
		// TODO Auto-generated constructor stub
		try {
			this.loadJavaModel(word2VecPath);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	
	public Word2VEC() {
		// TODO Auto-generated constructor stub
	}


	public static HashMap<String, float[]> wordMap = new HashMap<String, float[]>();

	private int words;
	private int size;
	private int topNSize = 40;

	/**
	 * 加载模型
	 * 
	 * @param path
	 *            模型的路径
	 * @throws IOException
	 */
	public void loadGoogleModel(String path) throws IOException {
		DataInputStream dis = null;
		BufferedInputStream bis = null;
		double len = 0;
		float vector = 0;
		ClassLoader classLoader = Word2VEC.class.getClassLoader();  
	    FileInputStream in = (FileInputStream)classLoader.getResourceAsStream(path);
	   
		try {
			bis = new BufferedInputStream(in/*new FileInputStream(path)*/);
			dis = new DataInputStream(bis);
			// //读取词数
			words = Integer.parseInt(readString(dis));
			// //大小
			size = Integer.parseInt(readString(dis));
			String word;
			float[] vectors = null;
			for (int i = 0; i < words; i++) {
				word = readString(dis);
				vectors = new float[size];
				len = 0;
				for (int j = 0; j < size; j++) {
					vector = readFloat(dis);
					len += vector * vector;
					vectors[j] = (float) vector;
				}
				len = Math.sqrt(len);

				for (int j = 0; j < size; j++) {
					vectors[j] /= len;
				}

				wordMap.put(word, vectors);
				dis.read();
			}
		} finally {
			bis.close();
			dis.close();
		}
	}
	
	public static double distanceWith2Words(String word1 , String word2){ 
		if(!(wordMap.containsKey(word1)&&wordMap.containsKey(word2))){
			return 0;
		}
        float[] center1 = wordMap.get(word1);  
        float[] center2 = wordMap.get(word2);
       /* System.out.print(word1+"=");
        for (int i = 0; i < center1.length; i++) {  
            System.out.print(center1[i]+", "); 
        }
        System.out.println();
        System.out.print(word2+"=");
        for (int i = 0; i < center2.length; i++) {  
            System.out.print(center2[i]+", "); 
        }*/
        double dics = 0;  
        for (int i = 0; i < center1.length; i++) {  
            dics += center1[i] * center2[i];  
        }  
       // System.out.println(word1+" "+word2+"="+dics);
        return dics;  
    }  

	/**
	 * 加载模型
	 * 
	 * @param path
	 *            模型的路径
	 * @throws IOException
	 */
	public void loadJavaModel(String path) throws IOException {		
		//ClassLoader classLoader = Word2VEC.class.getClassLoader();      
	    //FileInputStream in = (FileInputStream)classLoader.getResourceAsStream(path);
	    
		try (DataInputStream dis = new DataInputStream(new BufferedInputStream(new FileInputStream(path)))) {
			words = dis.readInt();
			size = dis.readInt();
			float vector = 0;

			String key = null;
			float[] value = null;
			for (int i = 0; i < words; i++) {
				double len = 0;
				key = dis.readUTF();
				value = new float[size];
				for (int j = 0; j < size; j++) {
					vector = dis.readFloat();
					len += vector * vector;
					value[j] = vector;
				}

				len = Math.sqrt(len);

				for (int j = 0; j < size; j++) {
					value[j] /= len;
				}
				wordMap.put(key, value);
			}

		}
	}

	private static final int MAX_SIZE = 50;


	

	

	
	private float[] sum(float[] center, float[] fs) {
		// TODO Auto-generated method stub

		if (center == null && fs == null) {
			return null;
		}

		if (fs == null) {
			return center;
		}

		if (center == null) {
			return fs;
		}

		for (int i = 0; i < fs.length; i++) {
			center[i] += fs[i];
		}

		return center;
	}

	/**
	 * 得到词向量
	 * 
	 * @param word
	 * @return
	 */
	public float[] getWordVector(String word) {
		return wordMap.get(word);
	}

	public static float readFloat(InputStream is) throws IOException {
		byte[] bytes = new byte[4];
		is.read(bytes);
		return getFloat(bytes);
	}

	/**
	 * 读取一个float
	 * 
	 * @param b
	 * @return
	 */
	public static float getFloat(byte[] b) {
		int accum = 0;
		accum = accum | (b[0] & 0xff) << 0;
		accum = accum | (b[1] & 0xff) << 8;
		accum = accum | (b[2] & 0xff) << 16;
		accum = accum | (b[3] & 0xff) << 24;
		return Float.intBitsToFloat(accum);
	}

	/**
	 * 读取一个字符串
	 * 
	 * @param dis
	 * @return
	 * @throws IOException
	 */
	private static String readString(DataInputStream dis) throws IOException {
		// TODO Auto-generated method stub
		byte[] bytes = new byte[MAX_SIZE];
		byte b = dis.readByte();
		int i = -1;
		StringBuilder sb = new StringBuilder();
		while (b != 32 && b != 10) {
			i++;
			bytes[i] = b;
			b = dis.readByte();
			if (i == 49) {
				sb.append(new String(bytes));
				i = -1;
				bytes = new byte[MAX_SIZE];
			}
		}
		sb.append(new String(bytes, 0, i + 1));
		return sb.toString();
	}

	public int getTopNSize() {
		return topNSize;
	}

	public void setTopNSize(int topNSize) {
		this.topNSize = topNSize;
	}

	public HashMap<String, float[]> getWordMap() {
		return wordMap;
	}

	public int getWords() {
		return words;
	}

	public int getSize() {
		return size;
	}

}
