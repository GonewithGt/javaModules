package gt.gone.util;

//判断某个匹配是否满足句法
public class ConfusedExpUtil {
	
	public static  int countWordNum(String matchedStr){
		String[] tokens = matchedStr.split(" ");	
		return tokens.length;
	}
	
	
	//判断改变类型的词是否修饰中心词
	//经过观察 抽取错误主要在于matchedSent中修饰词和keyword之间有转折
	public static boolean isRightChangeSentence(String matchedSent, String keyword) {
		if(matchedSent.contains("#变化") && matchedSent.contains(keyword)){
			int changeStart = matchedSent.indexOf("#变化");
			int changeEnd = matchedSent.indexOf("#变化")+"#变化".length()+2;
			int keywordStart = matchedSent.indexOf(keyword);
			int keywordEnd = matchedSent.indexOf(keyword)+keyword.length()+2;
			if (changeEnd < keywordStart) {
				String middleStr = matchedSent.substring(changeEnd, keywordStart).trim().toLowerCase();
				//System.out.println(middleStr);
				if(middleStr.startsWith("and ")||middleStr.equals("and")||middleStr.equals(",")||middleStr.endsWith(" and")){
					return false;
				}
				
				if(middleStr.contains(" and ") && countWordNum(middleStr) > 2
						&& !middleStr.contains(" and #周期")){
					return false;
				}
				
				return  true;
			}else if (keywordEnd < changeStart) {
				String middleStr = matchedSent.substring(keywordEnd, changeStart).trim().toLowerCase();
				if(middleStr.endsWith(" and")||middleStr.equals("and")||middleStr.equals(",")
						||matchedSent.contains("make #变化")){
					return false;
				}	
				if(middleStr.contains(" and ") && countWordNum(middleStr) > 2
						&& !middleStr.contains(" and #周期")
						){
					return false;
				}
				
				return  true;
			}
			
			return true;
			
		}
		
		
		return true;
		
	}
	
	public static boolean isRightXiuShiSentence(String matchedSent, String keyword) {
		if(matchedSent.contains("#定性描述词") && matchedSent.contains(keyword)){
			int changeStart = matchedSent.indexOf("#定性描述词");
			int changeEnd = matchedSent.indexOf("#定性描述词")+"#定性描述词".length()+2;
			int keywordStart = matchedSent.indexOf(keyword);
			int keywordEnd = matchedSent.indexOf(keyword)+keyword.length()+2;
			if (changeEnd < keywordStart) {
				String middleStr = matchedSent.substring(changeEnd, keywordStart).trim().toLowerCase();
				//System.out.println(middleStr);
				if(middleStr.contains(" which ")){
					return false;
				}
							
				return  true;
			}else if (keywordEnd < changeStart) {
				
				
				return  true;
			}
			
			return true;
			
		}
		
		
		return true;
		
	}

}
