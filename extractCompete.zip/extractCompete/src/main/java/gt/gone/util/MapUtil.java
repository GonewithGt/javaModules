package gt.gone.util;

import java.awt.Point;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

public class MapUtil {
	//按照point指示的位置长短进行排序排序
	public static LinkedHashMap<Point , Object> getOrder(Map<Point , Object> map){
		LinkedHashMap<Point, Object> newMap = new LinkedHashMap<Point, Object>();
		List< Map.Entry<Point , Object> > mapList = new ArrayList< Map.Entry<Point , Object> >(map.entrySet());
		Collections.sort(mapList, new Comparator< Map.Entry<Point , Object> >(){

			@Override
			public int compare(Entry<Point, Object> o1,
					Entry<Point, Object> o2) {
				// TODO Auto-generated method stub
				Point p1 = (Point)o1.getKey();
				Point p2 = (Point)o2.getKey();
				return (p2.y - p2.x) - (p1.y- p1.x);
				//return 0;
			}
			
		});
		for(Map.Entry<Point , Object> entity: mapList){
			newMap.put(entity.getKey(), entity.getValue());
		}
		return newMap;
	}

}
