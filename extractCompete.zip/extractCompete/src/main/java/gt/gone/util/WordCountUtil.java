package gt.gone.util;

public class WordCountUtil {
	
	public static  int countEntityNum(String matchedStr){
		String[] tokens = matchedStr.split(" ");
		int count=0;
		for(String token:tokens){
			if(token.trim().startsWith("#")){
				count++;
			}
		}
		return count;
	}
	
	public static  int countTargetEntityNum(String matchedStr, String target){
	
		String[] tokens = matchedStr.split(" ");
		int count=0;
		for(String token:tokens){
			if(token.contains(target)){
				count++;
			}
		}
		return count;
	}
	
	public static  int countWordNum(String matchedStr){
		String[] tokens = matchedStr.split(" ");
		int tokenLength = tokens.length;
		if(tokenLength > 2){
			int start = 0;
			int end = tokenLength;
			for(start = 0 ; start < tokenLength; start++){
				if(tokens[start].trim().startsWith("#")){
					break;
				}
			}
			
			for(end = tokenLength-1 ; end >= 0; end--){
				if(tokens[end].trim().startsWith("#")){
					break;
				}
			}
			
			return (end-start)+1;
		}else{
			return tokenLength;
		}
	}
	
	public static  boolean isContainKeyWord(String sentenceString){
		sentenceString = sentenceString.toLowerCase();
		if(sentenceString.contains("cash")
				||sentenceString.contains("flow")
				||sentenceString.contains("ebit")
				||sentenceString.contains("profit")
				||sentenceString.contains("margin")
				||sentenceString.contains("revenue")
				||sentenceString.contains("sales")
				||sentenceString.contains("income")
				||sentenceString.contains("turnover")
				||sentenceString.contains("turn over")
				||sentenceString.contains("turning over")
				||sentenceString.contains(" sde ")
				||sentenceString.contains(" gp ")
				||sentenceString.contains("business")
				||sentenceString.contains("the disposable")
				||sentenceString.contains("fees")
				||sentenceString.trim().startsWith("priced at")
				||sentenceString.contains(" has sold ")
				||sentenceString.contains("asking price")
				){
			return true;
		}		
		return false;
	}
	
	
	public static void main(String[] args){
		String teString = "abcdefg";
		System.out.println(teString.lastIndexOf("cbf"));
		System.out.println(teString.indexOf("def"));
		System.out.println("我爱你".length());
	}

}
