package gt.gone.util;

import java.text.NumberFormat;
import java.text.ParseException;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class PercentUtil {
	
	public static float percentToFloat(String percentStr){
		NumberFormat nf=NumberFormat.getPercentInstance();
		try {
			Number m=nf.parse(percentStr.replaceAll("\\s", ""));
			return m.floatValue();
		} catch (ParseException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			System.out.println("百分数不合法");
		}
	
		return 0;
	}
	
	public static String percentToFloatStr(String percentStr){
		String houzui = "";
		if(percentStr.trim().endsWith("+")&&percentStr.length()>1){
			percentStr = percentStr.substring(0,percentStr.length()-1);
			houzui = "+";
		}
		
		if(percentStr.contains("-")){
			int posOfSplit = percentStr.indexOf("-");
			String leftStr = percentStr.substring(0,posOfSplit);
			
			if(percentStr.length() > posOfSplit+1){
				String rightFloatStr = percentStr.substring(percentStr.indexOf("-")+1);
				if(!leftStr.contains("%")){
					leftStr = leftStr.trim()+"%";
				}
				return  percentToFloat(leftStr)+"-"+percentToFloat(rightFloatStr)+houzui;
			}else{
				System.out.println("百分数不合法");
				return "";
			}	
		}else{
			return new Float(percentToFloat(percentStr)).toString()+houzui;
		}
		
	}
	
public static ArrayList<String> percentToFloatStr(ArrayList<String> percentStrList){
		
		ArrayList<String> result = new ArrayList<String>();
		for(String percentStr : percentStrList){
			result.add(percentToFloatStr(percentStr));
		}
		
		return result;
		
	}

public static String getPercentNumStr(String oldStr,PatternUtil pu, XmlUtil xml){
	String cashflow = "预计达到";
	String regex = pu.templateToRegex(cashflow,xml.conceptMap).getReg()/*+"|"+pu.templateToRegex("现金流",xml.conceptMap).getReg()*/; //+"|"+ moneyTypeKeyWord;
	//System.out.println(regex);
	Pattern pattern = Pattern.compile(regex.toLowerCase());
	Matcher matcher = pattern.matcher(oldStr.toLowerCase());
	if(matcher.find()){
		return oldStr.replaceAll(oldStr.substring(matcher.start(),matcher.end()), "");
	}
	
	return oldStr;
}
	
	
	public static void main(String[] args){
		System.out.println(percentToFloatStr("35.2 %+"));
	}
	
	

}
