package gt.gone.util;

import java.util.LinkedHashMap;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

//改变类
public class ChangeUtil {
	//变化类型 分为INCREASE STABLE
	public static String extractChangeType(String oldChar) {
		if (oldChar.toLowerCase().contains("enhance") || oldChar.toLowerCase().contains("grow")
				|| oldChar.toLowerCase().contains("improv") || oldChar.toLowerCase().contains("increas")|| oldChar.toLowerCase().contains("up"))
			return "INCREASE";
		else if (oldChar.toLowerCase().contains("steadily")){
			return "STABLE";
		}
		return null;
	}
	//抽取变化率
	public static String extractChangeRate(String oldChar,LinkedHashMap<String,String> regexs) {
		/*if (oldChar.toLowerCase().contains("%"))
			return oldChar.split(" ")[oldChar.split(" ").length-1];*/
		String baifenbi = "百分比";
		String regex = regexs.get(baifenbi);
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(oldChar);
		if(matcher.find()){
			return matcher.group(0);
		}
		
		return null;
	}
	//抽取变化量
	public static String extractChangeQuatity(String oldChar,LinkedHashMap<String,String> regexs) {

	/*	if (oldChar.toLowerCase().contains("€")
				||oldChar.toLowerCase().contains("Dhs")
				||oldChar.toLowerCase().contains("pounds")
				|oldChar.toLowerCase().contains("$")
				|oldChar.toLowerCase().contains("USD")
				)
			return oldChar.split(" ")[oldChar.split(" ").length-1];*/
		String moneyRange = "钱数范围";
		//String regex = pu.toRegex(xml.conceptMap).get(moneyRange);
		String regex = regexs.get(moneyRange);
		Pattern pattern = Pattern.compile(regex);
		Matcher matcher = pattern.matcher(oldChar);
		if(matcher.find()){
			return matcher.group(0);
		}else{
			String moneyExpre = "钱数";
			//String regex = pu.toRegex(xml.conceptMap).get(moneyRange);
			String moneyExpreRegex = regexs.get(moneyExpre);
			Pattern moneyExprePattern = Pattern.compile(moneyExpreRegex);
			Matcher moneyExprematcher = moneyExprePattern.matcher(oldChar);
			if(moneyExprematcher.find()){
				return moneyExprematcher.group(0);
			}
		}
		return null;
	}
	
	
	
	
	public static String extractChangeQuatity(String oldChar) {

		if (oldChar.toLowerCase().contains("€")
				||oldChar.toLowerCase().contains("Dhs")
				||oldChar.toLowerCase().contains("pounds")
				|oldChar.toLowerCase().contains("$")
				|oldChar.toLowerCase().contains("USD")
				)
			return oldChar.split(" ")[oldChar.split(" ").length-1];
		return null;
	}

}
