package gt.gone.util;

import org.apache.commons.io.filefilter.AgeFileFilter;

public class MatchTemplateUtil {
	
	// with 短语 时间的问题，可能时间会在with短语之前
	public static String selectWithPhraseWithTime(String input, int withPos){
		String beforeWithString = input.substring(0,withPos);
		String afterWithString = input.substring(withPos);
		System.out.println(beforeWithString);
		int timePosInBeforeWithString = beforeWithString.lastIndexOf("#时间");
		if((!afterWithString.contains("#时间")|afterWithString.indexOf("#时间")> afterWithString.indexOf(", "))&& timePosInBeforeWithString >= 0){
			afterWithString = beforeWithString.substring(timePosInBeforeWithString , timePosInBeforeWithString+"#时间".length()+2).trim()
					+" "+afterWithString 
					;
			
			if(afterWithString.contains(" and ")){
				afterWithString = 
						afterWithString +" "+ beforeWithString.substring(timePosInBeforeWithString , timePosInBeforeWithString+"#时间".length()+2).trim()
						;
			}
		}
		
		
		
		//System.out.println(afterWithString);
		return afterWithString;
	}
	
	
	// with 短语 时间的问题
		public static String selectAndPhraseWithTime(String input, int andPos){
			String beforeAndString = input.substring(0,andPos);
			String afterAndString = input.substring(andPos);
			int timePosInBeforeAndString = beforeAndString.lastIndexOf("#时间");
			if(!afterAndString.contains("#时间")&& timePosInBeforeAndString >= 0){
				afterAndString =  beforeAndString.substring(timePosInBeforeAndString , timePosInBeforeAndString+"#时间".length()+2).trim()
						 
						+" "+ afterAndString;
			}
			
			return afterAndString;
		}

}
