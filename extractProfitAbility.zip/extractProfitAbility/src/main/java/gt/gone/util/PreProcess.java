package gt.gone.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class PreProcess {
//	public static String preProcess(String str) {
//		return str.replaceAll("\\.|,|!|\\?|\"|\\|/", " ");
//	}
	public static String competeTeamPreProcess(String str) {
		return str.replaceAll("no experience|many years|•", " ").replace("\\n", "\\n ")
				.replaceAll("\\?|!", " .").replace(",", " ,")
				.replace("\"", " \"").replace("\\", " \\").replace("/", " /")
				.replace(".", " .").replace("-", " ");
	}
	
	public static String preProcess(String str) {
		return str.replaceAll(", |\"|\\|/", " ").replaceAll("\\.|\\?|!", " .");
	}
	
	public static String preProcessForRule(String str) {
		//return str.replaceAll("\\?|\"|\t|\\t|\\|/|<BR>|\\(|\\•", " ");\\r
		return str.replaceAll("\\?|\"|<b>|<\\/b>|<\\\\/b>|/|\\t|\\\\t|\\n|\\\\n|\\r|\\\\r|<BR>|\\(|\\)|•|\\\\|'| - |- | -| – |– | –|&|=|“|”|<\\/strong>|<strong>|@", " ").replaceAll(":", " :");
	}
	
	public static String[] splitInput(String input){
		return input.split("\\?|!|\\t|\\\\t|\\r|\\\\r|\\n|\\\\n|<BR>|•|\\\\|\\. |; |\\. |; ");
	}
	
	//Yearly Revenue: $2,020,740 Yearly Cash Flow: $234,744
	//规避抽取$2,020,740 Yearly Cash Flow这种情形
	//判断是否被冒号包围
	//规避 Good profits are made on sales of over £400,000 这种情形
	public static boolean isCollectedByMaohao(String sentence, String matchedSentence) {
		//System.out.println(sentence);
		//System.out.println(matchedSentence);
		
		//规避这种情形 #收入2 and #钱数6
				//规避这种情形 income streams which have enhanced the business 
				//annual turnover in the vicinity £200,000 and enviable gross margins of roughly 40%
				//Sales area 4M x 9M
				matchedSentence = matchedSentence.replaceAll("\\d", "").toLowerCase();
				sentence = sentence.replaceAll("\\d", "").toLowerCase();
				//System.out.println(sentence);
				if(matchedSentence.contains(" and  #钱数")
						||matchedSentence.contains("#钱数 and ")
						||matchedSentence.contains(" which have  #变化")
						||matchedSentence.contains(" which has  #变化")
						||matchedSentence.contains(" which  #变化")
						||matchedSentence.contains(" through a  #定性描述词")
						||sentence.contains("#收入  area ")
						||sentence.contains("#收入  force ")
						||sentence.contains("#收入  price ")
						||sentence.contains("#收入  team")
						||sentence.contains(" make  #变化")
						||sentence.contains(" made  #变化")
						||sentence.contains(" making  #变化")
						||matchedSentence.contains("based on  #钱数")
						||matchedSentence.contains("#钱数   gallons")
						||matchedSentence.contains("sales of  #钱数")
						||matchedSentence.contains(" and ") && matchedSentence.indexOf("#钱数")< matchedSentence.indexOf(" and ")
						||matchedSentence.contains(" plus ") && matchedSentence.indexOf("#钱数")< matchedSentence.indexOf(" plus ")

						){
					return true;
				}
				
		if(matchedSentence.trim().startsWith("#钱数")){
			int moneyIndex = sentence.indexOf(matchedSentence);
		//	System.out.println(sentence.charAt(moneyIndex-1));
		//	System.out.println(sentence.charAt(moneyIndex-2));
			if(moneyIndex > 0&&sentence.charAt(moneyIndex-1)==':'|| moneyIndex > 1&&sentence.charAt(moneyIndex-2)==':'){
				int lastMatchedCharIndex = moneyIndex + matchedSentence.length() ;
			//	System.out.println(sentence.charAt(lastMatchedCharIndex));
			//	System.out.println(sentence.charAt(lastMatchedCharIndex + 1));
			//	System.out.println(sentence.charAt(lastMatchedCharIndex + 2));
				if(lastMatchedCharIndex< sentence.length() && sentence.charAt(lastMatchedCharIndex)==':'
						||lastMatchedCharIndex + 1< sentence.length() && sentence.charAt(lastMatchedCharIndex + 1)==':'
						||lastMatchedCharIndex + 2< sentence.length() && sentence.charAt(lastMatchedCharIndex + 2)==':'){
					//System.out.println("abc");
					return true;
				}
				
			}
			
			
			
		}
		
		
		
		
		
		return false;
	}
	
	
	public static Map<String , Object> getKeySentencesMap(String input, 
			String cashFlowRegex, String ebitdaRegex, 
			String profitMarginRegex, String revenueRegex){
		Map<String , Object> categoryToSentencesMap = new HashMap<String , Object>();
		ArrayList<String> cashFlowSentenceStrings = new ArrayList<String>();
		ArrayList<String> ebidtaSentenceStrings = new ArrayList<String>();
		ArrayList<String> profitMarginSentenceStrings = new ArrayList<String>();
		ArrayList<String> revenueSentenceStrings = new ArrayList<String>();
		StringBuilder cashFlowSb = new StringBuilder();
		StringBuilder ebitdaSb = new StringBuilder();
		StringBuilder profitMarginSb = new StringBuilder();
		StringBuilder revenueSb = new StringBuilder();
		String[] inputStrs = splitInput(input);
		
		for(int i = 0 ; i < inputStrs.length ; i++){
			String inputStr = new String();
			inputStr = inputStrs[i];
			if(TestDataUtil.isIrregularStopSign(inputStrs[i]) && (i+1 < inputStrs.length)){
				inputStr = inputStrs[i]+". "+ inputStrs[i+1];
				i++;
			}
			
			//System.out.println("inputStr===>"+inputStr);
			
			if(TestDataUtil.isContainedKeyWord(inputStr, cashFlowRegex)){
				
			//	System.out.println("cashFlow===>"+cashFlowRegex);
				cashFlowSb.append(inputStr).append(". ");
			}
			
			if(TestDataUtil.isContainedKeyWord(inputStr, ebitdaRegex)){
			//	System.out.println("ebitdaRegex===>"+ebitdaRegex);
				ebitdaSb.append(inputStr).append(". ");
			}
			
			if(TestDataUtil.isContainedKeyWord(inputStr, profitMarginRegex)){
			//	System.out.println("profitMarginRegex===>"+profitMarginRegex);
				profitMarginSb.append(inputStr).append(". ");
			}
			
			if(TestDataUtil.isContainedKeyWord(inputStr, revenueRegex)){
			//	System.out.println("revenueRegex===>"+revenueRegex);
				revenueSb.append(inputStr).append(". ");
			}
			
		}
		
		categoryToSentencesMap.put("cashFlowSens", cashFlowSb.toString());
		categoryToSentencesMap.put("ebitdaSens", ebitdaSb.toString());
		categoryToSentencesMap.put("profitMarginSens", profitMarginSb.toString());
		categoryToSentencesMap.put("revenueSens", revenueSb.toString());
		
		return categoryToSentencesMap;
	}
	
	public static String getKeySentences(String input, 
			String targetEntityRegex){
		
		StringBuilder cashFlowSb = new StringBuilder();
		
		String[] inputStrs = splitInput(input);
		
		for(int i = 0 ; i < inputStrs.length ; i++){
			String inputStr = new String();
			inputStr = inputStrs[i];
			if(TestDataUtil.isIrregularStopSign(inputStrs[i]) && (i+1 < inputStrs.length)){
				if(inputStrs[i].endsWith(" excl")||inputStrs[i].endsWith(" incl")){ // excl. VAT
					inputStr = inputStrs[i]+" "+ inputStrs[i+1];
				}else{
					inputStr = inputStrs[i]+". "+ inputStrs[i+1];
				}
				
				i++;
			}
			
			if(TestDataUtil.isContainedKeyWord(inputStr, targetEntityRegex)){
				cashFlowSb.append(inputStr).append(". ");
			}
						
		}
		
		System.out.println(cashFlowSb.toString());
		return cashFlowSb.toString();
	}
	
	
	

	
	

	public static void main(String[] args){
		String input = "abc\tabc/de?(abc<BR>abc-abc)efg\\abc\\nabc\ndef\"defgh\\t\\n\\t\\ngggg. tttt'bbb<b>abc<\\/b>ddd!bc; lllvv";
		System.out.println(preProcessForRule(input));
		String[] inputs = splitInput(input);//input.split("\\?|\"|/|\\t|\\\\t|\\n|\\\\n|<BR>|\\(|\\)|•|\\\\|\\. ");
		System.out.println(inputs.length);
		for(String str: inputs){
			System.out.println(str);
		}
	}

}
