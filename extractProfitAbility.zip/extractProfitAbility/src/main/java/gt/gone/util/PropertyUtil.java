package gt.gone.util;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Properties;

import javax.swing.JOptionPane;

import org.apache.commons.io.ByteOrderMark;
import org.apache.commons.io.input.BOMInputStream;


public class PropertyUtil {
	final static String filePath = "src/main/resources/properties/conf.properties";
	//static String profileName = "conf.properties";
	private static Properties props = new Properties();
	public static String getValue(String key){
		try {
			File file = new File(filePath);
			//InputStream inputStream = getClass().getResourceAsStream(arg0);
			InputStreamReader inputStreamReader = null;
			if(file.exists()){
				FileInputStream fis = new FileInputStream(file);
				// 可检测多种类型，并剔除bom
				BOMInputStream bomIn = new BOMInputStream(fis, false, ByteOrderMark.UTF_8, ByteOrderMark.UTF_16LE,
						ByteOrderMark.UTF_16BE);
				String charset = "utf-8";
				// 若检测到bom，则使用bom对应的编码
				if (bomIn.hasBOM()) {
					charset = bomIn.getBOMCharsetName();
				}
				inputStreamReader = new InputStreamReader(bomIn,charset);
			}else{
				JOptionPane.showMessageDialog(null, "配置文件路径错误");
			}
			props.load(inputStreamReader);
			
		} catch (Exception e) {
			// TODO: handle exception
		}
		
		return (String)props.get(key);
	}
	
	public static void main(String[] args) {
		System.out.println(PropertyUtil.getValue("compete.input"));
	}

}
