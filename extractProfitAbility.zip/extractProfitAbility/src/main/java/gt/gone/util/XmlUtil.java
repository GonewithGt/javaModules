package gt.gone.util;

import gt.gone.model.common.Intention;
import gt.gone.model.common.Template;

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import net.sf.json.JSONObject;

import org.dom4j.Document;
import org.dom4j.Element;
import org.dom4j.io.SAXReader;



public class XmlUtil {
	public List<Intention> intentionList = new ArrayList<Intention>();
	public LinkedHashMap<String, List<String>> conceptMap = new LinkedHashMap<String, List<String>>();
	/**
	 * @description：初始化intentionList和conceptMap
	 * @param filename 文本名字，位置放在resources目录下，需要xml文件
	 */
	/*public XmlUtil(String filename){
		SAXReader saxReader = new SAXReader();
//		InputStream in = XmlUtil.class.getClassLoader().getResourceAsStream(filename);
//		InputStream in = new FileInputStream("");
		try {
		     //InputStream in = new FileInputStream(filename);
			 ClassLoader classLoader = XmlUtil.class.getClassLoader();  
		        //URL resource = classLoader.getResource("test.xml");  
		       // String path = resource.getPath();  
		        //System.out.println(path);  
		    InputStream in = classLoader.getResourceAsStream(filename);  
		        
			Document document = saxReader.read(in);
			Element rootEle = document.getRootElement();
			Element concepthead = rootEle.element("concepts");
			if(concepthead != null){
				List<Element> conceptEles = concepthead.elements("concept");
//				System.out.println(conceptList.size());
				if(conceptEles != null && conceptEles.size()>0){
					for(Element conceptEle : conceptEles){
						String conceptName = conceptEle.attributeValue("name").trim();
//						System.out.println(conceptName);
						String keywords = conceptEle.getText();
						String temkeyword[] = keywords.split(", ");
						List<String> keywordList = new ArrayList<String>();
						for(String keyword: temkeyword){
							if(keyword.equals("#空格"))
								keyword = " ";
							keywordList.add(keyword);
						}
						
						Collections.sort(keywordList, new Comparator<String>() {
							//@Override
							public int compare(String s1, String s2){
								return s2.length() - s1.length();
							}
						});
				//		System.out.println(keywordList);
						this.conceptMap.put(conceptName, keywordList);
					}

				}
			}
			List<Element> intentionEles = rootEle.elements("intentionAdd");
//			System.out.println(intentionEles.size());
			if(intentionEles != null && intentionEles.size() > 0){
			//	System.out.println("intention a");
				for(Element intentionEle : intentionEles){
					String intentionname = intentionEle.attributeValue("name");
					
					String intentionid = intentionEle.attributeValue("id");
					
					List<Element> templateEles = intentionEle.elements("template");
					List<Template> templates = new ArrayList<Template>();
					
					if(templateEles != null && templateEles.size() > 0){
				//		System.out.println("intention test B");
						for(Element templateEle : templateEles){
							String templatename = templateEle.attributeValue("name");
							
							String templatetext = templateEle.getText();
							
							templates.add(new Template(templatename, templatetext));
							
						}
					}
					this.intentionList.add(new Intention(intentionname, intentionid, templates));
					//System.out.println(intentionList);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.err.println(e);
		}
		
	}*/
	
	public XmlUtil(String databaseName, String docName, String filename){
		SAXReader saxReader = new SAXReader();
//		InputStream in = XmlUtil.class.getClassLoader().getResourceAsStream(filename);
//		InputStream in = new FileInputStream("");
		try {
		     //InputStream in = new FileInputStream(filename);
			 ClassLoader classLoader = XmlUtil.class.getClassLoader();  
		        //URL resource = classLoader.getResource("test.xml");  
		       // String path = resource.getPath();  
		        //System.out.println(path);  
		    InputStream in = classLoader.getResourceAsStream(filename);  
		        
			Document document = saxReader.read(in);
			Element rootEle = document.getRootElement();
			this.conceptMap = MongoDBUtil.getConceptHashMapFromMongoDB(databaseName, docName);
			List<Element> intentionEles = rootEle.elements("intentionAdd");
//			System.out.println(intentionEles.size());
			if(intentionEles != null && intentionEles.size() > 0){
			//	System.out.println("intention a");
				for(Element intentionEle : intentionEles){
					String intentionname = intentionEle.attributeValue("name");
					
					String intentionid = intentionEle.attributeValue("id");
					
					List<Element> templateEles = intentionEle.elements("template");
					List<Template> templates = new ArrayList<Template>();
					
					if(templateEles != null && templateEles.size() > 0){
				//		System.out.println("intention test B");
						for(Element templateEle : templateEles){
							String templatename = templateEle.attributeValue("name");
							
							String templatetext = templateEle.getText();
							
							templates.add(new Template(templatename, templatetext));
							
						}
					}
					this.intentionList.add(new Intention(intentionname, intentionid, templates));
					//System.out.println(intentionList);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.err.println(e);
		}
	}
	/*public XmlUtil(String filename, String mongoDBName){
		SAXReader saxReader = new SAXReader();
//		InputStream in = XmlUtil.class.getClassLoader().getResourceAsStream(filename);
//		InputStream in = new FileInputStream("");
		try {
		     //InputStream in = new FileInputStream(filename);
			 ClassLoader classLoader = XmlUtil.class.getClassLoader();  
		        //URL resource = classLoader.getResource("test.xml");  
		       // String path = resource.getPath();  
		        //System.out.println(path);  
		    InputStream in = classLoader.getResourceAsStream(filename);  
		        
			Document document = saxReader.read(in);
			Element rootEle = document.getRootElement();
			
			
			
			List<Element> intentionEles = rootEle.elements("intentionAdd");
//			System.out.println(intentionEles.size());
			if(intentionEles != null && intentionEles.size() > 0){
			//	System.out.println("intention a");
				for(Element intentionEle : intentionEles){
					String intentionname = intentionEle.attributeValue("name");
					
					String intentionid = intentionEle.attributeValue("id");
					
					List<Element> templateEles = intentionEle.elements("template");
					List<Template> templates = new ArrayList<Template>();
					
					if(templateEles != null && templateEles.size() > 0){
				//		System.out.println("intention test B");
						for(Element templateEle : templateEles){
							String templatename = templateEle.attributeValue("name");
							
							String templatetext = templateEle.getText();
							
							templates.add(new Template(templatename, templatetext));
							
						}
					}
					this.intentionList.add(new Intention(intentionname, intentionid, templates));
					//System.out.println(intentionList);
				}
			}
		} catch (Exception e) {
			// TODO: handle exception
			System.err.println(e);
		}
		
	}
		
	}*/
	
	
	
	public static void main(String[] args){
		/*// TODO Auto-generated method stub
		/*XmlUtil xml = new XmlUtil("Company_key_word.xml");
		String regex = "(very|extremely|highly)? nice[\\s]*|(very|extremely|highly)? great[\\s]*\\d*(~|-)";
		String regex2 = "((very|extremely|highly)? incredible[\\s]*|(very|extremely|highly)? healthy[\\s]*|(very|extremely|highly)? Attractive[\\s]*|(very|extremely|highly)? amazing[\\s]*|(very|extremely|highly)? nice[\\s]*|(very|extremely|highly)? great[\\s]*|(very|extremely|highly)? discounted[\\s]*|(very|extremely|highly)? Considerable[\\s]*|(very|extremely|highly)? highly stable[\\s]*|(very|extremely|highly)? free[\\s]*|(very|extremely|highly)? consistent[\\s]*|(very|extremely)? high[\\s]*|(very|extremely|highly)? good[\\s]*|(very|extremely|highly)? excellent[\\s]*|(very|extremely|highly)? healthy[\\s]*|(very|extremely|highly)? normalized[\\s]*|(very|extremely|highly)? normalized[\\s]*|(very|extremely|highly)? outstanding[\\s]*|(very|extremely|highly)? reliable[\\s]*|(very|extremely|highly)? significant[\\s]*|(very|extremely|highly)? significant[\\s]*|(very|extremely|highly)? sizeable[\\s]*|(very|extremely|highly)? sizeable[\\s]*|(very|extremely|highly)? solid[\\s]*|(very|extremely|highly)? stable[\\s]*|(very|extremely|highly)? stable[\\s]*|(very|extremely|highly)? steady[\\s]*|(very|extremely|highly)? Strong[\\s]*|(very|extremely|highly)? strong[\\s]*|(very|extremely|highly)? Tremendous[\\s]*|consistent[\\s]*|Growing[\\s]*|increased[\\s]*|multiple of[\\s]*|net[\\s]*|operating[\\s]*|organi[\\s]*|outstanding[\\s]*|positive[\\s]*|potential[\\s]*|proven track of[\\s]*|recurring[\\s]*|regular[\\s]*|strong[\\s]*|Sustainable[\\s]*|year over year[\\s]*|([0-9]?\\d*\\d*\\.?\\d*[\\s]*)year track record of consistent[\\s]*[\\s]*)";
		String regex3 = "((very|extremely|highly)? incredible[\\s]*|(very|extremely|highly)? healthy[\\s]*|(very|extremely|highly)? Attractive[\\s]*|(very|extremely|highly)? amazing[\\s]*|(very|extremely|highly)? nice[\\s]*|(very|extremely|highly)? great[\\s]*|(very|extremely|highly)? discounted[\\s]*|(very|extremely|highly)? Considerable[\\s]*|(very|extremely|highly)? highly stable[\\s]*|(very|extremely|highly)? free[\\s]*|(very|extremely|highly)? consistent[\\s]*|(very|extremely)? high[\\s]*|(very|extremely|highly)? good[\\s]*|(very|extremely|highly)? excellent[\\s]*|(very|extremely|highly)? healthy[\\s]*|(very|extremely|highly)? normalized[\\s]*|(very|extremely|highly)? normalized[\\s]*|(very|extremely|highly)? outstanding[\\s]*|(very|extremely|highly)? reliable[\\s]*|(very|extremely|highly)? significant[\\s]*|(very|extremely|highly)? significant[\\s]*|(very|extremely|highly)? sizeable[\\s]*|(very|extremely|highly)? sizeable[\\s]*|(very|extremely|highly)? solid[\\s]*|(very|extremely|highly)? stable[\\s]*|(very|extremely|highly)? stable[\\s]*|(very|extremely|highly)? steady[\\s]*|(very|extremely|highly)? Strong[\\s]*|(very|extremely|highly)? strong[\\s]*|(very|extremely|highly)? Tremendous[\\s]*|consistent[\\s]*|Growing[\\s]*|increased[\\s]*|multiple of[\\s]*|net[\\s]*|operating[\\s]*|organi[\\s]*|outstanding[\\s]*|positive[\\s]*|potential[\\s]*|proven track of[\\s]*|recurring[\\s]*|regular[\\s]*|strong[\\s]*|Sustainable[\\s]*|year over year[\\s]*|([0-9]?\\d*\\d*\\.?\\d*[\\s]*)year track record of consistent[\\s]*[\\s]*)?[\\d]*(Adjusted Cash Flow[\\s]*|cash flow(s)?[\\s]*|cash flow positive[\\s]*|net cash flow[\\s]*|Cash-flow positive[\\s]*|cash-flow[\\s]*|financial flow[\\s]*|capital flow[\\s]*|cash flow[\\s]*|money flow[\\s]*|cashflow(s)?[\\s]*|SDE[\\s]*)(consistently[\\s]*|steadily[\\s]*|stably[\\s]*|persistently[\\s]*|regularly[\\s]*|significantly[\\s]*)((~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*USD[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)million[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*£[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)[\\s]*|\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)M[\\s]*(\\+[\\s]*)[\\s]*|(~|-)?[\\s]*\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)K[\\s]*(\\+[\\s]*)[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)Dhs[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*£[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)m[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)Million[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*) — [\\s]*million[\\s]*[\\s]*|(~|-)?[\\s]* ([\\s]*(\\+[\\s]*)|-) \\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)[\\s]*|(~|-)?[\\s]*\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)(\\+[\\s]*)[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)million[\\s]*USD[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)mil[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)k[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)M[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*c£[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)k [\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*INR[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)Cr[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*US[\\s]*\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*US[\\s]*\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)million[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*USD[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)million[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)M[\\s]*pounds[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)million[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)million baht[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)million[\\s]*euros[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)million[\\s]*pounds[\\s]*[\\s]*)";
		String regex4 = "((very|extremely|highly)? incredible[\\s]*|(very|extremely|highly)? healthy[\\s]*|(very|extremely|highly)? Attractive[\\s]*|(very|extremely|highly)? amazing[\\s]*|(very|extremely|highly)? nice[\\s]*|(very|extremely|highly)? great[\\s]*|(very|extremely|highly)? discounted[\\s]*|(very|extremely|highly)? Considerable[\\s]*|(very|extremely|highly)? highly stable[\\s]*|(very|extremely|highly)? free[\\s]*|(very|extremely|highly)? consistent[\\s]*|(very|extremely)? high[\\s]*|(very|extremely|highly)? good[\\s]*|(very|extremely|highly)? excellent[\\s]*|(very|extremely|highly)? healthy[\\s]*|(very|extremely|highly)? normalized[\\s]*|(very|extremely|highly)? normalized[\\s]*|(very|extremely|highly)? outstanding[\\s]*|(very|extremely|highly)? reliable[\\s]*|(very|extremely|highly)? significant[\\s]*|(very|extremely|highly)? significant[\\s]*|(very|extremely|highly)? sizeable[\\s]*|(very|extremely|highly)? sizeable[\\s]*|(very|extremely|highly)? solid[\\s]*|(very|extremely|highly)? stable[\\s]*|(very|extremely|highly)? stable[\\s]*|(very|extremely|highly)? steady[\\s]*|(very|extremely|highly)? Strong[\\s]*|(very|extremely|highly)? strong[\\s]*|(very|extremely|highly)? Tremendous[\\s]*|consistent[\\s]*|Growing[\\s]*|increased[\\s]*|multiple of[\\s]*|net[\\s]*|operating[\\s]*|organi[\\s]*|outstanding[\\s]*|positive[\\s]*|potential[\\s]*|proven track of[\\s]*|recurring[\\s]*|regular[\\s]*|strong[\\s]*|Sustainable[\\s]*|year over year[\\s]*|([0-9]?\\d*\\d*\\.?\\d*[\\s]*)year track record of consistent[\\s]*[\\s]*)?[\\d]*(Adjusted Cash Flow[\\s]*|cash flow(s)?[\\s]*|cash flow positive[\\s]*|net cash flow[\\s]*|Cash-flow positive[\\s]*|cash-flow[\\s]*|financial flow[\\s]*|capital flow[\\s]*|cash flow[\\s]*|money flow[\\s]*|cashflow(s)?[\\s]*|SDE[\\s]*)(consistently[\\s]*|steadily[\\s]*|stably[\\s]*|persistently[\\s]*|regularly[\\s]*|significantly[\\s]*)((~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*USD[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)million[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*£[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)[\\s]*|\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)M[\\s]*(\\+[\\s]*)[\\s]*|(~|-)?[\\s]*\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)K[\\s]*(\\+[\\s]*)[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)Dhs[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*£[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)m[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)Million[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*) — [\\s]*million[\\s]*[\\s]*|(~|-)?[\\s]* ([\\s]*(\\+[\\s]*)|-) \\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)[\\s]*|(~|-)?[\\s]*\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)(\\+[\\s]*)[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)million[\\s]*USD[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)mil[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)k[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)M[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*c£[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)k [\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*INR[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)Cr[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*US[\\s]*\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*US[\\s]*\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)million[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*USD[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)million[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)M[\\s]*pounds[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)million[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)million baht[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)million[\\s]*euros[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)million[\\s]*pounds[\\s]*[\\s]*)(over the past[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)years[\\s]*[\\s]*|over the last[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)years.[\\s]*[\\s]*|each year[\\s]*|by[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|Since[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|in the recent years[\\s]*|for[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|for .* year[\\s]*|over the last [\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)|[\\s]*([one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety|hundred|thousand|million|billion|-]*[\\s]*) years[\\s]*[\\s]*|in such for the last[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)year[\\s]*[\\s]*|for FY[\\s]*([0-9]|1[12][\\s]*)([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|before the end of[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|by the end of[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|in the next .* year[\\s]*|in past[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*) months|years[\\s]*[\\s]*|in[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|throughout the year[\\s]*|year-on-year[\\s]*|([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)—[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*)?[\\d]*";
		String money = "((~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*USD[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)million[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*£[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)[\\s]*|\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)M[\\s]*(\\+[\\s]*)[\\s]*|(~|-)?[\\s]*\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)K[\\s]*(\\+[\\s]*)[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)Dhs[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*£[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)m[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)Million[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*) — [\\s]*million[\\s]*[\\s]*|(~|-)?[\\s]* ([\\s]*(\\+[\\s]*)|-) \\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)[\\s]*|(~|-)?[\\s]*\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)(\\+[\\s]*)[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)million[\\s]*USD[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)mil[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)k[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)M[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*c£[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)k [\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*INR[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)Cr[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*US[\\s]*\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*US[\\s]*\\$[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)million[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*USD[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)million[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)M[\\s]*pounds[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)million[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)million baht[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)million[\\s]*euros[\\s]*[\\s]*|(~|-)?[\\s]*(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just ove[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)?[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)million[\\s]*pounds[\\s]*[\\s]*)";
		System.out.println(regex);
		String line = "4 year track record of consistent cash flow positive steadily up to 5 million over the past 4 years";
		//String line2 = "";
		Pattern r = Pattern.compile(regex4);
		Matcher m = r.matcher(line);
		if(m.find()){
			String str = m.group(0);
			Pattern moneyr = Pattern.compile(money);
			Matcher moneym = moneyr.matcher(str);
			if(moneym.find()){
				System.out.println(moneym.group(0));
			}
			
		}
		
		//System.out.println(xml.intentionList.get(0).getTemplates().get(0).getTemplatetext());

*/	
		/*XmlUtil cashFlowXml = new XmlUtil("CashFlow.xml");
		XmlUtil ebitdaXml = new XmlUtil("Ebitda.xml");
		XmlUtil profitMarginXml = new XmlUtil("ProfitMargin.xml");
		XmlUtil revenueXml = new XmlUtil("Revenue.xml");
		XmlUtil marketshareXml = new XmlUtil("marketshare.xml");
		XmlUtil productXml = new XmlUtil("product.xml");
		XmlUtil technologyXml = new XmlUtil("technology.xml");
		PrintStream ps;
		
		try {
			ps = new PrintStream(new FileOutputStream("C:\\technology.json"));
			String ans = JSONObject.fromObject(technologyXml.conceptMap).toString();
			ps.println(JsonTool.formatJson(ans, "\t"));
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		*/
		//LinkedHashMap<String, Object> 
		XmlUtil revenueXml = new XmlUtil("profitability","revenue","Revenue.xml");
		PatternUtil pu = new PatternUtil();
		String revenueRegex = pu.templateToRegex("收入", revenueXml.conceptMap).getReg();
		System.out.println(revenueRegex);

	}

}
