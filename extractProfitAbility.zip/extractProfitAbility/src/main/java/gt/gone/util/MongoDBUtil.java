package gt.gone.util;

import gt.gone.util.WordTree.Pair;
import jxl.Cell;
import jxl.Sheet;
import jxl.Workbook;

import java.awt.Point;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.Vector;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.bson.Document;

import com.mongodb.Block;
import com.mongodb.MongoClient;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoDatabase;

import net.sf.json.JSONObject;
import net.sf.json.util.NewBeanInstanceStrategy;

public class MongoDBUtil {

	final static String mongoDbIp = PropertyUtil.getValue("mongodb.ip");

	public static ArrayList<String> extractClientScale(String input,
			WordTree scaleWordTree) {

		ArrayList<String> result = new ArrayList<String>();
		String[] inputWords = input.split(" ");
		Vector<WordTree.Pair<Integer>> pos = scaleWordTree
				.findPhrase(inputWords);

		for (Pair<Integer> pair : pos) {
			String extractedStr = "";
			for (int i = pair.first; i < pair.second && i < inputWords.length; i++) {
				extractedStr += inputWords[i] + " ";
			}
			result.add(extractedStr.trim());
		}

		// 加上正则匹配的词 例如：over 350
		String[] scaleReg = {
				"(a|an)?(\\s)*(extensive|Huge|huge|High|high|broad|any|large|various|all|most|different|Several|many|additional|these|complete|comprehensive|wide|full)?(\\s)*(range|numbers|number|groups|group|types|type|lines|line|kinds|kind|base|variety|database)(\\s)*of",
				"(over|more than)(\\s)*\\d+(,\\d+)*\\s(active\\s)?(clients|client)" };

		for (String reg : scaleReg) {
			Pattern p = Pattern.compile(reg);
			Matcher m = p.matcher(input);
			ArrayList<String> temp = new ArrayList<String>();
			LinkedHashMap<Point, Object> positionToEntity = new LinkedHashMap<Point, Object>();
			while (m.find()) {
				// result.add(m.group());
				int start = m.start();
				int end = m.end();
				if (end > 0 && input.charAt(end - 1) == ' ') {
					end = end - 1;
				}
				int matchLength = end - start;

				Point currentMatchPos = new Point(start, end);
				List<Point> jiaoChaPoints = selectJiaochaPoint(currentMatchPos,
						positionToEntity.keySet()); // 和当前点有交叉的区域
				if (jiaoChaPoints.isEmpty()) {
					positionToEntity.put(currentMatchPos, m.group());

				} else if (!jiaoChaPoints.isEmpty()) {
					for (Point jiaoChaPoint : jiaoChaPoints) {
						if (matchLength > (jiaoChaPoint.y - jiaoChaPoint.x)) {
							positionToEntity.remove(jiaoChaPoint);
						}

					}

					positionToEntity.put(currentMatchPos, m.group());
				}

			}
			for (Object entity : positionToEntity.values())
				result.add(entity.toString());

		}
		return result;
	}

	public static ArrayList<String> extractByReg(String input, String[] regs) {

		ArrayList<String> result = new ArrayList<String>();

		for (String reg : regs) {
			Pattern p = Pattern.compile(reg);
			Matcher m = p.matcher(input);
			ArrayList<String> temp = new ArrayList<String>();
			LinkedHashMap<Point, Object> positionToEntity = new LinkedHashMap<Point, Object>();
			while (m.find()) {
				int start = m.start();
				int end = m.end();
				if (end > 0 && input.charAt(end - 1) == ' ') {
					end = end - 1;
				}
				int matchLength = end - start;

				Point currentMatchPos = new Point(start, end);
				List<Point> jiaoChaPoints = selectJiaochaPoint(currentMatchPos,
						positionToEntity.keySet()); // 和当前点有交叉的区域
				if (jiaoChaPoints.isEmpty()) {
					positionToEntity.put(currentMatchPos, m.group());

				} else if (!jiaoChaPoints.isEmpty()) {
					for (Point jiaoChaPoint : jiaoChaPoints) {
						if (matchLength > (jiaoChaPoint.y - jiaoChaPoint.x)) {
							positionToEntity.remove(jiaoChaPoint);
						}

					}

					positionToEntity.put(currentMatchPos, m.group());
				}

			}
			for (Object entity : positionToEntity.values())
				result.add(entity.toString());

		}
		return result;
	}

	private static List<Point> selectJiaochaPoint(Point currentPosPoint,
			Set<Point> keySet) {
		// TODO Auto-generated method stub
		List<Point> jiaoChaPoints = new ArrayList<Point>();
		for (Point p : keySet) {
			if (p.x < currentPosPoint.x && currentPosPoint.x < p.y
					|| p.x < currentPosPoint.y && currentPosPoint.y < p.y
					|| p.x >= currentPosPoint.x && currentPosPoint.y >= p.y)
				jiaoChaPoints.add(p);

		}
		return jiaoChaPoints;
	}

	public static ArrayList<String> extract(String input, WordTree wordTree) {
		ArrayList<String> result = new ArrayList<String>();
		String[] inputWords = input.split(" ");
		Vector<WordTree.Pair<Integer>> pos = wordTree.findPhrase(inputWords);

		for (Pair<Integer> pair : pos) {
			String extractedStr = "";
			for (int i = pair.first; i < pair.second && i < inputWords.length; i++) {
				extractedStr += inputWords[i] + " ";
			}
			result.add(extractedStr.trim());
		}

		return result;
	}

	public static ArrayList<String> extractTrueOrFlase(String input,
			WordTree wordTree) {
		ArrayList<String> result = new ArrayList<String>();
		String[] inputWords = input.toLowerCase().split(" ");
		Vector<WordTree.Pair<Integer>> pos = wordTree.findPhrase(inputWords);

		for (Pair<Integer> pair : pos) {
			String extractedStr = "";
			for (int i = pair.first; i < pair.second && i < inputWords.length; i++) {
				extractedStr += inputWords[i] + " ";
			}
			result.add(extractedStr.trim());
		}
		return result;
	}

	public static HashMap<String, String> getIndustryHashMapFromMongoDB() {
		final HashMap<String, String> industryHashMap = new HashMap<String, String>();
		MongoClient mongoClient = null;

		mongoClient = new MongoClient(mongoDbIp, 27017);
		MongoDatabase db = mongoClient.getDatabase("product");
		FindIterable<Document> iterable = db.getCollection("industry").find();
		iterable.forEach(new Block<Document>() {
			public void apply(final Document document) {
				for (Entry<String, Object> entry : document.entrySet()) {
					String value = String.valueOf(entry.getValue());
					String key = String.valueOf(entry.getKey());
					if (value.contains("]"))
						value = value.replace("]", "");
					if (value != null) {
						industryHashMap.put(value, key);
						industryHashMap.put(value.toLowerCase(), key);
						if (value.contains("&")) {
							String[] words = value.split(" &");
							for (String word : words) {
								if (word.subSequence(0, 1).equals(" "))
									word = word.substring(1, word.length());
								industryHashMap.put(word, key);
								industryHashMap.put(word.toLowerCase(), key);
							}

						}
					}
				}
			}
		});
		return industryHashMap;
	}

	public static WordTree getIndustryWordTreeFromMongoDB() {
		final WordTree wordTree = new WordTree();
		// final ArrayList<String> result = new ArrayList<String>();
		MongoClient mongoClient = null;

		mongoClient = new MongoClient(mongoDbIp, 27017);
		MongoDatabase db = mongoClient.getDatabase("product");
		FindIterable<Document> iterable = db.getCollection("industry").find();
		iterable.forEach(new Block<Document>() {
			public void apply(final Document document) {
				String[] words1 = document.values().toString().split(",");
				for (String word : words1) {
					if (word.contains("&")) {
						String[] words2 = word.split("&");
						for (String word3 : words2) {
							wordTree.addPhrase(word3
									.substring(1, word3.length())
									.replace("]", "").split("\\s"));
							wordTree.addPhrase(word3.toLowerCase()
									.substring(1, word3.length())
									.replace("]", "").split("\\s"));
						}

					}
					wordTree.addPhrase(word.substring(1, word.length())
							.replace("]", "").split("\\s"));
					wordTree.addPhrase(word.toLowerCase()
							.substring(1, word.length()).replace("]", "")
							.split("\\s"));
				}

			}
		});
		return wordTree;
	}

	public static WordTree getLocationFromMongoDB() {
		final WordTree wordTree = new WordTree();
		// final ArrayList<String> result = new ArrayList<String>();
		final Map<String, String> map = new HashMap<String, String>();
		MongoClient mongoClient = null;

		mongoClient = new MongoClient(mongoDbIp, 27017);
		MongoDatabase db = mongoClient.getDatabase("product");
		FindIterable<Document> iterable = db.getCollection("location").find();
		iterable.forEach(new Block<Document>() {
			public void apply(final Document document) {
				if (document.containsKey("name")) {
					Document words = (Document) document.get("name");
					String[] words1 = words.toString()
							.replace("Document{{name_en=[", "")
							.replace("]}}", "").split("\n");

					for (String word : words1) {
						if (!word.equals("A") && !word.equals("Huge")
								&& !word.equals("Sales")
								&& !word.equals("Market")
								&& !word.equals("Good")
								&& !word.equals("Mobile")
								&& !word.equals("Long") && !word.equals("Well")
								&& !word.equals("Strong") && !word.equals("By")
								&& !word.equals("Metal")
								&& !word.equals("They") && !word.equals("Here")
								&& !word.equals("Serves")
								&& !word.equals("Many"))
							wordTree.addPhrase(word.split("\\s"));
					}
					wordTree.addPhrase("Asian".split("\\s"));
					wordTree.addPhrase("domestic".split("\\s"));
					wordTree.addPhrase("state".split("\\s"));
					wordTree.addPhrase("Australia".split("\\s"));
					wordTree.addPhrase("International".split("\\s"));
					wordTree.addPhrase("European".split("\\s"));
					wordTree.addPhrase("local area".split("\\s"));
					wordTree.addPhrase("local".split("\\s"));

					wordTree.addPhrase("overseas".split("\\s"));
					wordTree.addPhrase("Broad overall".split("\\s"));
					wordTree.addPhrase("Nationwide".split("\\s"));
					wordTree.addPhrase("Domestic".split("\\s"));
					wordTree.addPhrase("United States".split("\\s"));
					wordTree.addPhrase("USA".split("\\s"));
					wordTree.addPhrase("international".split("\\s"));
					wordTree.addPhrase("world".split("\\s"));
				}
			}
		});
		return wordTree;
	}

	public static WordTree getMarketWordTreeFromMongoDB() throws Exception {

		final WordTree wordTree = new WordTree();
		MongoClient mongoClient = null;

		mongoClient = new MongoClient(mongoDbIp, 27017);
		MongoDatabase db = mongoClient.getDatabase("product");
		FindIterable<Document> iterable = db.getCollection("location").find();
		iterable.forEach(new Block<Document>() {
			public void apply(final Document document) {
				if (document.containsKey("name")) {
					Document words = (Document) document.get("name");
					String[] words1 = words.toString()
							.replace("Document{{name_en=[", "")
							.replace("]}}", "").split("\n");

					for (String word : words1) {

						wordTree.addPhrase(word.split("\\s"));
					}

				}
			}
		});

		return wordTree;
	}

	public static void firstTest() throws Exception {
		MongoClient mongoClient = null;
		try {
			mongoClient = new MongoClient(mongoDbIp, 27017);
			MongoDatabase db = mongoClient.getDatabase("gt");
			FindIterable<Document> iterable = db.getCollection(
					"products_knowledgebase").find();
			iterable.forEach(new Block<Document>() {
				public void apply(final Document document) {
					if (document.containsKey("english_synonym")) {
						System.out.println(document.getString(""));
					}
				}
			});
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			try {
				mongoClient.close();
			} catch (Exception e2) {
			}
		}
	}

	public static WordTree getEconomicActivityFromMongoDB() {
		final WordTree wordTree = new WordTree();
		MongoClient mongoClient = null;

		mongoClient = new MongoClient(mongoDbIp, 27017);
		MongoDatabase db = mongoClient.getDatabase("product");
		FindIterable<Document> iterable = db.getCollection("economicActivity")
				.find();
		iterable.forEach(new Block<Document>() {
			public void apply(final Document document) {
				if (document.containsKey("words")) {

					ArrayList<String> words = new ArrayList<String>();
					for (String sentence : document.get("words").toString()
							.split(",")) {

						if (sentence.contains("word")) {
							String character = sentence.replace("[", " ")
									.replace(" Document{{word=", "");

							words.add(character);
						}

					}

					for (String word : words.toString().split("\n")) {
						if (word != null) {

							wordTree.addPhrase(word.split("\\s"));
						}

					}

				}

			}
		});

		return wordTree;
	}

	public static HashMap<String, String> getDataFromExcel() throws Exception {
		Workbook readwb = null;
		InputStream instream = new FileInputStream(
				"d:/industry_classification.xls");
		readwb = Workbook.getWorkbook(instream);
		Sheet readsheet = readwb.getSheet(0);
		int rsColumns = readsheet.getColumns();
		int rsRows = readsheet.getRows();
		HashMap<String, String> industryMap = new HashMap<String, String>();
		for (int i = 4; i < rsRows; i += 2) {
			Cell cell = readsheet.getCell(7, i);
			industryMap.put(readsheet.getCell(6, i).toString(), readsheet
					.getCell(7, i).toString());
			System.out.println(industryMap);
		}
		return industryMap;
	}
	
	public static LinkedHashMap<String, List<String>> getConceptHashMapFromMongoDB(String databaseString,String collectionName) {
		final LinkedHashMap<String, List<String>> conceptHashMap = new LinkedHashMap<String, List<String>>();
		MongoClient mongoClient = null;

		mongoClient = new MongoClient(mongoDbIp, 27017);
		MongoDatabase db = mongoClient.getDatabase(databaseString);
		FindIterable<Document> iterable = db.getCollection(collectionName).find();
		iterable.forEach(new Block<Document>() {
			public void apply(final Document document) {
				for (Entry<String, Object> entry : document.entrySet()) {
					Object value = entry.getValue();
					String key = entry.getKey();
					if (value != null && value instanceof List) {
						conceptHashMap.put(key, (List<String>) value);
					}
				}
			}
		});
		return conceptHashMap;
	}
	
	public static void main(String[] args){
		PrintStream ps;
		String conceptName = "cashflow";
		try {
			ps = new PrintStream(new FileOutputStream("C:\\cashflowFromMongo.json"));
			LinkedHashMap<String, List<String>> conceptMap = getConceptHashMapFromMongoDB("profitability",conceptName);
			String ans = JSONObject.fromObject(conceptMap).toString();
			ps.println(JsonTool.formatJson(ans, "\t"));
			System.out.println(conceptMap.get("数字"));
			
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

}