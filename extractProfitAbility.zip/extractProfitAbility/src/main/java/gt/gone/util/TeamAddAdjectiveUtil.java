package gt.gone.util;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.collections.map.HashedMap;

public class TeamAddAdjectiveUtil {

	// 去除结果中包含的情况
	public static HashSet removeCompete(Set locationSet) {
		HashSet result = new HashSet<>();
		HashSet newSet = new LinkedHashSet<>();
		if (locationSet == null)
			;
		else {
			StringBuilder locationString = new StringBuilder();
			for (Object setObject : locationSet) {
				locationString.append(setObject.toString());
				locationString.append(" ");
			}

			
			for (Object setObject : locationSet) {
				if (count(locationString.toString(), setObject.toString()) == 1) {
					newSet.add(setObject);
				}
			}
			//result.add(newSet);
		}
		return newSet;
	}

	// 计算结果出现的次数
	public static int count(String text, String sub) {
		int count = 0;
		int start = 0;
		while (((start = text.indexOf(sub, start))) >= 0) {
			start += sub.length();
			count++;
		}
		return count;
	}

	// 首字母大写
	public static String toUpperCaseFirstOne(String s) {
		StringBuilder stringBuilder = new StringBuilder();
		String[] wStrings = s.split("\\s+");
		for (String wString : wStrings) {
			stringBuilder.append(Character.toUpperCase(wString.charAt(0)))
					.append(wString.substring(1));
			stringBuilder.append(" ");
		}
		return stringBuilder.toString();

	}

	public static HashSet teamAddAdjectiveUtil(Set teamAdvantageSet,
			String input) {
		HashSet teamAddAjectiveSet = new HashSet<>();
		// 如果匹配上
		if (teamAdvantageSet.size() != 0) {

			for (Object str : teamAdvantageSet) {
				// 后期用正则匹配，将匹配到的结果加上固定的搭配与原句比较
				String[] regs = {
						"(multi|Multi|really|well|Very|very|smoothly|extremely|very highly|rich|significant|rich industry|highly|Fully|Highly|fully|high|profound|extensive|famous|more)(\\s)*"
								+ str.toString()
						//,"(very |Very |well )" + str.toString()
						};
				int count = 0;
				for (String reg : regs) {
					Pattern pattern = Pattern.compile(reg);
					Matcher matcher = pattern.matcher(input);

					while (matcher.find()) {
						count++;
						teamAddAjectiveSet.add(matcher.group());
					}

				}
				if (count == 0)
					teamAddAjectiveSet.add(str);
			}
		}

		return teamAddAjectiveSet;

	}

}
