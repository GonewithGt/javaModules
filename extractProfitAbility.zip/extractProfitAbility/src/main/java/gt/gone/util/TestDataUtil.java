package gt.gone.util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class TestDataUtil {
	public static void main(String[] args) {
		/*List<String> strs = new ArrayList<String>();
		String path = "C:\\TestData\\projects.txt";
		String outPutpath = "C:\\TestData\\TestProductAll.txt";
		BufferedReader br = null;
		String tmp = null;
		try {
			PrintStream ps = new PrintStream(new FileOutputStream(outPutpath));
			System.setOut(ps);
			br = new BufferedReader(new FileReader(path));
			while ((tmp = br.readLine()) != null) {
				strs.add(tmp);
			}

			for (int i = 0; i < strs.size(); i++) {
				// if(one.toLowerCase().contains("margin ")||one.toLowerCase().contains("profit "))
				// if(one.toLowerCase().contains("ebitda "))
				
				 * if(one.toLowerCase().contains("revenue ")
				 * ||one.toLowerCase().contains("sale ")
				 * ||one.toLowerCase().contains("turnover ")
				 * ||one.toLowerCase().contains("income ") )
				 
				if (i % 5 == 0) {
					String one = strs.get(i);
					
					 * if (one.toLowerCase().contains("cash flow") ||
					 * one.toLowerCase().contains("cash-flow") ||
					 * one.toLowerCase().contains("financial flow") ||
					 * one.toLowerCase().contains("capital flow") ||
					 * one.toLowerCase().contains("money flow") ||
					 * one.toLowerCase().contains("cashflow") ||
					 * one.toLowerCase().contains("SDE")) {
					 
					if (one.toLowerCase().contains("product") || one.toLowerCase().contains("company")) {
						if (one.trim().startsWith("\"")) {
							one = one.trim()
									.substring(1, one.trim().length() - 1)
									.trim();
						}
						System.out.println(one);

					}
				}
			}
		} catch (Exception e) {
			System.out.println("file not exist");
		} finally {
			try {
				if (br != null) {
					br.close();
					br = null;
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}*/
		
		System.out.println(isIrregularStopSign("abc g.p"));
	}
	
	
	public static boolean isContainedKeyWord(String input, PatternUtil pu, XmlUtil cashFlowXml, XmlUtil ebitdaXml, XmlUtil profitMarginXml, XmlUtil revenueXml){
		String cashFlow = "现金流";
		String ebitda = "税息前利润";
		String profitMargin = "利润率";
		String revenue = "收入";
		String keyWordRegex = pu.templateToRegex(cashFlow, cashFlowXml.conceptMap).getReg()
				+"|"+pu.templateToRegex(ebitda, ebitdaXml.conceptMap).getReg()
				+"|"+pu.templateToRegex(profitMargin, profitMarginXml.conceptMap).getReg()
				+"|"+pu.templateToRegex(revenue, revenueXml.conceptMap).getReg();
		Pattern pattern = Pattern.compile(keyWordRegex.toLowerCase());
		Matcher matcher = pattern.matcher(input.toLowerCase());
		if(matcher.find()){
			return true;
		}
		return false;
	}
	
	public static boolean isContainedCashFlowKeyWord(String input, PatternUtil pu, XmlUtil cashFlowXml){
		String cashFlow = "现金流";
		
		String keyWordRegex = pu.templateToRegex(cashFlow, cashFlowXml.conceptMap).getReg();
				
		Pattern pattern = Pattern.compile(keyWordRegex.toLowerCase());
		Matcher matcher = pattern.matcher(input.toLowerCase());
		if(matcher.find()){
			return true;
		}
		return false;
	}
	
	
	public static boolean isContainedEbitdaKeyWord(String input, PatternUtil pu, XmlUtil ebitdaXml){
		
		String ebitda = "税息前利润";
		
		String keyWordRegex = pu.templateToRegex(ebitda, ebitdaXml.conceptMap).getReg();
				
		Pattern pattern = Pattern.compile(keyWordRegex.toLowerCase());
		Matcher matcher = pattern.matcher(input.toLowerCase());
		if(matcher.find()){
			return true;
		}
		return false;
	}
	
	public static boolean isContainedProfitMarginKeyWord(String input, PatternUtil pu, XmlUtil profitMarginXml){
		
		String profitMargin = "利润率";
		
		String keyWordRegex = pu.templateToRegex(profitMargin, profitMarginXml.conceptMap).getReg();
				
		Pattern pattern = Pattern.compile(keyWordRegex.toLowerCase());
		Matcher matcher = pattern.matcher(input.toLowerCase());
		if(matcher.find()){
			return true;
		}
		return false;
	}
	
	public static boolean isContainedRevenueKeyWord(String input, PatternUtil pu, XmlUtil revenueXml){
		
		String revenue = "收入";
		String keyWordRegex = pu.templateToRegex(revenue, revenueXml.conceptMap).getReg();
		Pattern pattern = Pattern.compile(keyWordRegex.toLowerCase());
		Matcher matcher = pattern.matcher(input.toLowerCase());
		if(matcher.find()){
			return true;
		}
		return false;
	}
	
	
	public static boolean isContainedKeyWord(String input, String keyWordRegex){
		
		Pattern pattern = Pattern.compile(keyWordRegex.toLowerCase());
		Matcher matcher = pattern.matcher(input.toLowerCase());
		if(matcher.find()){
			return true;
		}
		return false;
	}
	// 判断是否包含Avg\\. 这样的句号
	public static boolean isIrregularStopSign(String input){
		input = input.toLowerCase();
		if(input.endsWith("avg")
			||input.endsWith("years")
			||input.endsWith("y.e")
			||input.endsWith("p.w")
			||input.endsWith("p.a")
			||input.endsWith("circa")
			||input.endsWith("approx")
			||input.endsWith(" c") //c. £
			||input.endsWith("£")
			||input.endsWith("rs")
			||input.endsWith("%")
			||input.endsWith("g.p")
			||input.endsWith("dhs")
			||input.endsWith("adj")
			
			){
			return true;
		}
		return false;
	}
	
	
	
	

}
