package gt.gone.model.profitability;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.io.ByteOrderMark;
import org.apache.commons.io.input.BOMInputStream;

import gt.gone.model.profitability.cashflow.CashFlow;
import gt.gone.model.profitability.cashflow.CashFlowExtract;
import gt.gone.model.profitability.ebitda.Ebitda;
import gt.gone.model.profitability.profitmargin.ProfitMargin;
import gt.gone.model.profitability.revenue.Revenue;
import gt.gone.util.FileUtil;
import gt.gone.util.JsonTool;
import gt.gone.util.PatternUtil;
import gt.gone.util.PreProcess;
import gt.gone.util.PropertyUtil;
import gt.gone.util.TestDataUtil;
import gt.gone.util.XmlUtil;
import net.sf.json.JSONObject;

public class ProfitAbilityExtract {
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//String fileTest2 = "D:\\java\\cashFlow\\extractCashFlow3\\src\\main\\resources\\test2.txt";
		//String input = FileUtil.importData(fileTest2, 1);	
		
		long getProgStartTime = System.currentTimeMillis();
		 PrintStream ps;
			try {

				//ps = new PrintStream(new FileOutputStream("C:\\sellerPAResultJsonMongo100.txt"));
				ps = new PrintStream(new FileOutputStream(PropertyUtil.getValue("profitablity.output")));

				//System.setOut(ps);  
				/*+"companyJson.txt"*/
			//	String fileTest2 = "C:\\Users\\nlp\\workspace\\extractCashFlow3\\src\\main\\resources\\seller_4w.txt";

				//String fileTest2 = "C:\\Users\\nlp\\workspace1\\extractCashFlow3\\src\\main\\resources\\4w_new.txt";
				String fileTest2 = PropertyUtil.getValue("profitablity.input");

				//String fileTest2 = "C:\\Users\\nlp\\workspace\\extractCashFlow3\\src\\main\\resources\\wrongSentence.txt";
				ProfitAbilityExtract cfe = new ProfitAbilityExtract();
				
				String line = null;
				  //  int n = 3;//从第三行开始读取
				    try {
				    	//FileInputStream fileInputStream  = new FileInputStream(filePath);
				    	//InputStreamReader isr = new InputStreamReader(fileInputStream, "UTF-8");
				    	// ClassLoader classLoader = XmlUtil.class.getClassLoader();
				    	// FileInputStream fis = (FileInputStream) classLoader.getResourceAsStream(filePath); 
				    	 
				    	FileInputStream fis = new FileInputStream(fileTest2);
			        	   //可检测多种类型，并剔除bom
			        	BOMInputStream bomIn = new BOMInputStream(fis, false,ByteOrderMark.UTF_8, ByteOrderMark.UTF_16LE, ByteOrderMark.UTF_16BE);
			        	String charset = "utf-8";
			        	   //若检测到bom，则使用bom对应的编码
//			        	if(bomIn.hasBOM()){
//			        		charset = bomIn.getBOMCharsetName();
//			        	 }
			        	BufferedReader br = new BufferedReader(new InputStreamReader(bomIn, charset));
						//br = new BufferedReader(new InputStreamReader(new FileInputStream(filePath), "UTF-8"));
						int i = 0;
						int count = 1;
						/*while(i < 6000){
							line = br.readLine();
							i++;
						}*/
						 while ((line = br.readLine()) != null) {

						//	 if(TestDataUtil.isContainedKeyWord(line, pu, cashFlowXml, ebitdaXml, profitMarginXml, revenueXml)){

								 /*	if(i % 100000 == 0){
								 		ps = new PrintStream(new FileOutputStream(PropertyUtil.getValue("profitablity.output")+"companyJson"+Integer.toString(i/100000)+".txt"));
								 	}*/
								 
							 		String ans = cfe.extractProfitAbility(line);

									//JsonFormatTool jst = new JsonFormatTool();
								 	//System.out.println(count++);

							 		
								 	ps.println(++i);
								 	System.out.println(i);

								 	//ps.println(count);
								 	//count++;
									ps.println(JsonTool.formatJson(ans, "\t"));
									ps.println();
									ps.println();


					// }

//							 
//							 if(count==1001){
//								 break;
//							 }
							 	
							/*if(i == 6000){
								break;
								}*/
								

							}
						 br.close();
						 
						 long getProgEndTime = System.currentTimeMillis();
							
						ps.println("profitAbility extraction time For 3000 sentence: "+ (getProgEndTime - getProgStartTime)+ " ms");

						 
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
				/*for(int i = 1 ; i < 110 ; i++){
					
					String input = FileUtil.importData(fileTest2, i);	
					if(input!=null){
						String ans = cfe.extractProfitAbility(input);
						//JsonFormatTool jst = new JsonFormatTool();
						System.out.println(JsonTool.formatJson(ans, "\t"));
						System.out.println();
						System.out.println();
					}
					
				}*/
			/*	
				String input = FileUtil.importData(fileTest, 1);
				String ans = extractCashFlow(input);
				JsonFormatTool jst = new JsonFormatTool();
				System.out.println(JsonTool.formatJson(ans, " "));*/
				
			
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			
			
	}
	public static XmlUtil cashFlowXml = new XmlUtil("profitability","cashflow","CashFlow.xml");
	public static XmlUtil ebitdaXml = new XmlUtil("profitability","ebitda","Ebitda.xml");
	public static XmlUtil profitMarginXml = new XmlUtil("profitability","profitmargin","ProfitMargin.xml");
	public static XmlUtil revenueXml = new XmlUtil("profitability","revenue","Revenue.xml");
	public static PatternUtil pu = new PatternUtil();
	
	public static String cashFlowRegex = pu.templateToRegex("现金流", cashFlowXml.conceptMap).getReg();
	public static String ebitdaRegex = pu.templateToRegex("税息前利润", ebitdaXml.conceptMap).getReg();
	public static String profitMarginRegex = pu.templateToRegex("利润率", profitMarginXml.conceptMap).getReg();
	public static String revenueRegex = pu.templateToRegex("收入", revenueXml.conceptMap).getReg();
	public static String keyWordRegex = cashFlowRegex+ "|"+ ebitdaRegex+ "|"+profitMarginRegex+ "|"+revenueRegex;
	
	public String extractProfitAbility(String input) {
		
		return extractProfitAbility(input, cashFlowXml, ebitdaXml, profitMarginXml, revenueXml);
/*
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		result.put("Input", input);
		CashFlow cashflowSen = new CashFlow(input);
		Ebitda ebitdaSen = new Ebitda(input);
		ProfitMargin profitMarginSen = new ProfitMargin(input);
		Revenue revenueSen = new Revenue(input);
		LinkedHashMap<String, Object> cashFlow = cashflowSen.getResultMap();
		LinkedHashMap<String, Object> ebitda = ebitdaSen.getResultMap();
		LinkedHashMap<String, Object> profitmargin = profitMarginSen.getResultMap();
		LinkedHashMap<String, Object> revenue = revenueSen.getResultMap();
		if(cashFlow!=null && cashFlow.get("CashFlow")!=null &&  !cashFlow.get("CashFlow").toString().isEmpty() && !result.containsKey("CashFlow")){
			result.put("CashFlow", cashFlow);
		}
		
		if(ebitda!=null && ebitda.get("EBITDA")!=null &&  !ebitda.get("EBITDA").toString().isEmpty() && !result.containsKey("EBITDA")){
			result.put("EBITDA", ebitda);
		}
		
		if(profitmargin!=null && profitmargin.get("ProfitMargin")!=null &&  !profitmargin.get("ProfitMargin").toString().isEmpty() && !result.containsKey("ProfitMargin")){
			result.put("ProfitMargin", profitmargin);
		}
		
		if(revenue!=null && revenue.get("Revenue")!=null &&  !revenue.get("Revenue").toString().isEmpty() && !result.containsKey("Revenue")){
			result.put("Revenue", revenue);
		}

		return JSONObject.fromObject(result).toString();*/
	}
	
	public String extractProfitAbility(String inputStr, XmlUtil cashFlowXml, XmlUtil ebitdaXml, XmlUtil profitMarginXml, XmlUtil revenueXml) {
		
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		result.put("Input", inputStr);
		
		
		//String[]inputs = inputStr.split("\\. |\\n\\r\\n");
		if(TestDataUtil.isContainedKeyWord(inputStr, pu, cashFlowXml, ebitdaXml, profitMarginXml, revenueXml)){
			
			Map<String , Object> categoryToSentencesMap = PreProcess.getKeySentencesMap(inputStr, cashFlowRegex, ebitdaRegex, profitMarginRegex, revenueRegex);
			String cashFlowInputStr = categoryToSentencesMap.get("cashFlowSens").toString();
			String ebitdaInputStr = categoryToSentencesMap.get("ebitdaSens").toString();
			String profitMarginInputStr = categoryToSentencesMap.get("profitMarginSens").toString();
			String revenueInputStr = categoryToSentencesMap.get("revenueSens").toString();
			
			//System.out.println("cashflow==>"+cashFlowInputStr);
			//System.out.println("ebitdaInputStr==>"+ebitdaInputStr);
			//System.out.println("profitMarginInputStr==>"+profitMarginInputStr);
			//System.out.println("revenueInputStr==>"+revenueInputStr);
			//inputStr = inputStr.replace("excl. VAT", "excl VAT"); 
			/*CashFlow cashflowSen = new CashFlow(inputStr, cashFlowXml);
			Ebitda ebitdaSen = new Ebitda(inputStr, ebitdaXml);
			ProfitMargin profitMarginSen = new ProfitMargin(inputStr, profitMarginXml);
			Revenue revenueSen = new Revenue(inputStr, revenueXml);*/
			CashFlow cashflowSen = new CashFlow(cashFlowInputStr, cashFlowXml);
			Ebitda ebitdaSen = new Ebitda(ebitdaInputStr, ebitdaXml);
			ProfitMargin profitMarginSen = new ProfitMargin(profitMarginInputStr, profitMarginXml);
			Revenue revenueSen = new Revenue(revenueInputStr, revenueXml);
			
			List<LinkedHashMap<String, Object> > cashflowList = cashflowSen.getResultList();
			List<LinkedHashMap<String, Object> > ebitdaList = ebitdaSen.getResultList();
			List<LinkedHashMap<String, Object> > profitmarginList = profitMarginSen.getResultList();
			List<LinkedHashMap<String, Object> > revenueList = revenueSen.getResultList();
			/*List<LinkedHashMap<String, Object> > cashflowList = new ArrayList<LinkedHashMap<String, Object> >();
			List<LinkedHashMap<String, Object> > ebitdaList = new ArrayList<LinkedHashMap<String, Object> >();
			List<LinkedHashMap<String, Object> > profitmarginList = new ArrayList<LinkedHashMap<String, Object> >();
			List<LinkedHashMap<String, Object> > revenueList = new ArrayList<LinkedHashMap<String, Object> >();
			for(String input:inputs){
				System.out.println(input);
				
				CashFlow cashflowSen = new CashFlow(input, cashFlowXml);
				Ebitda ebitdaSen = new Ebitda(input, ebitdaXml);
				ProfitMargin profitMarginSen = new ProfitMargin(input, profitMarginXml);
				Revenue revenueSen = new Revenue(input, revenueXml);
				LinkedHashMap<String, Object> cashFlow = cashflowSen.getResultMap();
				LinkedHashMap<String, Object> ebitda = ebitdaSen.getResultMap();
				LinkedHashMap<String, Object> profitmargin = profitMarginSen.getResultMap();
				LinkedHashMap<String, Object> revenue = revenueSen.getResultMap();
				if(cashFlow!=null && cashFlow.get("CashFlow")!=null &&  !cashFlow.get("CashFlow").toString().isEmpty() && !result.containsKey("CashFlow")
						&& cashFlow.size() > 2){
					//System.out.println("cashflow");
					cashflowList.add(cashFlow);
				}
				
				if(ebitda!=null && ebitda.get("EBITDA")!=null &&  !ebitda.get("EBITDA").toString().isEmpty() && !result.containsKey("EBITDA")
						&& ebitda.size() > 2){
					//System.out.println(ebitda);
					ebitdaList.add(ebitda);
				}
				
				if(profitmargin!=null && profitmargin.get("ProfitMargin")!=null &&  !profitmargin.get("ProfitMargin").toString().isEmpty() && !result.containsKey("ProfitMargin")
						&& profitmargin.size() > 2){
					//System.out.println(profitmargin);
					profitmarginList.add(profitmargin);
				}
				
				if(revenue!=null && revenue.get("Revenue")!=null &&  !revenue.get("Revenue").toString().isEmpty() && !result.containsKey("Revenue")
						&& revenue.size() > 2){
					//System.out.println(revenue);
					revenueList.add(revenue);
				}			
			}
			*/
			if(cashflowList.size()>0){
				result.put("CashFlow",cashflowList);
			}
			if(ebitdaList.size()>0){
				result.put("EBITDA",ebitdaList);
			}
			if(profitmarginList.size()>0){
				result.put("ProfitMargin",profitmarginList);
			}
			if(revenueList.size()>0){
				result.put("Revenue",revenueList);
			}
		}
		return JSONObject.fromObject(result).toString();
	}

}
