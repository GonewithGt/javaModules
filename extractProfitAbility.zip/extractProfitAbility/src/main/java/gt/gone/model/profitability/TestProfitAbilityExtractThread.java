package gt.gone.model.profitability;

import gt.gone.util.FileUtil;
import gt.gone.util.JsonTool;
import gt.gone.util.PropertyUtil;

import java.io.BufferedReader;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.Vector;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class TestProfitAbilityExtractThread {
	
	public static void main(String[] args) throws IOException, InterruptedException{
		final Vector<String> inputs = new Vector<String>();
		String fileTest2 = "C:\\Users\\nlp\\workspace1\\extractCashFlow3\\src\\main\\resources\\4w_new.txt";
		//String fileTest2 = "C:\\Users\\nlp\\workspace1\\extractCashFlow3\\src\\main\\resources\\TestCashFlow.txt";
		String outPath = "C:\\TestCashFlowThread.txt";
		//String fileTest2 = PropertyUtil.getValue("profitablity.input");
		BufferedReader br = FileUtil.quchuBom(fileTest2);
		String line = null;
		 while ( br !=null &&(line = br.readLine()) != null){
			 inputs.add(line);
		 }
		// Thread.sleep(10000);
		 
		int threadNum = 5;
		int fileSize = inputs.size();
		//ProfitAbilityExtractThread[] thread = new ProfitAbilityExtractThread[threadNum];
		//Thread[] threads = new Thread[threadNum];
		ExecutorService cachedTreadPool = Executors.newFixedThreadPool(10);
		final ProfitAbilityExtract pae = new ProfitAbilityExtract();
		final PrintStream ps = new PrintStream(new FileOutputStream(outPath));;
		for( int i = 0 ; i < fileSize ; i++){
			
			final String lineStr = inputs.get(i);
			cachedTreadPool.execute(new Runnable() {				
				@Override
				public void run() {
					// TODO Auto-generated method stub
					synchronized (ps) {
						//ps.println(i);
						ps.println(JsonTool.formatJson(pae.extractProfitAbility(lineStr), "\t"));
					}	
				}
			});
		}
		//ProfitAbilityExtractThread thread1 = new ProfitAbilityExtractThread(inputs,);
		
 	}

}
