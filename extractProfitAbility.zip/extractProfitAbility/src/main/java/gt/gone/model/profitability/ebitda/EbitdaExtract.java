package gt.gone.model.profitability.ebitda;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;

import org.apache.commons.io.ByteOrderMark;
import org.apache.commons.io.input.BOMInputStream;

import gt.gone.util.FileUtil;
import gt.gone.util.JsonTool;
import gt.gone.util.PatternUtil;
import gt.gone.util.PreProcess;
import gt.gone.util.PropertyUtil;
import gt.gone.util.XmlUtil;
import net.sf.json.JSONObject;

public class EbitdaExtract {
	public static XmlUtil ebitdaXml = new XmlUtil("profitability","ebitda","Ebitda.xml");
	public static PatternUtil pu = new PatternUtil();
	public static String ebitdaRegex = pu.templateToRegex("税息前利润", ebitdaXml.conceptMap).getReg();

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//String fileTest2 = "D:\\java\\cashFlow\\extractCashFlow3\\src\\main\\resources\\test2.txt";
		//String input = FileUtil.importData(fileTest2, 1);
		EbitdaExtract cfe = new EbitdaExtract();		
		//XmlUtil xml = new XmlUtil("Ebitda.xml");
		XmlUtil xml = new XmlUtil("profitability","ebitda","Ebitda.xml");
		 PrintStream ps;
			try {
				//ps = new PrintStream(new FileOutputStream("C:\\sellerEbitdaResultJson.txt"));
				ps = new PrintStream(new FileOutputStream(PropertyUtil.getValue("profitablity.ebitda.output")));
				//System.setOut(ps);
				
			
				//String fileTest2 = "C:\\Users\\nlp\\workspace1\\extractCashFlow3\\src\\main\\resources\\seller_4w.txt";
				String fileTest2 = PropertyUtil.getValue("profitablity.ebitda.input");
				//String fileTest2 = "C:\\Users\\nlp\\workspace1\\extractCashFlow3\\src\\main\\resources\\TestEbitda.txt";
				String line = null;
				  //  int n = 3;//从第三行开始读取
				    try {
				    	//FileInputStream fileInputStream  = new FileInputStream(filePath);
				    	//InputStreamReader isr = new InputStreamReader(fileInputStream, "UTF-8");
				    	// ClassLoader classLoader = XmlUtil.class.getClassLoader();
				    	// FileInputStream fis = (FileInputStream) classLoader.getResourceAsStream(filePath); 
				    	 
				    	FileInputStream fis = new FileInputStream(fileTest2);
			        	   //可检测多种类型，并剔除bom
			        	BOMInputStream bomIn = new BOMInputStream(fis, false,ByteOrderMark.UTF_8, ByteOrderMark.UTF_16LE, ByteOrderMark.UTF_16BE);
			        	String charset = "utf-8";
			        	   //若检测到bom，则使用bom对应的编码
			        	if(bomIn.hasBOM()){
			        		charset = bomIn.getBOMCharsetName();
			        	 }
			        	BufferedReader br = new BufferedReader(new InputStreamReader(bomIn, charset));
						//br = new BufferedReader(new InputStreamReader(new FileInputStream(filePath), "UTF-8"));
						int i = 1;
						 while ((line = br.readLine()) != null) {
							 String ans = cfe.extractEbitda(line, xml);
								//JsonFormatTool jst = new JsonFormatTool();
							 	//System.out.println("LineNum:"+ i++);
							 	ps.println(JsonTool.formatJson(ans, "\t"));
							 	ps.println();
							 	ps.println();
								//System.out.println(JsonTool.formatJson(ans, "\t"));
								//System.out.println();
								System.out.println(i++);
							}
						 br.close();
						 
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				

			
				/*for(int i = 1 ; i < 30 ; i++){
					
					String input = FileUtil.importData(fileTest2, i);	
					if(input!=null){
						EbitdaExtract cfe = new EbitdaExtract();
						String ans = cfe.extractEbitda(input);
						//JsonFormatTool jst = new JsonFormatTool();
						System.out.println(JsonTool.formatJson(ans, "\t"));
						System.out.println();
						System.out.println();
					}
					
				}*/
			/*	
				String input = FileUtil.importData(fileTest, 1);
				String ans = extractCashFlow(input);
				JsonFormatTool jst = new JsonFormatTool();
				System.out.println(JsonTool.formatJson(ans, " "));*/
				
			
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 

	}
	
	public  String extractEbitda(String input){
		String ebitdaInputStr = PreProcess.getKeySentences(input, ebitdaRegex);
		Ebitda sentence = new Ebitda(ebitdaInputStr/*.replaceAll("–", "-")*/);
		String resultStr ="";
		//resultStr = JSONObject.fromObject(sentence.getEntityNameToEntityMap()).toString();
		resultStr = JSONObject.fromObject(sentence.getResultMap()).toString();
		//System.out.println(JsonTool.formatJson(sentence.getKeyToInfoMap().toString(), " "));
		return resultStr;
	}
	
	public  String extractEbitda(String input, XmlUtil xml){
		String ebitdaInputStr = PreProcess.getKeySentences(input, ebitdaRegex);
		Ebitda sentence = new Ebitda(ebitdaInputStr/*.replaceAll("–", "-")*/, xml);
		String resultStr ="";
		//resultStr = JSONObject.fromObject(sentence.getEntityNameToEntityMap()).toString();
		resultStr = JSONObject.fromObject(sentence.getResultMap()).toString();
		//System.out.println(JsonTool.formatJson(sentence.getKeyToInfoMap().toString(), " "));
		return resultStr;
	}

}
