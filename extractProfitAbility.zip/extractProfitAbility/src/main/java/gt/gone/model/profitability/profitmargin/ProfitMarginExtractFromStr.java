package gt.gone.model.profitability.profitmargin;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;

import gt.gone.model.profitability.revenue.RevenueExtract;
import gt.gone.util.FileUtil;
import gt.gone.util.JsonTool;
import gt.gone.util.PropertyUtil;

public class ProfitMarginExtractFromStr {
	
	public static void main(String[] args) throws FileNotFoundException{
		//String fileTest2 = "C:\\Users\\nlp\\workspace\\extractCashFlow3\\src\\main\\resources\\TestProfitMargin.txt";
		//String fileTest2 = "C:\\Users\\nlp\\workspace\\extractCashFlow3\\src\\main\\resources\\wrongSentence.txt";
		//String fileTest2 = "C:\\Users\\nlp\\workspace\\extractCashFlow3\\src\\main\\resources\\seller_4w.txt";
		String fileTest2 = PropertyUtil.getValue("profitablity.input");
		int i = 0 ;
		String input = FileUtil.importData(fileTest2, 1615);
		//String input = "Consistent Profitability: Not only is the Company highly profitable, but its margins and earnings are consistent.";
		PrintStream ps = new PrintStream(new FileOutputStream("C:\\tmp.txt"));
		if(input!=null){
			ProfitMarginExtract cfe = new ProfitMarginExtract();
			String ans = cfe.extractProfitMargin(input);
			//JsonFormatTool jst = new JsonFormatTool();
			ps.println(JsonTool.formatJson(ans, "\t"));
			ps.println();
			ps.println();
			System.out.println(JsonTool.formatJson(ans, "\t"));
			System.out.println();
			System.out.println();
		}
	
	}
	

}
