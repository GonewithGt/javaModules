package gt.gone.model.profitability.revenue;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.LinkedHashMap;

import org.apache.commons.io.ByteOrderMark;
import org.apache.commons.io.input.BOMInputStream;








import gt.gone.model.profitability.ebitda.EbitdaExtract;
import gt.gone.util.FileUtil;
import gt.gone.util.JsonTool;
import gt.gone.util.PatternUtil;
import gt.gone.util.PreProcess;
import gt.gone.util.PropertyUtil;
import gt.gone.util.XmlUtil;
import net.sf.json.JSONObject;

public class RevenueExtract {
	
	public static XmlUtil revenueXml = new XmlUtil("profitability","revenue","Revenue.xml");
	public static PatternUtil pu = new PatternUtil();
	public static String revenueRegex = pu.templateToRegex("收入", revenueXml.conceptMap).getReg();

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//String fileTest2 = "D:\\java\\cashFlow\\extractCashFlow3\\src\\main\\resources\\test2.txt";
		//String input = FileUtil.importData(fileTest2, 1);
		
		
		RevenueExtract cfe = new RevenueExtract();		
		//XmlUtil xml = new XmlUtil("Revenue.xml");
		
		 PrintStream ps;
			try {
				//ps = new PrintStream(new FileOutputStream("C:\\extractRevenueResultJson.txt"));
				ps = new PrintStream(new FileOutputStream(PropertyUtil.getValue("profitablity.revenue.output")));
				System.setOut(ps);  
			
				//String fileTest2 = "C:\\Users\\nlp\\workspace1\\extractCashFlow3\\src\\main\\resources\\TestRevenue.txt";
				String fileTest2 = PropertyUtil.getValue("profitablity.input");
				String line = null;
				  //  int n = 3;//从第三行开始读取
				    try {
				    	//FileInputStream fileInputStream  = new FileInputStream(filePath);
				    	//InputStreamReader isr = new InputStreamReader(fileInputStream, "UTF-8");
				    	// ClassLoader classLoader = XmlUtil.class.getClassLoader();
				    	// FileInputStream fis = (FileInputStream) classLoader.getResourceAsStream(filePath); 
				    	 
				    	FileInputStream fis = new FileInputStream(fileTest2);
			        	   //可检测多种类型，并剔除bom
			        	BOMInputStream bomIn = new BOMInputStream(fis, false,ByteOrderMark.UTF_8, ByteOrderMark.UTF_16LE, ByteOrderMark.UTF_16BE);
			        	String charset = "utf-8";
			        	   //若检测到bom，则使用bom对应的编码
			        	if(bomIn.hasBOM()){
			        		charset = bomIn.getBOMCharsetName();
			        	 }
			        	BufferedReader br = new BufferedReader(new InputStreamReader(bomIn, charset));
						//br = new BufferedReader(new InputStreamReader(new FileInputStream(filePath), "UTF-8"));
						int i = 1;
						long startTime = System.currentTimeMillis();
						 while ((line = br.readLine()) != null) {
						//	 line = PreProcess.getKeySentences(line, revenueRegex);
							 String ans = cfe.extractRevenue(line, revenueXml);
								//JsonFormatTool jst = new JsonFormatTool();
							 	System.out.println("LineNum:"+ i++);
								System.out.println(JsonTool.formatJson(ans, "\t"));
								System.out.println();
								System.out.println();
								
								if(i==1000)
									break;
							}
						 long endTime = System.currentTimeMillis();
						 System.out.println("run 1000 sentences"+(endTime - startTime));
						 br.close();
						 
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				
				
			/*	for(int i = 1 ; i < 110 ; i++){
					
					String input = FileUtil.importData(fileTest2, i);	
					if(input!=null){
						RevenueExtract cfe = new RevenueExtract();
						String ans = cfe.extractRevenue(input);
						//JsonFormatTool jst = new JsonFormatTool();
						System.out.println(JsonTool.formatJson(ans, "\t"));
						System.out.println();
						System.out.println();
					}
					
				}*/
			/*	
				String input = FileUtil.importData(fileTest, 1);
				String ans = extractCashFlow(input);
				JsonFormatTool jst = new JsonFormatTool();
				System.out.println(JsonTool.formatJson(ans, " "));*/
				
			
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 

	}
	
	public  String extractRevenue(String input){
		String revenueInputStr = PreProcess.getKeySentences(input, revenueRegex);
		System.out.println(revenueInputStr);
		Revenue sentence = new Revenue(revenueInputStr/*.replace("excl. VAT", "excl VAT").replace("incl. VAT", "incl VAT")*/,revenueXml);//不知名字符
		String resultStr ="";
		//resultStr = JSONObject.fromObject(sentence.getEntityNameToEntityMap()).toString();
		LinkedHashMap<String ,Object> resultMap = sentence.getResultMap();
		resultMap.put("Sentence", input);
		resultStr = JSONObject.fromObject(resultMap).toString();
		//System.out.println(JsonTool.formatJson(sentence.getKeyToInfoMap().toString(), " "));
		return resultStr;
	}
	public  String extractRevenue(String input, XmlUtil xml){
		String revenueInputStr = PreProcess.getKeySentences(input, revenueRegex);
		Revenue sentence = new Revenue(revenueInputStr/*.replace("excl. VAT", "excl VAT").replace("incl. VAT", "incl VAT")*/, xml);
		String resultStr ="";
		LinkedHashMap<String ,Object> resultMap = sentence.getResultMap();
		resultMap.put("Sentence", input);
		//resultStr = JSONObject.fromObject(sentence.getEntityNameToEntityMap()).toString();
		resultStr = JSONObject.fromObject(resultMap).toString();
		//System.out.println(JsonTool.formatJson(sentence.getKeyToInfoMap().toString(), " "));
		return resultStr;
	}

}
