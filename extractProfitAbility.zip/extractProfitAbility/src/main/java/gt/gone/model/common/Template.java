package gt.gone.model.common;


public class Template {
	
	private String name; //模板名字
	private String templatetext; //模板对应的原始文本
	
	public Template(String name, String templatetext) {
		this.name = name;
		this.templatetext = templatetext;
	}
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getTemplatetext() {
		return templatetext;
	}
	public void setTemplate(String templatetext) {
		this.templatetext = templatetext;
	}

}
