package gt.gone.model.profitability;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import gt.gone.util.FileUtil;
import gt.gone.util.JsonTool;
import gt.gone.util.PropertyUtil;

public class ProfitAbilityExtractFromStr {
		
		public static void main(String[] args) throws FileNotFoundException{

			//String fileTest2 = "C:\\Users\\nlp\\workspace\\extractCashFlow3\\src\\main\\resources\\TestRevenue.txt";
			//String fileTest2 = "C:\\Users\\nlp\\workspace\\extractCashFlow3\\src\\main\\resources\\wrongSentence.txt";
			String fileTest2 = PropertyUtil.getValue("profitablity.input");
			int i = 0 ;
			String input = FileUtil.importData(fileTest2, 3236);
			//String input = "Group of websites are now averaging 160,000 per month in sales with 9 world class URL they are expected to a net profit estimate of 1,011,600 in 2014. This is a 15,000 sq distribution and assembly center, this is a good company to run and operate for more info call Nathan Goldstein	";
			PrintStream ps = new PrintStream(new FileOutputStream("C:\\tmp.txt"));
			if(input!=null){
				ProfitAbilityExtract cfe = new ProfitAbilityExtract();
				String ans = cfe.extractProfitAbility(input);
				//JsonFormatTool jst = new JsonFormatTool();
				ps.println(JsonTool.formatJson(ans, "\t"));
				ps.println();
				ps.println();
				System.out.println(JsonTool.formatJson(ans, "\t"));
				System.out.println();
				System.out.println();
			}
		}

	

}
