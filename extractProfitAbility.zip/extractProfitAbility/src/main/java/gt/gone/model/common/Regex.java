package gt.gone.model.common;

import java.util.HashMap;
import java.util.List;

public class Regex {
	
	
	private String reg;// 一条模板对应的reg
	private List<ExtractTarget> extractTarget;//一条模板中需要提取的目标
	
	public Regex(String reg, List<ExtractTarget> extractTarget) {
		//super();
		this.reg = reg;
		this.extractTarget = extractTarget;
	}
	public List<ExtractTarget> getExtractTarget() {
		return extractTarget;
	}
	public void setExtractTarget(List<ExtractTarget> extractTarget) {
		this.extractTarget = extractTarget;
	}
	
	
	public String getReg() {
		return reg;
	}
	public void setReg(String reg) {
		this.reg = reg;
	}
	

}
