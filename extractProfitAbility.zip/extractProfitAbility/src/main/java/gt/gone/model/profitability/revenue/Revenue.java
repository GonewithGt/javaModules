package gt.gone.model.profitability.revenue;

import java.awt.Point;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import gt.gone.model.common.Intention;
import gt.gone.model.common.Template;
import gt.gone.util.ChangeUtil;
import gt.gone.util.FileUtil;
import gt.gone.util.FrequencyUtil;
import gt.gone.util.KeyWordReplaceUtil;
import gt.gone.util.MapUtil;
import gt.gone.util.MatchTemplateUtil;
import gt.gone.util.MoneyUtil;
import gt.gone.util.PatternUtil;
import gt.gone.util.PreProcess;
import gt.gone.util.TimeUtil;
import gt.gone.util.WordCountUtil;
import gt.gone.util.XmlUtil;

public class Revenue {
	private String sentenceString ; //原句
	private String changedString ; //关键词替换后的句子
	private LinkedHashMap<String ,Object> keyToTokenMap; //关键词-->关键词对应的类。初步设计为：#money1 -->Money
	//private LinkedHashMap<String ,Object> entityNameToEntityMap; //实体名 到实体的映射
	private LinkedHashMap<String ,Object> keyToInfoMap; //抽取的信息
	private  LinkedHashMap<String ,Object> resultMap; //最终抽取的信息
	private List<LinkedHashMap<String, Object> > resultList ;
	private final String keyEntityStr = "#收入"; 
	public List<LinkedHashMap<String, Object>> getResultList() {
		return resultList;
	}
	public void setResultList(List<LinkedHashMap<String, Object>> resultList) {
		this.resultList = resultList;
	}
	/*public LinkedHashMap<String, Object> getEntityNameToEntityMap() {
		return entityNameToEntityMap;
	}
	public void setEntityNameToEntityMap(
			LinkedHashMap<String, Object> entityNameToEntityMap) {
		this.entityNameToEntityMap = entityNameToEntityMap;
	}*/
	public Revenue(String sentence){
		this.sentenceString = sentence;
		this.changedString = sentence;
		//this.entityNameToEntityMap = new LinkedHashMap<String ,Object>();
		this.keyToInfoMap= new LinkedHashMap<String, Object>();
		this.resultMap= new LinkedHashMap<String, Object>();
		this.resultList = new ArrayList<LinkedHashMap<String, Object> >();
		process(sentence, null);
		//System.out.println();
		//System.out.println();
		
	}
	
	public Revenue(String sentence, XmlUtil xml){
		this.sentenceString = sentence;
		this.changedString = sentence;
	//	this.entityNameToEntityMap = new LinkedHashMap<String ,Object>();
		this.keyToInfoMap= new LinkedHashMap<String, Object>();
		this.resultMap= new LinkedHashMap<String, Object>();
		this.resultList = new ArrayList<LinkedHashMap<String, Object> >();
		process(sentence, xml);
		//System.out.println();
		//System.out.println();
		
	}
	
	//将元素替换成
	private void process(String sentence, XmlUtil xml) {
		// TODO Auto-generated method stub
		if(xml==null){
			//xml = new XmlUtil("Revenue.xml");
			xml = new XmlUtil("profitability","revenue","Revenue.xml");
		}
		
		//PatternUtil pu = new PatternUtil();
		//LinkedHashMap<String ,String> keyWordToRegex = pu.toRegex(xml.conceptMap);
		String changedSentence = new String(sentence);
		Map<Point ,Object> positionToEntity = new HashMap<Point ,Object>();
		//Set<Point> matchedPos = new HashSet<Point>();
		/*long getKeyWordPosStartTime = System.currentTimeMillis();
		boolean flag = false;
		for (Map.Entry<String, String> entry :keyWordToRegex.entrySet()) {   
		  // System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue()); 
		   Pattern r = Pattern.compile(entry.getValue().toLowerCase());
		   Matcher m = r.matcher(sentence.toLowerCase());
		   //Matcher change = r.matcher(sentence);
		   int count = 0 ;	   
		   int matchLength = 0;
		   int start = 0;
		   int end = 0;
		   while(m.find()) {
			   	flag = true;
		         count++;
		         start = m.start();
		         end = m.end();
		         if(end <= sentence.length()){
		        	 if(end > 0 && sentence.charAt(end-1)==' '){
			        	 end = end - 1;
			         }
			         matchLength = end - start;
			        // System.out.println(sentence.substring(start,end)+" "+start+" "+end); //gt
			         Point currentMatchPos = new Point(start,end);
			         List<Point> jiaoChaPoints = selectJiaochaPoint(currentMatchPos , positionToEntity.keySet()); //和当前点有交叉的区域
			         
			         if(jiaoChaPoints.isEmpty()){
			        	 positionToEntity.put(currentMatchPos, entry.getKey());
			        	
			         }else if(!jiaoChaPoints.isEmpty() ){
			        	 boolean addEntityFlag = true;
			        	 for(Point jiaoChaPoint: jiaoChaPoints){
			        		// System.out.println("jiaochapoints: "+sentence.substring(jiaoChaPoint.x, jiaoChaPoint.y)+" x:"+jiaoChaPoint.x+" y:"+jiaoChaPoint.y);//gt
			        		 
			        		 // System.out.println("x:"+jiaoChaPoint.x);
			        		// System.out.println("y:"+jiaoChaPoint.y);
			        		 if(matchLength >= (jiaoChaPoint.y- jiaoChaPoint.x)){
			        			// System.out.println("matchLength:"+matchLength);
			        			 positionToEntity.remove(jiaoChaPoint);
			        		 }else {
			        			 addEntityFlag = false;
							}
			        	
			        	 }
			        	
			        	 if(addEntityFlag)
			        	 positionToEntity.put(currentMatchPos, entry.getKey());
			         }
		         }
		        
		   
		      }
			
			
		}
		long getKeyWordPosOrderStartTime = System.currentTimeMillis();
		positionToEntity = MapUtil.getOrder(positionToEntity);
		long getKeyWordPosOrderEndTime = System.currentTimeMillis();
		System.out.println("getKeyWordPosOrderStartTime:"+ (getKeyWordPosOrderEndTime - getKeyWordPosOrderStartTime));
		for(Point point: positionToEntity.keySet()){
			System.out.println("point: "+sentence.substring(point.x, point.y)+" x:"+point.x+" y:"+point.y);//gt	
		}
		
		long getKeyWordPosEndTime = System.currentTimeMillis();
		System.out.println("getKeyWordPosTime:"+ (getKeyWordPosEndTime - getKeyWordPosStartTime));
		*/
		
		positionToEntity = KeyWordReplaceUtil.getTokenPositionByRegex(sentence, xml, positionToEntity, changedSentence);
		/*for(Point point: positionToEntity.keySet()){
			System.out.println("point: "+sentence.substring(point.x, point.y)+" x:"+point.x+" y:"+point.y);//gt	
		}*/
		
		if(positionToEntity.size()> 0){
			changedSentence = sentenceReplacedWithKeyWord(sentence, (LinkedHashMap<Point, Object>) positionToEntity, xml);	
		}	
		
		
		//System.out.println("sentence = "+sentence);
		//System.out.println("changedSentence = "+changedSentence);
		//entityNameToEntityMap.put("sentence", sentence);
		//entityNameToEntityMap.put("changedSentence", changedSentence);
		//System.out.println(keyWordToRegex.size());
		//System.out.println(positionToEntity.size());
	}
	
	//将原句中匹配的部分进行关键字替换
	private String sentenceReplacedWithKeyWord(String sentence, LinkedHashMap<Point, Object> positionToEntity, XmlUtil xml) {
		// TODO Auto-generated method stub
		
		long sentenceReplaceStartTime = System.currentTimeMillis();
		String sentenceTmp = new String(sentence);
		PatternUtil pu = new PatternUtil();
		if(xml==null){
			//xml = new XmlUtil("Revenue.xml");
			xml = new XmlUtil("profitability","revenue","Revenue.xml");
		}
		LinkedHashMap<String,String> regexs = pu.toRegex(xml.conceptMap);
		ArrayList< Map<String, Object> > timeEntityList = new ArrayList< Map<String, Object> > ();
		ArrayList< Map<String, Object> > moneyEntityList = new ArrayList< Map<String, Object> > ();
		ArrayList< Map<String, Object> > changeEntityList = new ArrayList< Map<String, Object> > ();
		ArrayList< Map<String, Object> > frequencyEntityList = new ArrayList< Map<String, Object> > ();
		ArrayList< Map<String, Object> > percentEntityList = new ArrayList< Map<String, Object> > ();
		/*int timeCount=0;
		int moneyCount = 0;
		int predictCount = 0;
		int changeCount = 0;
		int frequencyCount = 0;
		int percentCount = 0;
		*/
		
		int count = 0;
		StringBuilder sentenceReplacedSb = new StringBuilder();
		int startPos = 0;
		for( Map.Entry<Point,Object> entry : positionToEntity.entrySet()){
			
			int start = entry.getKey().x;
			int end = entry.getKey().y;
			String oldChar = sentenceTmp.substring(start,end);
			String keyToken = entry.getValue().toString();
			
			
			boolean flag = false;
			String keyTokenTmp = new String(keyToken);
			if(keyTokenTmp.contains("钱数")){
				keyTokenTmp = "钱数";
			}
			boolean tokenToDisplayFlag =false;
			if(keyToken.contains("收入")
					||keyToken.contains("时间")
					||keyToken.contains("周期")
					||keyToken.contains("预计类词语")
					||keyToken.contains("钱数")
					||keyToken.contains("达到类词语")
					||keyToken.contains("百分比")
					||keyToken.contains("变化")
					||keyToken.contains("预计达到")){
				if(keyToken.contains("钱数")){
					keyToken = "钱数";
				}
				if(keyToken.contains("收入定性")){
					keyToken = "收入";
				}
				tokenToDisplayFlag = true;
				count++;
				keyToken = keyToken+count;
				keyTokenTmp = keyToken;
				//System.out.println(keyToken+"====>"+oldChar);
			}
			//按词进行替换 消除一个词被部分截断的问题
			if(tokenToDisplayFlag){
				flag = KeyWordReplaceUtil.isCorrectToken(sentenceTmp, start, end, keyTokenTmp, oldChar);
			}
			
			if(flag&&tokenToDisplayFlag){
				//System.out.println(startPos);
				//System.out.println(start);
				sentenceReplacedSb.append(sentenceTmp.substring(startPos,start));
				sentenceReplacedSb.append(" "+"#"+ keyTokenTmp +" ");
				startPos = end;
				/*if(keyToken.equals("现金流")||keyToken.equals("利润率")||keyToken.equals("折旧前利润")||keyToken.equals("收入")||keyToken.equals("净收入")){
					System.out.println("主体：" + oldChar);
				}else*/ if(keyToken.contains("时间")){
					/*System.out.println("时间："+oldChar);
					System.out.println("-----timeType:"+ extractTimeType(oldChar));
					System.out.println("-----timePoint:"+ extractTimePoint(oldChar));
					System.out.println("-----isTimeFuzzy:"+ isTimeFuzzy(oldChar));
					System.out.println("-----isTimePoint:"+ isTimePoint(oldChar));
					//System.out.println("-----timeUnit:"+ extractTimeUnit(oldChar));
					//System.out.println("-----timeTense:"+ extractTimeTense(oldChar));
					System.out.println("-----timePeriodStart:"+ extractTimePeriodStart(oldChar));
					System.out.println("-----timePeriodEnd:"+ extractTimePeriodEnd(oldChar));
					System.out.println("-----timeStartPos:"+ entry.getKey().x);
					System.out.println("-----timeEndPos:"+ entry.getKey().y);*/
					
					LinkedHashMap<String ,Object> timeEntityMap = new LinkedHashMap<String ,Object>();
					timeEntityMap.put("time", oldChar.trim());
					timeEntityMap.put("timeType", TimeUtil.extractTimeType(oldChar));
					timeEntityMap.put("timePoint", TimeUtil.extractTimePoint(oldChar));
					timeEntityMap.put("isTimeFuzzy", TimeUtil.isTimeFuzzy(oldChar));
					timeEntityMap.put("isTimePoint", TimeUtil.isTimePoint(oldChar));
					timeEntityMap.put("timePeriodStart", TimeUtil.extractTimePeriodStart(oldChar));
					timeEntityMap.put("timePeriodEnd", TimeUtil.extractTimePeriodEnd(oldChar));
					timeEntityMap.put("timeStartPos", entry.getKey().x);
					timeEntityMap.put("timeEndPos", entry.getKey().y);
					timeEntityList.add(timeEntityMap);
					this.keyToInfoMap.put("#"+keyToken.trim(), timeEntityMap);
					
					
					//entityNameToEntityMap.put(key, value)
					
				}else if(keyToken.contains("钱数")){
					String moneyModifier = MoneyUtil.getMoneyModifier(oldChar, pu, xml);
					/*System.out.println("钱数："+ "："+oldChar);
					System.out.println("-----moneyNum："+MoneyUtil.getMoneyNum(oldChar, regexs));
					System.out.println("-----moneyCurrencyType："+MoneyUtil.getMoneyCurrencyType(oldChar));
					System.out.println("-----moneyModifier：" + moneyModifier);
					System.out.println("-----moneyModifierType：" + MoneyUtil.getMoneyModifierType(moneyModifier,oldChar));
					//System.out.println("-----moneyType：" + MoneyUtil.getMoneyType(oldChar,pu,xml));
					System.out.println("-----moneyType：" + MoneyUtil.getMoneyType(oldChar,regexs));
					System.out.println("-----moneyMin：" + MoneyUtil.getMoneyMin(oldChar,regexs));
					System.out.println("-----moneyMax：" + MoneyUtil.getMoneyMax(oldChar,regexs));
					System.out.println("-----moneyQualityCategory：" + MoneyUtil.getMoneyQualityCategory (oldChar,regexs));
					System.out.println("-----moneyQualityDes：" + MoneyUtil.getMoneyQualityDes(oldChar,regexs));
					System.out.println("-----moneyStartPos："+entry.getKey().x);
					System.out.println("-----moneyEndPos："+entry.getKey().y);*/
					
					LinkedHashMap<String ,Object> moneyEntityMap = new LinkedHashMap<String ,Object>();
					moneyEntityMap.put("money", oldChar.trim());
					moneyEntityMap.put("moneyNum", MoneyUtil.getMoneyNum(oldChar, regexs));
					moneyEntityMap.put("moneyCurrencyType", MoneyUtil.getMoneyCurrencyType(oldChar));
					moneyEntityMap.put("moneyModifier", moneyModifier);
					moneyEntityMap.put("moneyModifierType", MoneyUtil.getMoneyModifierType(moneyModifier,oldChar));
					moneyEntityMap.put("moneyType",  MoneyUtil.getMoneyType(oldChar,regexs));
					moneyEntityMap.put("moneyMin", MoneyUtil.getMoneyMin(oldChar,regexs));
					moneyEntityMap.put("moneyMax", MoneyUtil.getMoneyMax(oldChar,regexs));
					moneyEntityMap.put("moneyQualityCategory", MoneyUtil.getMoneyQualityCategory (oldChar,regexs));
					moneyEntityMap.put("moneyQualityDes",  MoneyUtil.getMoneyQualityDes(oldChar,regexs));
					moneyEntityMap.put("moneyStartPos", entry.getKey().x);
					moneyEntityMap.put("moneyEndPos", entry.getKey().y);
					moneyEntityList.add(moneyEntityMap);
					
					this.keyToInfoMap.put("#"+keyToken.trim(), moneyEntityMap);
					
				}else if (keyToken.contains("变化")) {
					/*System.out.println(entry.getValue() + "：" + oldChar);
					System.out.println("-----changeType" + "：" + extractChangeType(oldChar));
	                System.out.println("-----changeRate" + "：" + extractChangeRate(oldChar,regexs));
	                System.out.println("-----changeQuatity" + "：" + extractChangeQuatity(oldChar,regexs));
	                System.out.println("-----changeStartPos："+entry.getKey().x);			
	                System.out.println("-----changeEndPos："+entry.getKey().y);*/
	                
					LinkedHashMap<String ,Object> changeEntityMap = new LinkedHashMap<String ,Object>();
					changeEntityMap.put("changeText", oldChar.trim());
					changeEntityMap.put("changeType", ChangeUtil.extractChangeType(oldChar));
					changeEntityMap.put("changeRate", ChangeUtil.extractChangeRate(oldChar,regexs));
					changeEntityMap.put("changeQuatity",ChangeUtil.extractChangeQuatity(oldChar,regexs));
					changeEntityMap.put("changeStartPos", entry.getKey().x);
					changeEntityMap.put("changeEndPos", entry.getKey().y);
					changeEntityList.add(changeEntityMap);
					this.keyToInfoMap.put("#"+keyToken.trim(), changeEntityMap);
					
				} else if (keyToken.contains("周期")) {
					/*
					System.out.println("周期：" + oldChar);
					System.out.println("-----frequencyUnit：" + extractFrequency(oldChar));
					System.out.println("-----frequencyStartPos："+entry.getKey().x);
					System.out.println("-----frequencyEndPos："+entry.getKey().y);*/
					
					LinkedHashMap<String ,Object> frequencyEntityMap = new LinkedHashMap<String ,Object>();
					frequencyEntityMap.put("frequencyText", oldChar.trim());
					frequencyEntityMap.put("frequencyUnit", FrequencyUtil.extractFrequencyUnit(oldChar));
					frequencyEntityMap.put("frequencyStartPos", entry.getKey().x);
					frequencyEntityMap.put("frequencyEndPos", entry.getKey().y);
					frequencyEntityList.add(frequencyEntityMap);
					this.keyToInfoMap.put("#"+keyToken.trim(), frequencyEntityMap);
					
				}else if(keyToken.contains("百分比")){
					/*System.out.println(entry.getValue() +":"+ oldChar);
					System.out.println("-----percentStartPos："+entry.getKey().x);
					System.out.println("-----percentEndPos："+entry.getKey().y);	*/
					
					LinkedHashMap<String ,Object> percentEntityMap = new LinkedHashMap<String ,Object>();
					//percentEntityMap.put("percentText", oldChar.trim());
					String moneyModifier = MoneyUtil.getMoneyModifier(oldChar, pu, xml);
					percentEntityMap.put("percentText", oldChar.trim());
					percentEntityMap.put("percentModifier", moneyModifier);
					percentEntityMap.put("percentModifierType", MoneyUtil.getMoneyModifierType(moneyModifier,oldChar));
					percentEntityMap.put("percentStartPos", entry.getKey().x);
					percentEntityMap.put("percentEndPos", entry.getKey().y);
					percentEntityList.add(percentEntityMap);
					this.keyToInfoMap.put("#"+keyToken.trim(), percentEntityMap);
				}else if(keyToken.contains("收入")){
					LinkedHashMap<String ,Object> cashFlowEntityMap = new LinkedHashMap<String ,Object>();
					cashFlowEntityMap.put("cfDescripWord", "");
					cashFlowEntityMap.put("cfDescripWordCategory", "");
					cashFlowEntityMap.put("cashflow", "");	
					if(keyToken.contains("收入")){
						String xiushici = MoneyUtil.getMoneyQualityDes(oldChar,regexs);
						cashFlowEntityMap.put("cfDescripWord", xiushici);
						cashFlowEntityMap.put("cfDescripWordCategory", MoneyUtil.getMoneyQualityCategory(oldChar,regexs));
						//System.out.println(xiushici);
						//System.out.println(oldChar);
						if(xiushici!=null){
							cashFlowEntityMap.put("cashflow", (" "+oldChar.trim()+" ").replaceAll("\\s"+xiushici.trim()+"\\s", "").trim());	
							
						}else{
							cashFlowEntityMap.put("cashflow", oldChar.trim());	
							
						}					}
					this.keyToInfoMap.put("#"+keyToken.trim(), cashFlowEntityMap);
				}else if(keyToken.contains("预计")){
					this.keyToInfoMap.put("#"+keyToken.trim(), oldChar);
				}
			}
		}
		if(startPos < sentenceTmp.length()){
			sentenceReplacedSb.append(sentenceTmp.substring(startPos));
		}
		sentence = sentenceReplacedSb.toString();
		/*this.entityNameToEntityMap.put("sentence", sentenceTmp);
		this.entityNameToEntityMap.put("changedSentence", sentence);
		this.entityNameToEntityMap.put("moneyEntitys", moneyEntityList);
		this.entityNameToEntityMap.put("timeEntitys",  timeEntityList);
		this.entityNameToEntityMap.put("changeEntitys", changeEntityList);
		this.entityNameToEntityMap.put("frequencyEntitys", frequencyEntityList);
		this.entityNameToEntityMap.put("percentEntitys", percentEntityList);*/
	//	long sentenceReplaceEndTime = System.currentTimeMillis();
	//	System.out.println("sentenceReplaceTime:"+ (sentenceReplaceEndTime - sentenceReplaceStartTime));
		
	//	long sentenceMatchStartTime = System.currentTimeMillis();
		
		String[] sensStrings = PreProcess.splitInput(sentence);
		for(String sen : sensStrings){
			//LinkedHashMap<String, Object> newKeyToInfoMap = (LinkedHashMap<String, Object>) this.keyToInfoMap.clone();
			//System.out.println(sen);
			sen = sen.trim();
			if(sen!=null && !sen.isEmpty()){
				
				int keyEntityStrPos = sen.indexOf(keyEntityStr);
				int lastKeyEntityStrPos = sen.lastIndexOf(keyEntityStr);
				int withPos = sen.indexOf(" with ");
				int andPos = sen.indexOf(" and ");
				if(keyEntityStrPos >=0 ){
					
					if(keyEntityStrPos == lastKeyEntityStrPos){ //一句话中中心实体只有一个
						//System.out.println("withPos====>"+withPos);
						//System.out.println("andPos====>"+andPos);
						//System.out.println("keyEntityStrPos====>"+keyEntityStrPos);
						String keyWordInSenString = MoneyUtil.getTokenStr(sen, keyEntityStr);
						LinkedHashMap<String, Object> cashFlowTokenMap = (LinkedHashMap<String, Object>)keyToInfoMap.get(keyWordInSenString);
						String keyWordDes = null;
						int keyWordDesCate = 0; 
						if(cashFlowTokenMap!=null && cashFlowTokenMap.get("cfDescripWord")!=null){
							
							keyWordDes = new String(cashFlowTokenMap.get("cfDescripWord").toString()) ;
							keyWordDesCate =  (int)cashFlowTokenMap.get("cfDescripWordCategory");
						}
						if(withPos >= 0 && withPos < keyEntityStrPos){ //如果包含with keyEntity ...结构
							//String tmpsen = sen.substring(withPos);
							String tmpsen = MatchTemplateUtil.selectWithPhraseWithTime(sen, withPos);
							this.keyToInfoMap = MoneyUtil.addFarXiuShiCi(tmpsen, this.keyEntityStr, regexs, this.keyToInfoMap);
							LinkedHashMap<String ,Object> entityResultMap = matchTemplate(xml, PreProcess.preProcessForRule(tmpsen), this.keyToInfoMap);
							if(entityResultMap.size() > 2){
								this.resultList.add(entityResultMap);
							}
							
						}else if(withPos >= 0 && withPos > keyEntityStrPos){ //如果包含with keyEntity ...结构
							String tmpsen = sen ;
							if(!sen.contains("with #预计")){
								tmpsen = sen.substring(0, withPos);
							}
							 
							this.keyToInfoMap = MoneyUtil.addFarXiuShiCi(tmpsen, this.keyEntityStr, regexs, this.keyToInfoMap);
							LinkedHashMap<String ,Object> entityResultMap = matchTemplate(xml, PreProcess.preProcessForRule(tmpsen), this.keyToInfoMap);
							if(entityResultMap.size() > 2){
								this.resultList.add(entityResultMap);
							}
						}else if(andPos>= 0 && andPos > keyEntityStrPos){ 
							
							String beforeAndsen = sen.substring(0, andPos);
							String afterAndsen = sen.substring(andPos + " and ".length());
							String andBeforeAnd= afterAndsen;
							if(andBeforeAnd.contains(" and ")){
								andBeforeAnd = afterAndsen.substring(0, afterAndsen.indexOf(" and "));
							}																
							//String andAfterAnd= afterAndsen.substring(afterAndsen.indexOf(" and "));
							if(!WordCountUtil.isContainKeyWord(andBeforeAnd)){
								String pingjieSen = sen.substring(keyEntityStrPos,keyEntityStrPos+keyEntityStr.length()+2)+" "+ afterAndsen;
								this.keyToInfoMap = MoneyUtil.addFarXiuShiCi(pingjieSen, this.keyEntityStr, regexs, this.keyToInfoMap);
								LinkedHashMap<String ,Object> entityResultMap2 = matchTemplate(xml, PreProcess.preProcessForRule(pingjieSen), this.keyToInfoMap);
								if(entityResultMap2.size() > 2){
									this.resultList.add(entityResultMap2);
								}
								this.keyToInfoMap = MoneyUtil.addFarXiuShiCi(beforeAndsen, this.keyEntityStr, regexs, this.keyToInfoMap);
								LinkedHashMap<String ,Object> entityResultMap1 = matchTemplate(xml, PreProcess.preProcessForRule(beforeAndsen), this.keyToInfoMap);
								if(entityResultMap1.size() > 2){
									this.resultList.add(entityResultMap1);
								}
							}else {
								
								this.keyToInfoMap = MoneyUtil.addFarXiuShiCi(sen, this.keyEntityStr, regexs, this.keyToInfoMap);
								LinkedHashMap<String ,Object> entityResultMap1 = matchTemplate(xml, PreProcess.preProcessForRule(sen), this.keyToInfoMap);
								if(entityResultMap1.size() > 2){
									this.resultList.add(entityResultMap1);
								}
							}
									
							
						}else if(andPos >= 0 && andPos < keyEntityStrPos){ //如果包含and keyEntity ...结构
							//String tmpsen = sen.substring(withPos);
							String tmpsen = MatchTemplateUtil.selectAndPhraseWithTime(sen, andPos);
							this.keyToInfoMap = MoneyUtil.addFarXiuShiCi(tmpsen, this.keyEntityStr, regexs, this.keyToInfoMap);
							LinkedHashMap<String ,Object> entityResultMap = matchTemplate(xml, PreProcess.preProcessForRule(tmpsen), this.keyToInfoMap);
							if(entityResultMap.size() > 2){
								this.resultList.add(entityResultMap);
							}
							
						}else{
							
							this.keyToInfoMap = MoneyUtil.addFarXiuShiCi(sen, this.keyEntityStr, regexs, this.keyToInfoMap);
							LinkedHashMap<String ,Object> entityResultMap = matchTemplate(xml, PreProcess.preProcessForRule(sen), this.keyToInfoMap);
							if(entityResultMap.size() > 2){
								this.resultList.add(entityResultMap);
							}
						}
						
					//	if(cashFlowTokenMap!=null){
					//		cashFlowTokenMap.put("cfDescripWord", keyWordDes);
					//		cashFlowTokenMap.put("cfDescripWordCategory", keyWordDesCate);	
					//	}
							
											
					}else{ //一句话中有多个同样的实体  用关键词进行分割
						String[] entityInConmmonStrs = sen.split(" and | with | which |, |means that| while ");
						for(String entityInCommonStr : entityInConmmonStrs){
							
							String keyWordInSenString = MoneyUtil.getTokenStr(entityInCommonStr, keyEntityStr);
							LinkedHashMap<String, Object> cashFlowTokenMap = (LinkedHashMap<String, Object>)keyToInfoMap.get(keyWordInSenString);
							String keyWordDes = null;
							int keyWordDesCate = 0; 
							if(cashFlowTokenMap!=null && cashFlowTokenMap.get("cfDescripWord")!=null){
								keyWordDes = new String(cashFlowTokenMap.get("cfDescripWord").toString()) ;
								keyWordDesCate =  (int)cashFlowTokenMap.get("cfDescripWordCategory");
							}
							
							this.keyToInfoMap = MoneyUtil.addFarXiuShiCi(entityInCommonStr, this.keyEntityStr, regexs, this.keyToInfoMap);

							LinkedHashMap<String ,Object> entityResultMap = matchTemplate(xml, PreProcess.preProcessForRule(entityInCommonStr), this.keyToInfoMap);
							if(entityResultMap.size() > 2){
								this.resultList.add(entityResultMap);
							}
							
							if(cashFlowTokenMap!=null && cashFlowTokenMap.get("cfDescripWord")!=null){
								cashFlowTokenMap.put("cfDescripWord", keyWordDes);
								cashFlowTokenMap.put("cfDescripWordCategory", keyWordDesCate);	
							}
									
						}
					}
					
					
				}																
			}		
			
		}
		this.resultMap.put("Revenue", resultList);
		//this.resultMap = matchTemplate(xml, PreProcess.preProcessForRule(sentence), this.keyToInfoMap);
		//resultMap.put("Sentence", sentenceTmp);
		resultMap.put("SentenceReplaced", sentence);
		
		
	//	long sentenceMatchEndTime = System.currentTimeMillis();
	//	System.out.println("sentenceMatchTime:"+ (sentenceMatchEndTime - sentenceMatchStartTime));

		
		
		return sentence;
	}
	
	
	
	private LinkedHashMap<String, Object> matchTemplate(XmlUtil xml, String changedSentence, LinkedHashMap<String, Object> keyToInfoMap){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		//System.out.println("反射调用之前"+changedSentence);
		//Intention longestIntention = new Intention();
		String longestMatchString = "";
		//Template longestMatchTemplate;
		String methodName = "";
		String className = "";
		String ruleStr="";
		
	//	keyToInfoMap = MoneyUtil.addFarXiuShiCi(changedSentence, keyEntityStr, xml, keyToInfoMap);
		for(Intention intention : xml.intentionList){
			for(Template template: intention.getTemplates()){
				Pattern pattern = Pattern.compile(template.getTemplatetext());
				Matcher matcher = pattern.matcher(changedSentence);
				//methodName = "";
				//className = "";
				//ruleStr="";
				if(matcher.find() && !PreProcess.isCollectedByMaohao(changedSentence, matcher.group(0))){ //匹配到的模板除了关键词还要有其它信息
					if(WordCountUtil.countEntityNum(matcher.group(0)) > WordCountUtil.countEntityNum(longestMatchString)
							||WordCountUtil.countEntityNum(matcher.group(0)) == WordCountUtil.countEntityNum(longestMatchString)&& WordCountUtil.countWordNum(matcher.group(0))< WordCountUtil.countWordNum(longestMatchString)){
						longestMatchString = matcher.group(0);
						className = intention.getName();
						methodName = template.getName();
						ruleStr = template.getName()+" "+template.getTemplatetext();
						//System.out.println(changedSentence);
						//System.out.println(ruleStr);
						//System.out.println(longestMatchString);
						//System.out.println();
					}
				}
			}
		}
		//System.out.println(ruleStr);
		//System.out.println(longestMatchString);
		
		if(longestMatchString!=null&& !longestMatchString.isEmpty()
			&&className!=null&& !className.isEmpty()
			&&methodName!=null&& !methodName.isEmpty()){
			try {
				//String matchedString  = matcher.group(0);
				Class cls = Class.forName(className);
				Object process = cls.newInstance(); 
				Method processMethod = cls.getDeclaredMethod(methodName,String.class,LinkedHashMap.class);  
				result = (LinkedHashMap<String, Object>) processMethod.invoke(process, longestMatchString, keyToInfoMap);//调用xml中对应的方法  					              
				return result;
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println(className+"类未定义");
			} catch (InstantiationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchMethodException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SecurityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		}
			
	
		return result;
		
	}
	
	private List<Point> selectJiaochaPoint(Point currentPosPoint, Set<Point> keySet) {
		// TODO Auto-generated method stub
		List<Point> jiaoChaPoints = new ArrayList<Point>();
			for(Point p : keySet){
				if(p.x < currentPosPoint.x && currentPosPoint.x < p.y 
						|| p.x < currentPosPoint.y && currentPosPoint.y < p.y 
						||p.x >= currentPosPoint.x && currentPosPoint.y >= p.y 
					//	||p.x >= currentPosPoint.x && currentPosPoint.y <= p.y 
						)
					//return p;
					jiaoChaPoints.add(p);
				
			}
		return jiaoChaPoints;
	}
	
	public String getSentenceString() {
		return sentenceString;
	}
	public void setSentenceString(String sentenceString) {
		this.sentenceString = sentenceString;
	}
	public String getChangedString() {
		return changedString;
	} 
	public void setChangedString(String changedString) {
		this.changedString = changedString;
	}
	public LinkedHashMap<String, Object> getKeyToTokenMap() {
		return keyToTokenMap;
	}
	public void setKeyToTokenMap(LinkedHashMap<String, Object> keyToTokenMap) {
		this.keyToTokenMap = keyToTokenMap;
	}
	
	
	public LinkedHashMap<String ,Object> getKeyToInfoMap() {
		return keyToInfoMap;
	}
	public void setKeyToInfoMap(LinkedHashMap<String ,Object> keyToInfoMap) {
		this.keyToInfoMap = keyToInfoMap;
	}
	public LinkedHashMap<String ,Object> getResultMap() {
		return resultMap;
	}
	public void setResultMap(LinkedHashMap<String ,Object> resultMap) {
		this.resultMap = resultMap;
	}
	
	public static void main(String[] args){

		 PrintStream ps;
		try {
			ps = new PrintStream(new FileOutputStream("D:\\extractResult.txt"));
			System.setOut(ps);  
			String fileTest = "D:\\Codes\\javacode\\extractCashFlow3\\src\\main\\resources\\test2.txt";
			String fileTest2 = "D:\\java\\cashFlow\\extractCashFlow3\\src\\main\\resources\\test2.txt";
			String fileTest3 = "D:\\cashFlow.txt";
			for(int i = 1 ; i < 110 ; i++){
				String input = FileUtil.importData(fileTest2, i);
				if(input!=null){
					Revenue senc = new Revenue(input);
				}
				
			}
			
		   // System.out.println("Hello World!");  
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
	       
		//String fileTest = "D:\\java\\extractCashFlow3\\src\\main\\resources\\test.txt";
		//String fileTest = "D:\\Codes\\javacode\\extractCashFlow3\\src\\main\\resources\\test2.txt";
		//Sentence senc = new Sentence(FileUtil.importData(fileTest, 0));
		//String fileTest2 = "D:\\java\\cashFlow\\extractCashFlow3\\src\\main\\resources\\test2.txt";
		//Sentence senc = new Sentence(FileUtil.importData(fileTest2, 7));

		//Sentence senc = new Sentence(Data0.getSentence(3));

		//String fileTest = "D:\\Codes\\javacode\\extractCashFlow3\\src\\main\\resources\\test.txt";
		//String fileTest = "c:\\cashFlow.txt";
		//Sentence senc = new Sentence(FileUtil.importData(fileTest, 0));
		//Sentence senc = new Sentence(Data0.getSentence(6));

		
	}

}
