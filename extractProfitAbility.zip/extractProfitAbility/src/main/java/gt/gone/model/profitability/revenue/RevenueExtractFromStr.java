package gt.gone.model.profitability.revenue;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;

import gt.gone.util.FileUtil;
import gt.gone.util.JsonTool;
import gt.gone.util.PropertyUtil;

public class RevenueExtractFromStr {
	
	public static void main(String[] args) throws FileNotFoundException{

		//String fileTest2 = "C:\\Users\\nlp\\workspace\\extractCashFlow3\\src\\main\\resources\\TestRevenue.txt";
		//String fileTest2 = "C:\\Users\\nlp\\workspace\\extractCashFlow3\\src\\main\\resources\\wrongSentence.txt";
		String fileTest2 = PropertyUtil.getValue("profitablity.input");
		int i = 0 ;
		String input = FileUtil.importData(fileTest2, 3255);
		//input = "Strong yearly sales area will be about $100 million - 150 million in 2019. Strong yearly sales revenue will be about $100 million - 150 million in 2019. Strong yearly cash flow will increase about $100 million - 150 million in 2019. Strong yearly ebitda will increase about $100 million - 150 million in 2019. Strong yearly profit margins will be 15% in 2019.";
		PrintStream ps = new PrintStream(new FileOutputStream("C:\\tmp.txt"));
		if(input!=null){
			RevenueExtract cfe = new RevenueExtract();
			String ans = cfe.extractRevenue(input);
			//JsonFormatTool jst = new JsonFormatTool();
			ps.println(JsonTool.formatJson(ans, "\t"));
			ps.println();
			ps.println();
			System.out.println(JsonTool.formatJson(ans, "\t"));
			System.out.println();
			System.out.println();
		}
		
	}
	

}

