package gt.gone.model.profitability.ebitda;

import gt.gone.util.ConfusedExpUtil;
import gt.gone.util.MoneyUtil;
import java.util.LinkedHashMap;
import java.util.Map;

public class EbitdaProcess {
	
	public String transformKey(String keyWord){
		if(keyWord.contains("税息前利润")){
			return "EBITDA";
		}else if(keyWord.contains("时间")){
			return "Time";
		}else if(keyWord.contains("钱数")){
			return "Money";
		}else if(keyWord.contains("变化")){
			return "Change";
		}else if(keyWord.contains("周期")){
			return "Frequency";
		}
		return "";
	}
	
	public Map<String, Object> commonAction(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		LinkedHashMap<String, Object> tense = new LinkedHashMap<String, Object>();
		String[] tokens = matchedString.split("\\s+");
		//for(String token: tokens){
	
		tense.put("tense", "PAST");
		
		String moneyQuantity=null;
		int moneyQuantityCategory = 0;
		for(int i=0 ; i< tokens.length; i++){
			String token = tokens[i];
			
			if(keyToInfo.containsKey(token)){
				if(token.contains("预计")){
					//System.out.println("预计："+ keyToInfo.get(token));
					tense.put("tense", "FUTURE");
					tense.put("word", keyToInfo.get(token));		
				}
				
				if(token.contains("变化") && ConfusedExpUtil.isRightChangeSentence(matchedString, "#税息前利润")){
					result.put(transformKey(token), keyToInfo.get(token));
				}else 
				if(token.contains("百分比")){
					if(i>0&&(tokens[0].contains("变化")||tokens[1].contains("变化"))
							&&(matchedString.contains("by")||matchedString.contains("at"))){//后面要作修改
						if(result.containsKey("Change")){
							LinkedHashMap<String ,Object> change= (LinkedHashMap<String, Object>) result.get("Change");
							change.put("changeRate", ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("percentText"));
						}
					}
				}else if(token.contains("钱数")){
					LinkedHashMap<String, Object> moneyToken = (LinkedHashMap<String, Object>) keyToInfo.get(token);
					//System.out.println("money==>"+moneyQuantity);
					//System.out.println("moneyQuantity==>"+moneyQuantityCategory);
					if(moneyToken.get("moneyQualityDes")==null||moneyToken.get("moneyQualityDes").toString().isEmpty()){	
						moneyToken.put("moneyQualityDes",  moneyQuantity);
					}
					if(moneyToken.get("moneyQualityCategory")==null||(Integer)moneyToken.get("moneyQualityCategory") == 0){
						moneyToken.put("moneyQualityCategory", moneyQuantityCategory);
						//money.put("moneyQualityDes",  moneyQuantity);
					}
					result.put(transformKey(token), moneyToken);
			
					if(i>0&&(tokens[0].contains("变化")||tokens[1].contains("变化"))
							&&(matchedString.contains("by")||matchedString.contains("at"))){//后面要作修改 有to时感觉没有增长量的含义
						if(result.containsKey("Change")){
							LinkedHashMap<String ,Object> change= (LinkedHashMap<String, Object>) result.get("Change");
							change.put("changeQuatity", ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("money"));
						}
					}
				}else if(token.contains("周期")){
					result.put(transformKey(token), keyToInfo.get(token));
				}else if(token.contains("时间")){
					result.put(transformKey(token), keyToInfo.get(token));
				}else if(token.contains("利润")){
					if(token.contains("利润")){
						if (keyToInfo.get(token) instanceof LinkedHashMap<?, ?>){
							LinkedHashMap<String, Object> cashFlowToken = (LinkedHashMap<String, Object>) keyToInfo.get(token);	
							if(cashFlowToken!=null){
								result.put(transformKey(token), (cashFlowToken.get("cashflow").toString()));
								moneyQuantity = (String) cashFlowToken.get("cfDescripWord");
								moneyQuantityCategory = (Integer) cashFlowToken.get("cfDescripWordCategory");
								if(result.containsKey("money")){
									LinkedHashMap<String ,Object> money= (LinkedHashMap<String, Object>) result.get("Money");
									if(money!=null){
										money.put("moneyQualityCategory", moneyQuantityCategory);
										money.put("moneyQualityDes",  moneyQuantity);
									}
									
									//change.put("changeQuatity", ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("money"));
								}else if(moneyQuantity!=null && !moneyQuantity.isEmpty()){
									LinkedHashMap<String ,Object> moneyEntityMap = new LinkedHashMap<String, Object>();
									
									moneyEntityMap.put("money", null);
									moneyEntityMap.put("moneyNum", null);
									moneyEntityMap.put("moneyCurrencyType", null);
									moneyEntityMap.put("moneyModifier", null);
									moneyEntityMap.put("moneyModifierType", null);
									moneyEntityMap.put("moneyType", null);
									moneyEntityMap.put("moneyMin", null);
									moneyEntityMap.put("moneyMax", null);
									moneyEntityMap.put("moneyQualityCategory",moneyQuantityCategory);
									moneyEntityMap.put("moneyQualityDes", moneyQuantity);
									moneyEntityMap.put("moneyStartPos", 0);
									moneyEntityMap.put("moneyEndPos", 0);
									result.put("Money", moneyEntityMap);
 								}
							}
						}
					}else{
						result.put(transformKey(token),  keyToInfo.get(token));
					}
					
					
				}
			}
			
		}	
		result.put("Tense", tense);
		//result.put("MatchedString", matchedString);
		return result;
	}
	
	public Map<String, Object> rule1(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		LinkedHashMap<String, Object> tense = new LinkedHashMap<String, Object>();
		String[] tokens = matchedString.split("\\s+");
		//for(String token: tokens){
		String changeRate=null;
		tense.put("tense", "PAST");
		String moneyQuantity=null;
		int moneyQuantityCategory = 0;
		for(int i=0 ; i< tokens.length; i++){
			String token = tokens[i];
			if(keyToInfo.containsKey(token)){
				if(token.contains("预计")){
					tense.put("tense", "FUTURE");
					tense.put("word", keyToInfo.get(token));
					
				}else if(token.contains("变化") && ConfusedExpUtil.isRightChangeSentence(matchedString, "#税息前利润")){
					LinkedHashMap<String ,Object> change= (LinkedHashMap<String, Object>)keyToInfo.get(token);
					change.put("changeRate", changeRate);
					result.put(transformKey(token), change);
				}else 
				if(token.contains("百分比")){
					if(i>0&&tokens[i-1].contains("变化")||i < tokens.length-1&&tokens[i+1].contains("变化")
							||i>0&&(tokens[0].contains("变化")||tokens[1].contains("变化"))
							&&(matchedString.contains("by")||matchedString.contains("at")||matchedString.contains(" of "))
							|| i+1< tokens.length && tokens[i+1].contains("变化")
							|| i-1>= 0 && tokens[i-1].contains("变化")
							|| i-4 >= 0 && tokens[i-4].contains("变化")&& tokens[i-3].contains("时间")&& tokens[i-2].contains("averaging")&&(matchedString.contains("by")||matchedString.contains("at")||tokens[i-1].contains("收入")||tokens[i-1].contains("of"))
							|| i-3 >= 0 && tokens[i-3].contains("变化")&& tokens[i-2].contains("时间")&&(matchedString.contains("by")||matchedString.contains("at")||tokens[i-1].contains("收入")||tokens[i-1].contains("of"))		
							|| i-2>= 0 && tokens[i-2].contains("变化")&&(matchedString.contains("by")||matchedString.contains("at")||tokens[i-1].contains("收入")||tokens[i-1].contains("of"))){//后面要作修改
						if(result.containsKey("Change")){
							LinkedHashMap<String ,Object> change= (LinkedHashMap<String, Object>) result.get("Change");
							LinkedHashMap<String ,Object> percent= (LinkedHashMap<String, Object>) keyToInfo.get(token);
							if(percent.containsKey("percentText") && change != null){
								change.put("changeRate", percent.get("percentText").toString());
							}
							
						}else{
							LinkedHashMap<String ,Object> percent= (LinkedHashMap<String, Object>) keyToInfo.get(token);
							if(percent.containsKey("percentText")){
								changeRate = percent.get("percentText").toString();
							}
							
						}
					}
				}else if(token.contains("钱数")){
					//result.put(transformKey(token), keyToInfo.get(token));
					LinkedHashMap<String, Object> moneyToken = (LinkedHashMap<String, Object>) keyToInfo.get(token);
					//System.out.println("money==>"+moneyQuantity);
					//System.out.println("moneyQuantity==>"+moneyQuantityCategory);
					if(moneyToken.get("moneyQualityDes")==null||moneyToken.get("moneyQualityDes").toString().isEmpty()){	
						moneyToken.put("moneyQualityDes",  moneyQuantity);
					}
					if(moneyToken.get("moneyQualityCategory")==null||(Integer)moneyToken.get("moneyQualityCategory") == 0){
						moneyToken.put("moneyQualityCategory", moneyQuantityCategory);
						//money.put("moneyQualityDes",  moneyQuantity);
					}
					result.put(transformKey(token), moneyToken);
					if(i>0&&tokens[i-1].contains("变化")||
							i>0&&(tokens[0].contains("变化")||tokens[1].contains("变化"))
							&&(matchedString.contains("by")||matchedString.contains("at")||matchedString.contains(" of "))
							|| i+1< tokens.length && tokens[i+1].contains("变化")
							|| i-1>= 0 && tokens[i-1].contains("变化")
							|| i-4 >= 0 && tokens[i-4].contains("变化")&& tokens[i-3].contains("时间")&& tokens[i-2].contains("averaging")&&(matchedString.contains("by")||matchedString.contains("at")||tokens[i-1].contains("收入")||tokens[i-1].contains("of"))
							|| i-3 >= 0 && tokens[i-3].contains("变化")&& tokens[i-2].contains("时间")&&(matchedString.contains("by")||matchedString.contains("at")||tokens[i-1].contains("收入")||tokens[i-1].contains("of"))		
							|| i-2>= 0 && tokens[i-2].contains("变化")&&(matchedString.contains("by")||matchedString.contains("at")||tokens[i-1].contains("收入")||tokens[i-1].contains("of"))){//后面要作修改
						if(result.containsKey("Change")){
							LinkedHashMap<String ,Object> change= (LinkedHashMap<String, Object>) result.get("Change");
							change.put("changeQuatity", ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("money"));
						}
					}
				}else if(token.contains("周期")){
					result.put(transformKey(token), keyToInfo.get(token));
				}else if(token.contains("时间")){
					result.put(transformKey(token), keyToInfo.get(token));
				}else if(token.contains("利润")){
					if(token.contains("利润")){
						if (keyToInfo.get(token) instanceof LinkedHashMap<?, ?>){
							LinkedHashMap<String, Object> cashFlowToken = (LinkedHashMap<String, Object>) keyToInfo.get(token);	
							if(cashFlowToken!=null){
								result.put(transformKey(token), (cashFlowToken.get("cashflow").toString()));
								moneyQuantity = (String) cashFlowToken.get("cfDescripWord");
								moneyQuantityCategory = (Integer) cashFlowToken.get("cfDescripWordCategory");
								if(result.containsKey("money")){
									LinkedHashMap<String ,Object> money= (LinkedHashMap<String, Object>) result.get("Money");
									if(money!=null){
										money.put("moneyQualityCategory", moneyQuantityCategory);
										money.put("moneyQualityDes",  moneyQuantity);
									}
									
									//change.put("changeQuatity", ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("money"));
								}else if(moneyQuantity!=null && !moneyQuantity.isEmpty()){
									LinkedHashMap<String ,Object> moneyEntityMap = new LinkedHashMap<String, Object>();
									
									moneyEntityMap.put("money", null);
									moneyEntityMap.put("moneyNum", null);
									moneyEntityMap.put("moneyCurrencyType", null);
									moneyEntityMap.put("moneyModifier", null);
									moneyEntityMap.put("moneyModifierType", null);
									moneyEntityMap.put("moneyType", null);
									moneyEntityMap.put("moneyMin", null);
									moneyEntityMap.put("moneyMax", null);
									moneyEntityMap.put("moneyQualityCategory",moneyQuantityCategory);
									moneyEntityMap.put("moneyQualityDes", moneyQuantity);
									moneyEntityMap.put("moneyStartPos", 0);
									moneyEntityMap.put("moneyEndPos", 0);
									result.put("Money", moneyEntityMap);
 								}
							}
						}
					}else{
						result.put(transformKey(token),  keyToInfo.get(token));
					}
					
				}
			}
			
		}
		result.put("Tense", tense);
		//result.put("MatchedString", matchedString);
		return result;
	}
	
	public Map<String, Object> rule2(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		LinkedHashMap<String, Object> tense = new LinkedHashMap<String, Object>();
		String[] tokens = matchedString.split("\\s+");
		//for(String token: tokens){
	
			tense.put("tense", "PAST");
		
			String moneyQuantity=null;
			String changeRate=null;
			int moneyQuantityCategory = 0;
		for(int i=0 ; i< tokens.length; i++){
			String token = tokens[i];
			if(keyToInfo.containsKey(token)){
				if(token.contains("预计")){
					tense.put("tense", "FUTURE");
					tense.put("word", keyToInfo.get(token));
					
				}else
				
				if(token.contains("变化") && ConfusedExpUtil.isRightChangeSentence(matchedString, "#税息前利润")){
					//result.put(transformKey(token), keyToInfo.get(token));
					LinkedHashMap<String ,Object> change= (LinkedHashMap<String, Object>)keyToInfo.get(token);
					change.put("changeRate", changeRate);
					result.put(transformKey(token), change);
				}else if(token.contains("百分比")){
					if(i>0 && (tokens[0].contains("变化")||tokens[1].contains("变化"))
							&&(matchedString.contains("by")||matchedString.contains("at"))
							|| i+1< tokens.length && tokens[i+1].contains("变化")
							|| i-1>= 0 && tokens[i-1].contains("变化")
							|| i+1< tokens.length && tokens[i+1].contains("税息前利润")&&i+2< tokens.length && tokens[i+2].contains("变化")
							|| i-2>= 0 && tokens[i-2].contains("变化")&&(matchedString.contains("by")||matchedString.contains("at"))){//后面要作修改
						/*if(result.containsKey("Change")){
							//LinkedHashMap<String ,Object> change= (LinkedHashMap<String, Object>) result.get("Change");
							//change.put("changeRate", ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("percentText"));
							
						}*/
						if(result.containsKey("Change")){
							LinkedHashMap<String ,Object> change= (LinkedHashMap<String, Object>) result.get("Change");
							LinkedHashMap<String ,Object> percent= (LinkedHashMap<String, Object>) keyToInfo.get(token);
							if(percent.containsKey("percentText") && change != null){
								change.put("changeRate", percent.get("percentText").toString());
							}
							
						}else{
							LinkedHashMap<String ,Object> percent= (LinkedHashMap<String, Object>) keyToInfo.get(token);
							if(percent.containsKey("percentText")){
								changeRate = percent.get("percentText").toString();
							}
							
						}
					}
				}else if(token.contains("钱数")){
					//result.put(transformKey(token), keyToInfo.get(token));
					LinkedHashMap<String, Object> moneyToken = (LinkedHashMap<String, Object>) keyToInfo.get(token);
					//System.out.println("money==>"+moneyQuantity);
					//System.out.println("moneyQuantity==>"+moneyQuantityCategory);
					if(moneyToken.get("moneyQualityDes")==null||moneyToken.get("moneyQualityDes").toString().isEmpty()){	
						moneyToken.put("moneyQualityDes",  moneyQuantity);
					}
					if(moneyToken.get("moneyQualityCategory")==null||(Integer)moneyToken.get("moneyQualityCategory") == 0){
						moneyToken.put("moneyQualityCategory", moneyQuantityCategory);
						//money.put("moneyQualityDes",  moneyQuantity);
					}
					result.put(transformKey(token), moneyToken);
					if(i>0 && (tokens[0].contains("变化")||tokens[1].contains("变化"))
							&&(matchedString.contains("by")||matchedString.contains("at"))
							|| i+1< tokens.length && tokens[i+1].contains("变化")
							|| i-1>= 0 && tokens[i-1].contains("变化")
							|| i+1< tokens.length && tokens[i+1].contains("税息前利润")&&i+2< tokens.length && tokens[i+2].contains("变化")
							|| i-2>= 0 && tokens[i-2].contains("变化")&&(matchedString.contains("by")||matchedString.contains("at"))){
						if(result.containsKey("Change")){
							LinkedHashMap<String ,Object> change= (LinkedHashMap<String, Object>) result.get("Change");
							change.put("changeQuatity", ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("money"));
						}
					}
				}else if(token.contains("周期")){
					result.put(transformKey(token), keyToInfo.get(token));
				}else if(token.contains("时间")){
					result.put(transformKey(token), keyToInfo.get(token));
				}else if(token.contains("利润")){
					if(token.contains("利润")){
						if (keyToInfo.get(token) instanceof LinkedHashMap<?, ?>){
							LinkedHashMap<String, Object> cashFlowToken = (LinkedHashMap<String, Object>) keyToInfo.get(token);	
							if(cashFlowToken!=null){
								result.put(transformKey(token), (cashFlowToken.get("cashflow").toString()));
								moneyQuantity = (String) cashFlowToken.get("cfDescripWord");
								moneyQuantityCategory = (Integer) cashFlowToken.get("cfDescripWordCategory");
								if(result.containsKey("money")){
									LinkedHashMap<String ,Object> money= (LinkedHashMap<String, Object>) result.get("Money");
									if(money!=null){
										money.put("moneyQualityCategory", moneyQuantityCategory);
										money.put("moneyQualityDes",  moneyQuantity);
									}
									
									//change.put("changeQuatity", ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("money"));
								}else if(moneyQuantity!=null && !moneyQuantity.isEmpty()){
									LinkedHashMap<String ,Object> moneyEntityMap = new LinkedHashMap<String, Object>();
									
									moneyEntityMap.put("money", null);
									moneyEntityMap.put("moneyNum", null);
									moneyEntityMap.put("moneyCurrencyType", null);
									moneyEntityMap.put("moneyModifier", null);
									moneyEntityMap.put("moneyModifierType", null);
									moneyEntityMap.put("moneyType", null);
									moneyEntityMap.put("moneyMin", null);
									moneyEntityMap.put("moneyMax", null);
									moneyEntityMap.put("moneyQualityCategory",moneyQuantityCategory);
									moneyEntityMap.put("moneyQualityDes", moneyQuantity);
									moneyEntityMap.put("moneyStartPos", 0);
									moneyEntityMap.put("moneyEndPos", 0);
									result.put("Money", moneyEntityMap);
 								}
							}
						}
					}else{
						result.put(transformKey(token),  keyToInfo.get(token));
					}
					
				}
			}
			
		}
		result.put("Tense", tense);
		//result.put("MatchedString", matchedString);
		return result;
	}
	public Map<String, Object> rule3(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		LinkedHashMap<String, Object> tense = new LinkedHashMap<String, Object>();
		String[] tokens = matchedString.split("\\s+");
		//for(String token: tokens){
		
			tense.put("tense", "PAST");
			
			String moneyQuantity=null;
			int moneyQuantityCategory = 0;
		for(int i=0 ; i< tokens.length; i++){
			String token = tokens[i];
			if(keyToInfo.containsKey(token)){
				if(token.contains("预计")){
					tense.put("tense", "FUTURE");
					tense.put("word", keyToInfo.get(token));
					//result.put("Tense", tense);
				}else if(token.contains("变化") && ConfusedExpUtil.isRightChangeSentence(matchedString, "#税息前利润")){
					result.put(transformKey(token), keyToInfo.get(token));
				}else 
				if(token.contains("百分比")){
					if(i>0 && (tokens[0].contains("变化")||tokens[1].contains("变化"))
							&&(matchedString.contains("by")||matchedString.contains("at"))
							|| i+1< tokens.length && tokens[i+1].contains("变化")
							|| i-1>= 0 && tokens[i-1].contains("变化")
							|| i+1< tokens.length && tokens[i+1].contains("税息前利润")&&i+2< tokens.length && tokens[i+2].contains("变化")
							|| i-2>= 0 && tokens[i-2].contains("变化")&&(matchedString.contains("by")||matchedString.contains("at"))){//后面要作修改
						if(result.containsKey("Change")){
							LinkedHashMap<String ,Object> change= (LinkedHashMap<String, Object>) result.get("Change");
							change.put("changeRate", ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("percentText"));
						}
					}else {
						String ebitdaToken = matchedString.substring(matchedString.indexOf("#税息前利润"),matchedString.indexOf("#税息前利润")+"#税息前利润".length()+2).trim();
						if(ebitdaToken!=null){
							String ebitdaWord = keyToInfo.get(ebitdaToken).toString();
							if(ebitdaWord!= null && ebitdaWord.contains("margin")){
								LinkedHashMap<String, Object> percentToken = (LinkedHashMap<String, Object>) keyToInfo.get(token);
								LinkedHashMap<String, Object> moneyToken = new LinkedHashMap<String, Object>();
								moneyToken.put("money", percentToken.get("percentText"));
								moneyToken.put("moneyNum", percentToken.get("percentText"));

								//System.out.println("money==>"+moneyQuantity);
								//System.out.println("moneyQuantity==>"+moneyQuantityCategory);
								if(moneyToken.get("moneyQualityDes")==null||moneyToken.get("moneyQualityDes").toString().isEmpty()){	
									moneyToken.put("moneyQualityDes",  moneyQuantity);
								}
								if(moneyToken.get("moneyQualityCategory")==null||(Integer)moneyToken.get("moneyQualityCategory") == 0){
									moneyToken.put("moneyQualityCategory", moneyQuantityCategory);
									//money.put("moneyQualityDes",  moneyQuantity);
								}
								result.put("Money", moneyToken);
							}
						}
						
					}
				}else if(token.contains("钱数")){
					//result.put(transformKey(token), keyToInfo.get(token));
					LinkedHashMap<String, Object> moneyToken = (LinkedHashMap<String, Object>) keyToInfo.get(token);
					//System.out.println("money==>"+moneyQuantity);
					//System.out.println("moneyQuantity==>"+moneyQuantityCategory);
					if(moneyToken.get("moneyQualityDes")==null||moneyToken.get("moneyQualityDes").toString().isEmpty()){	
						moneyToken.put("moneyQualityDes",  moneyQuantity);
					}
					if(moneyToken.get("moneyQualityCategory")==null||(Integer)moneyToken.get("moneyQualityCategory") == 0){
						moneyToken.put("moneyQualityCategory", moneyQuantityCategory);
						//money.put("moneyQualityDes",  moneyQuantity);
					}
					result.put(transformKey(token), moneyToken);
					if(i>0 && (tokens[0].contains("变化")||tokens[1].contains("变化"))
							&&(matchedString.contains("by")||matchedString.contains("at"))
							|| i+1< tokens.length && tokens[i+1].contains("变化")
							|| i-1>= 0 && tokens[i-1].contains("变化")
							|| i+1< tokens.length && tokens[i+1].contains("税息前利润")&&i+2< tokens.length && tokens[i+2].contains("变化")
							|| i-2>= 0 && tokens[i-2].contains("变化")&&(matchedString.contains("by")||matchedString.contains("at"))){//后面要作修改 有to时感觉没有增长量的含义
						if(result.containsKey("Change")){
							LinkedHashMap<String ,Object> change= (LinkedHashMap<String, Object>) result.get("Change");
							change.put("changeQuatity", ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("money"));
						}
					}
				}else if(token.contains("周期")){
					result.put(transformKey(token), keyToInfo.get(token));
				}else if(token.contains("时间")){
					result.put(transformKey(token), keyToInfo.get(token));
				}else if(token.contains("税息前利润")){
					if(token.contains("税息前利润")){
						if (keyToInfo.get(token) instanceof LinkedHashMap<?, ?>){
							LinkedHashMap<String, Object> cashFlowToken = (LinkedHashMap<String, Object>) keyToInfo.get(token);	
							if(cashFlowToken!=null){
								result.put(transformKey(token), (cashFlowToken.get("cashflow").toString()));
								moneyQuantity = (String) cashFlowToken.get("cfDescripWord");
								moneyQuantityCategory = (Integer) cashFlowToken.get("cfDescripWordCategory");
								if(result.containsKey("money")){
									LinkedHashMap<String ,Object> money= (LinkedHashMap<String, Object>) result.get("Money");
									if(money!=null){
										money.put("moneyQualityCategory", moneyQuantityCategory);
										money.put("moneyQualityDes",  moneyQuantity);
									}
									
									//change.put("changeQuatity", ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("money"));
								}else if(moneyQuantity!=null && !moneyQuantity.isEmpty()){
									LinkedHashMap<String ,Object> moneyEntityMap = new LinkedHashMap<String, Object>();
									
									moneyEntityMap.put("money", null);
									moneyEntityMap.put("moneyNum", null);
									moneyEntityMap.put("moneyCurrencyType", null);
									moneyEntityMap.put("moneyModifier", null);
									moneyEntityMap.put("moneyModifierType", null);
									moneyEntityMap.put("moneyType", null);
									moneyEntityMap.put("moneyMin", null);
									moneyEntityMap.put("moneyMax", null);
									moneyEntityMap.put("moneyQualityCategory",moneyQuantityCategory);
									moneyEntityMap.put("moneyQualityDes", moneyQuantity);
									moneyEntityMap.put("moneyStartPos", 0);
									moneyEntityMap.put("moneyEndPos", 0);
									result.put("Money", moneyEntityMap);
 								}
							}
						}
					}else{
						result.put(transformKey(token),  keyToInfo.get(token));
					}
					
				}
			}
			
		}
		result.put("Tense", tense);
		//result.put("MatchedString", matchedString);
		return result;
	}
	public Map<String, Object> rule4(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		return commonAction(matchedString, keyToInfo);
	}
	public Map<String, Object> rule5(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		return commonAction(matchedString, keyToInfo);
	}
	public Map<String, Object> rule6(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		return commonAction(matchedString, keyToInfo);
	}
	public Map<String, Object> rule7(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		return rule2(matchedString, keyToInfo);
	}
	public Map<String, Object> rule8(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		return rule5(matchedString, keyToInfo);
	}
}
