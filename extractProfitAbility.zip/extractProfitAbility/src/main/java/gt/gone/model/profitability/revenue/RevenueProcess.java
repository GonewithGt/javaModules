package gt.gone.model.profitability.revenue;

import gt.gone.util.ConfusedExpUtil;
import gt.gone.util.MoneyUtil;

import java.util.LinkedHashMap;
import java.util.Map;

public class RevenueProcess {
	
	public String transformKey(String keyWord){
		if(keyWord.contains("收入")){
			return "Revenue";
		}else if(keyWord.contains("时间")){
			return "Time";
		}else if(keyWord.contains("钱数")){
			return "Money";
		}else if(keyWord.contains("变化")){
			return "Change";
		}else if(keyWord.contains("周期")){
			return "Frequency";
		}
		return "";
	}
	
	public Map<String, Object> commonAction(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		LinkedHashMap<String, Object> tense = new LinkedHashMap<String, Object>();
		String[] tokens = matchedString.split("\\s+");
		//for(String token: tokens){
		String moneyNum=null;
		tense.put("tense", "PAST");
		String changeRate = null;
		String moneyQuantity=null;
		int moneyQuantityCategory = 0;
		for(int i=0 ; i< tokens.length; i++){
			String token = tokens[i];
			
			if(keyToInfo.containsKey(token)){
				if(token.contains("预计")){
					//System.out.println("预计："+ keyToInfo.get(token));
					tense.put("tense", "FUTURE");
					tense.put("word", keyToInfo.get(token));		
				}
				
				if(token.contains("变化")&&ConfusedExpUtil.isRightChangeSentence(matchedString, "#收入")){
					result.put(transformKey(token), keyToInfo.get(token));
				}else 
				if(token.contains("百分比")){
					/*if(i>0&&tokens[0].contains("变化")
							&&matchedString.contains("by")){//后面要作修改
						if(result.containsKey("Change")){
							LinkedHashMap<String ,Object> change= (LinkedHashMap<String, Object>) result.get("Change");
							change.put("changeRate", keyToInfo.get(token));
						}
					}*/
					
					if(i>0 && tokens[0].contains("变化")
							&&(matchedString.contains("by")||matchedString.contains("at"))
							|| i+1< tokens.length && tokens[i+1].contains("变化")
							|| i-1>= 0 && tokens[i-1].contains("变化")
							|| i-2>= 0 && tokens[i-2].contains("变化")&&(matchedString.contains("by")||matchedString.contains("at"))){//后面要作修改
						changeRate = (String) ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("percentText");
						if(result.containsKey("Change")){
							LinkedHashMap<String ,Object> change= (LinkedHashMap<String, Object>) result.get("Change");
							change.put("changeRate", changeRate);
						}
						
					}
				}else if(token.contains("钱数")){
					LinkedHashMap<String, Object> moneyToken = (LinkedHashMap<String, Object>) keyToInfo.get(token);
					//System.out.println("money==>"+moneyQuantity);
					//System.out.println("moneyQuantity==>"+moneyQuantityCategory);
					
					result.put(transformKey(token), moneyToken);
			
					if(i>0&&tokens[0].contains("变化")
							&&matchedString.contains("by")){//后面要作修改 有to时感觉没有增长量的含义
						if(result.containsKey("Change")){
							LinkedHashMap<String ,Object> change= (LinkedHashMap<String, Object>) result.get("Change");
							change.put("changeQuatity", ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("money"));
						}
					}else{
						if(moneyToken.get("moneyQualityDes")==null||moneyToken.get("moneyQualityDes").toString().isEmpty()){	
							moneyToken.put("moneyQualityDes",  moneyQuantity);
						}
						if(moneyToken.get("moneyQualityCategory")==null||(Integer)moneyToken.get("moneyQualityCategory") == 0){
							moneyToken.put("moneyQualityCategory", moneyQuantityCategory);
							//money.put("moneyQualityDes",  moneyQuantity);
						}
					}
				}else if(token.contains("周期")){
					result.put(transformKey(token), keyToInfo.get(token));
				}else if(token.contains("时间")){
					result.put(transformKey(token), keyToInfo.get(token));
				}else if(token.contains("收入")){
					if(token.contains("收入")){
						if (keyToInfo.get(token) instanceof LinkedHashMap<?, ?>){
							LinkedHashMap<String, Object> cashFlowToken = (LinkedHashMap<String, Object>) keyToInfo.get(token);	
							if(cashFlowToken!=null){
								result.put(transformKey(token), (cashFlowToken.get("cashflow").toString()));
								moneyQuantity = (String) cashFlowToken.get("cfDescripWord");
								moneyQuantityCategory = (Integer) cashFlowToken.get("cfDescripWordCategory");
								if(result.containsKey("money")){
									LinkedHashMap<String ,Object> money= (LinkedHashMap<String, Object>) result.get("Money");
									if(money!=null){
										money.put("moneyQualityCategory", moneyQuantityCategory);
										money.put("moneyQualityDes",  moneyQuantity);
									}
									
									//change.put("changeQuatity", ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("money"));
								}else if(moneyQuantity!=null && !moneyQuantity.isEmpty()){
									LinkedHashMap<String ,Object> moneyEntityMap = new LinkedHashMap<String, Object>();
									
									moneyEntityMap.put("money", null);
									moneyEntityMap.put("moneyNum", null);
									moneyEntityMap.put("moneyCurrencyType", null);
									moneyEntityMap.put("moneyModifier", null);
									moneyEntityMap.put("moneyModifierType", null);
									moneyEntityMap.put("moneyType", null);
									moneyEntityMap.put("moneyMin", null);
									moneyEntityMap.put("moneyMax", null);
									moneyEntityMap.put("moneyQualityCategory",moneyQuantityCategory);
									moneyEntityMap.put("moneyQualityDes", moneyQuantity);
									moneyEntityMap.put("moneyStartPos", 0);
									moneyEntityMap.put("moneyEndPos", 0);
									result.put("Money", moneyEntityMap);
 								}
							}
						}
					}else{
						result.put(transformKey(token),  keyToInfo.get(token));
					}
					
					
				}
			}
			
		}	
		result.put("Tense", tense);
		//result.put("MatchedString", matchedString);
		return result;
	}
	
	public Map<String, Object> rule1(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		LinkedHashMap<String, Object> tense = new LinkedHashMap<String, Object>();
		String[] tokens = matchedString.split("\\s+");
		//for(String token: tokens){
		
		tense.put("tense", "PAST");
		String moneyQuantity=null;
		int moneyQuantityCategory = 0;
		for(int i=0 ; i< tokens.length; i++){
			String token = tokens[i];
			if(keyToInfo.containsKey(token)){
				if(token.contains("预计")){
					tense.put("tense", "FUTURE");
					tense.put("word", keyToInfo.get(token));
					
				}else if(token.contains("变化")&&ConfusedExpUtil.isRightChangeSentence(matchedString, "#收入")){
					result.put(transformKey(token), keyToInfo.get(token));
				}else 
				if(token.contains("百分比")){
					if(i>0&&tokens[i-1].contains("变化")
							||i>1&&tokens[i-2].contains("变化")&&tokens[i-1].contains("by")
							||i>1&&tokens[i-2].contains("变化")&&tokens[i-1].contains("of")
							/*||i>1&&tokens[i-2].contains("变化")&&tokens[i-1].contains("to")*/){//后面要作修改
						if(result.containsKey("Change")){
							LinkedHashMap<String ,Object> change= (LinkedHashMap<String, Object>) result.get("Change");
							change.put("changeRate", keyToInfo.get(token));
						}
					}
				}else if(token.contains("钱数")){
					//result.put(transformKey(token), keyToInfo.get(token));
					LinkedHashMap<String, Object> moneyToken = (LinkedHashMap<String, Object>) keyToInfo.get(token);
					//System.out.println("money==>"+moneyQuantity);
					//System.out.println("moneyQuantity==>"+moneyQuantityCategory);
					
					if(i>0&&tokens[i-1].contains("变化")
							/*||i>1&&tokens[i-2].contains("变化")&&tokens[i-1].contains("to")*/){//后面要作修改 有to时感觉没有增长量的含义
						if(result.containsKey("Change")){
							LinkedHashMap<String ,Object> change= (LinkedHashMap<String, Object>) result.get("Change");
							change.put("changeQuatity", ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("money"));
						}
					}else{
						if(moneyToken.get("moneyQualityDes")==null||moneyToken.get("moneyQualityDes").toString().isEmpty()){	
							moneyToken.put("moneyQualityDes",  moneyQuantity);
						}
						if(moneyToken.get("moneyQualityCategory")==null||(Integer)moneyToken.get("moneyQualityCategory") == 0){
							moneyToken.put("moneyQualityCategory", moneyQuantityCategory);
							//money.put("moneyQualityDes",  moneyQuantity);
						}
						result.put(transformKey(token), moneyToken);
					}
				}else if(token.contains("周期")){
					result.put(transformKey(token), keyToInfo.get(token));
				}else if(token.contains("时间")){
					result.put(transformKey(token), keyToInfo.get(token));
				}else if(token.contains("收入")){
					if(token.contains("收入")){
						if (keyToInfo.get(token) instanceof LinkedHashMap<?, ?>){
							LinkedHashMap<String, Object> cashFlowToken = (LinkedHashMap<String, Object>) keyToInfo.get(token);	
							if(cashFlowToken!=null){
								result.put(transformKey(token), (cashFlowToken.get("cashflow").toString()));
								moneyQuantity = (String) cashFlowToken.get("cfDescripWord");
								moneyQuantityCategory = (Integer) cashFlowToken.get("cfDescripWordCategory");
								if(result.containsKey("money")){
									LinkedHashMap<String ,Object> money= (LinkedHashMap<String, Object>) result.get("Money");
									if(money!=null){
										money.put("moneyQualityCategory", moneyQuantityCategory);
										money.put("moneyQualityDes",  moneyQuantity);
									}
									
									//change.put("changeQuatity", ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("money"));
								}else if(moneyQuantity!=null && !moneyQuantity.isEmpty()){
									LinkedHashMap<String ,Object> moneyEntityMap = new LinkedHashMap<String, Object>();
									
									moneyEntityMap.put("money", null);
									moneyEntityMap.put("moneyNum", null);
									moneyEntityMap.put("moneyCurrencyType", null);
									moneyEntityMap.put("moneyModifier", null);
									moneyEntityMap.put("moneyModifierType", null);
									moneyEntityMap.put("moneyType", null);
									moneyEntityMap.put("moneyMin", null);
									moneyEntityMap.put("moneyMax", null);
									moneyEntityMap.put("moneyQualityCategory",moneyQuantityCategory);
									moneyEntityMap.put("moneyQualityDes", moneyQuantity);
									moneyEntityMap.put("moneyStartPos", 0);
									moneyEntityMap.put("moneyEndPos", 0);
									result.put("Money", moneyEntityMap);
 								}
							}
						}
					}else{
						result.put(transformKey(token),  keyToInfo.get(token));
					}
					
				}
			}
			
		}
		result.put("Tense", tense);
		//result.put("MatchedString", matchedString);
		return result;
	}
	
	public Map<String, Object> rule2(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		LinkedHashMap<String, Object> tense = new LinkedHashMap<String, Object>();
		String[] tokens = matchedString.split("\\s+");
		//for(String token: tokens){
	
			tense.put("tense", "PAST");
		
			String moneyQuantity=null;
			int moneyQuantityCategory = 0;
			String changeRate = null;
		for(int i=0 ; i< tokens.length; i++){
			String token = tokens[i];
			if(keyToInfo.containsKey(token)){
				if(token.contains("预计")){
					tense.put("tense", "FUTURE");
					tense.put("word", keyToInfo.get(token));
					
				}else
				
				if(token.contains("变化") && ConfusedExpUtil.isRightChangeSentence(matchedString, "#收入")){
					
					LinkedHashMap<String, Object> change = (LinkedHashMap<String, Object>)keyToInfo.get(token);
					if(change.get("changeRate")==null ||change.get("changeRate").toString().isEmpty()){
						change.put("changeRate", changeRate);
					}
					
					result.put(transformKey(token), change);
				}else if(token.contains("百分比")){
					if(i>0&&(tokens[0].contains("变化")||tokens[1].contains("变化"))
							&&(matchedString.contains("by")||matchedString.contains("at")||matchedString.contains(" of "))
							|| i+1< tokens.length && tokens[i+1].contains("变化")
							|| i-1>= 0 && tokens[i-1].contains("变化")
							|| i-4 >= 0 && tokens[i-4].contains("变化")&& tokens[i-3].contains("时间")&& tokens[i-2].contains("averaging")&&(matchedString.contains("by")||matchedString.contains("at")||tokens[i-1].contains("收入")||tokens[i-1].contains("of"))
							|| i-3 >= 0 && tokens[i-3].contains("变化")&& tokens[i-2].contains("时间")&&(matchedString.contains("by")||matchedString.contains("at")||tokens[i-1].contains("收入")||tokens[i-1].contains("of"))		
							|| i-2>= 0 && tokens[i-2].contains("变化")&&(matchedString.contains("by")||matchedString.contains("at")||tokens[i-1].contains("收入")||tokens[i-1].contains("of"))){//后面要作修改
						changeRate = (String) ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("percentText");
						if(result.containsKey("Change")){
							LinkedHashMap<String ,Object> change= (LinkedHashMap<String, Object>) result.get("Change");
							change.put("changeRate", changeRate);
						}
						
					}
				}else if(token.contains("钱数")){
					//result.put(transformKey(token), keyToInfo.get(token));
					LinkedHashMap<String, Object> moneyToken = (LinkedHashMap<String, Object>) keyToInfo.get(token);
					//System.out.println("money==>"+moneyQuantity);
					//System.out.println("moneyQuantity==>"+moneyQuantityCategory);
					
					if(i>0&&(tokens[0].contains("变化")||tokens[1].contains("变化"))
							&&matchedString.contains("by")
							&&(matchedString.contains("by")||matchedString.contains("at"))
							|| i+1< tokens.length && tokens[i+1].contains("变化")
							|| i-4 >= 0 && tokens[i-4].contains("变化")&& tokens[i-3].contains("时间")&& tokens[i-2].contains("averaging")&&(matchedString.contains("by")||matchedString.contains("at")||tokens[i-1].contains("收入")||tokens[i-1].contains("of"))
							|| i-3 >= 0 && tokens[i-3].contains("变化")&& tokens[i-2].contains("时间")&&(matchedString.contains("by")||matchedString.contains("at")||tokens[i-1].contains("收入")||tokens[i-1].contains("of"))		

							|| i-1>= 0 && tokens[i-1].contains("变化")
							|| i-2>= 0 && tokens[i-2].contains("变化")&&(matchedString.contains("by")||matchedString.contains("at")||tokens[i-1].contains("收入")||tokens[i-1].contains("of"))){
						if(result.containsKey("Change")){
							LinkedHashMap<String ,Object> change= (LinkedHashMap<String, Object>) result.get("Change");
							change.put("changeQuatity", ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("money"));
						}
					}else {
						if(moneyToken.get("moneyQualityDes")==null||moneyToken.get("moneyQualityDes").toString().isEmpty()){	
							moneyToken.put("moneyQualityDes",  moneyQuantity);
						}
						if(moneyToken.get("moneyQualityCategory")==null||(Integer)moneyToken.get("moneyQualityCategory") == 0){
							moneyToken.put("moneyQualityCategory", moneyQuantityCategory);
						//money.put("moneyQualityDes",  moneyQuantity);
						}
						result.put(transformKey(token), moneyToken);
					}
				}else if(token.contains("周期")){
					result.put(transformKey(token), keyToInfo.get(token));
				}else if(token.contains("时间")){
					result.put(transformKey(token), keyToInfo.get(token));
				}else if(token.contains("收入")){
					if(token.contains("收入")){
						if (keyToInfo.get(token) instanceof LinkedHashMap<?, ?>){
							LinkedHashMap<String, Object> cashFlowToken = (LinkedHashMap<String, Object>) keyToInfo.get(token);	
							if(cashFlowToken!=null){
								result.put(transformKey(token), (cashFlowToken.get("cashflow").toString()));
								moneyQuantity = (String) cashFlowToken.get("cfDescripWord");
								moneyQuantityCategory = (Integer) cashFlowToken.get("cfDescripWordCategory");
								if(result.containsKey("money")){
									LinkedHashMap<String ,Object> money= (LinkedHashMap<String, Object>) result.get("Money");
									if(money!=null){
										money.put("moneyQualityCategory", moneyQuantityCategory);
										money.put("moneyQualityDes",  moneyQuantity);
									}
									
									//change.put("changeQuatity", ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("money"));
								}else if(moneyQuantity!=null && !moneyQuantity.isEmpty()){
									LinkedHashMap<String ,Object> moneyEntityMap = new LinkedHashMap<String, Object>();
									
									moneyEntityMap.put("money", null);
									moneyEntityMap.put("moneyNum", null);
									moneyEntityMap.put("moneyCurrencyType", null);
									moneyEntityMap.put("moneyModifier", null);
									moneyEntityMap.put("moneyModifierType", null);
									moneyEntityMap.put("moneyType", null);
									moneyEntityMap.put("moneyMin", null);
									moneyEntityMap.put("moneyMax", null);
									moneyEntityMap.put("moneyQualityCategory",moneyQuantityCategory);
									moneyEntityMap.put("moneyQualityDes", moneyQuantity);
									moneyEntityMap.put("moneyStartPos", 0);
									moneyEntityMap.put("moneyEndPos", 0);
									result.put("Money", moneyEntityMap);
 								}
							}
						}
					}else{
						result.put(transformKey(token),  keyToInfo.get(token));
					}
					
				}
			}
			
		}
		result.put("Tense", tense);
		//result.put("MatchedString", matchedString);
		return result;
	}
	public Map<String, Object> rule3(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		LinkedHashMap<String, Object> tense = new LinkedHashMap<String, Object>();
		String[] tokens = matchedString.split("\\s+");
		//for(String token: tokens){
		
			tense.put("tense", "PAST");
			
			String moneyQuantity=null;
			int moneyQuantityCategory = 0;
		for(int i=0 ; i< tokens.length; i++){
			String token = tokens[i];
			if(keyToInfo.containsKey(token)){
				if(token.contains("预计")){
					tense.put("tense", "FUTURE");
					tense.put("word", keyToInfo.get(token));
					//result.put("Tense", tense);
				}else if(token.contains("变化") && ConfusedExpUtil.isRightChangeSentence(matchedString, "#收入")){
					result.put(transformKey(token), keyToInfo.get(token));
				}else 
				if(token.contains("百分比")){
					if(i>0&&(tokens[0].contains("变化")||tokens[1].contains("变化"))
							&&(matchedString.contains("by")||matchedString.contains("at")||matchedString.contains(" of "))
							|| i+1< tokens.length && tokens[i+1].contains("变化")
							|| i-4 >= 0 && tokens[i-4].contains("变化")&& tokens[i-3].contains("时间")&& tokens[i-2].contains("averaging")&&(matchedString.contains("by")||matchedString.contains("at")||tokens[i-1].contains("收入")||tokens[i-1].contains("of"))
							|| i-3 >= 0 && tokens[i-3].contains("变化")&& tokens[i-2].contains("时间")&&(matchedString.contains("by")||matchedString.contains("at")||tokens[i-1].contains("收入")||tokens[i-1].contains("of"))		

							|| i-1>= 0 && tokens[i-1].contains("变化")
							|| i-2>= 0 && tokens[i-2].contains("变化")&&(matchedString.contains("by")||matchedString.contains("at")||tokens[i-1].contains("收入"))){//后面要作修改
						if(result.containsKey("Change")){
							LinkedHashMap<String ,Object> change= (LinkedHashMap<String, Object>) result.get("Change");
							change.put("changeRate", keyToInfo.get(token));
						}
					}
				}else if(token.contains("钱数")){
					//result.put(transformKey(token), keyToInfo.get(token));
					LinkedHashMap<String, Object> moneyToken = (LinkedHashMap<String, Object>) keyToInfo.get(token);
					//System.out.println("money==>"+moneyQuantity);
					//System.out.println("moneyQuantity==>"+moneyQuantityCategory);
					if(moneyToken.get("moneyQualityDes")==null||moneyToken.get("moneyQualityDes").toString().isEmpty()){	
						moneyToken.put("moneyQualityDes",  moneyQuantity);
					}
					if(moneyToken.get("moneyQualityCategory")==null||(Integer)moneyToken.get("moneyQualityCategory") == 0){
						moneyToken.put("moneyQualityCategory", moneyQuantityCategory);
						//money.put("moneyQualityDes",  moneyQuantity);
					}
					result.put(transformKey(token), moneyToken);
					if(i>0&&(tokens[0].contains("变化")||tokens[1].contains("变化"))
							&&(matchedString.contains("by")||matchedString.contains("at")||matchedString.contains(" of "))
							|| i+1< tokens.length && tokens[i+1].contains("变化")
							|| i-4 >= 0 && tokens[i-4].contains("变化")&& tokens[i-3].contains("时间")&& tokens[i-2].contains("averaging")&&(matchedString.contains("by")||matchedString.contains("at")||tokens[i-1].contains("收入")||tokens[i-1].contains("of"))
							|| i-3 >= 0 && tokens[i-3].contains("变化")&& tokens[i-2].contains("时间")&&(matchedString.contains("by")||matchedString.contains("at")||tokens[i-1].contains("收入")||tokens[i-1].contains("of"))		

							|| i-1>= 0 && tokens[i-1].contains("变化")
							|| i-2>= 0 && tokens[i-2].contains("变化")&&(matchedString.contains("by")||matchedString.contains("at")||tokens[i-1].contains("收入"))){//后面要作修改 有to时感觉没有增长量的含义
						if(result.containsKey("Change")){
							LinkedHashMap<String ,Object> change= (LinkedHashMap<String, Object>) result.get("Change");
							change.put("changeQuatity", ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("money"));
						}
					}
				}else if(token.contains("周期")){
					result.put(transformKey(token), keyToInfo.get(token));
				}else if(token.contains("时间")){
					result.put(transformKey(token), keyToInfo.get(token));
				}else if(token.contains("收入")){
					if(token.contains("收入")){
						if (keyToInfo.get(token) instanceof LinkedHashMap<?, ?>){
							LinkedHashMap<String, Object> cashFlowToken = (LinkedHashMap<String, Object>) keyToInfo.get(token);	
							if(cashFlowToken!=null){
								result.put(transformKey(token), (cashFlowToken.get("cashflow").toString()));
								moneyQuantity = (String) cashFlowToken.get("cfDescripWord");
								moneyQuantityCategory = (Integer) cashFlowToken.get("cfDescripWordCategory");
								if(result.containsKey("money")){
									LinkedHashMap<String ,Object> money= (LinkedHashMap<String, Object>) result.get("Money");
									if(money!=null){
										money.put("moneyQualityCategory", moneyQuantityCategory);
										money.put("moneyQualityDes",  moneyQuantity);
									}
									
									//change.put("changeQuatity", ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("money"));
								}else if(moneyQuantity!=null && !moneyQuantity.isEmpty()){
									LinkedHashMap<String ,Object> moneyEntityMap = new LinkedHashMap<String, Object>();
									
									moneyEntityMap.put("money", null);
									moneyEntityMap.put("moneyNum", null);
									moneyEntityMap.put("moneyCurrencyType", null);
									moneyEntityMap.put("moneyModifier", null);
									moneyEntityMap.put("moneyModifierType", null);
									moneyEntityMap.put("moneyType", null);
									moneyEntityMap.put("moneyMin", null);
									moneyEntityMap.put("moneyMax", null);
									moneyEntityMap.put("moneyQualityCategory",moneyQuantityCategory);
									moneyEntityMap.put("moneyQualityDes", moneyQuantity);
									moneyEntityMap.put("moneyStartPos", 0);
									moneyEntityMap.put("moneyEndPos", 0);
									result.put("Money", moneyEntityMap);
 								}
							}
						}
					}else{
						result.put(transformKey(token),  keyToInfo.get(token));
					}
					
				}
			}
			
		}
		result.put("Tense", tense);
		//result.put("MatchedString", matchedString);
		return result;
	}
	public Map<String, Object> rule4(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		return commonAction(matchedString, keyToInfo);
	}
	public Map<String, Object> rule5(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		return commonAction(matchedString, keyToInfo);
	}
	public Map<String, Object> rule6(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		return commonAction(matchedString, keyToInfo);
	}
	
	public Map<String, Object> rule7(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		LinkedHashMap<String, Object> tense = new LinkedHashMap<String, Object>();
		String[] tokens = matchedString.split("\\s+");
		//for(String token: tokens){
	
			tense.put("tense", "PAST");
		
			String moneyQuantity=null;
			int moneyQuantityCategory = 0;
			String changeRate = null;
		for(int i=0 ; i< tokens.length; i++){
			String token = tokens[i];
			if(keyToInfo.containsKey(token)){
				if(token.contains("预计")){
					tense.put("tense", "FUTURE");
					tense.put("word", keyToInfo.get(token));
					
				}else
				
				if(token.contains("变化") && ConfusedExpUtil.isRightChangeSentence(matchedString, "#收入")){
					LinkedHashMap<String, Object> change = (LinkedHashMap<String, Object>)keyToInfo.get(token);
					if(change.get("changeRate")==null ||change.get("changeRate").toString().isEmpty()){
						change.put("changeRate", changeRate);
					}
					
					result.put(transformKey(token), change);
				}else if(token.contains("百分比")){
					if(i>0&&(tokens[0].contains("变化")||tokens[1].contains("变化"))
							&&matchedString.contains("by") 
							|| i+1< tokens.length && tokens[i+1].contains("变化")){//后面要作修改
						changeRate = (String) ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("percentText");
						if(result.containsKey("Change")){
							LinkedHashMap<String ,Object> change= (LinkedHashMap<String, Object>) result.get("Change");
							change.put("changeRate", keyToInfo.get(token));
						}
						
					}
				}else if(token.contains("钱数")){
					//result.put(transformKey(token), keyToInfo.get(token));
					LinkedHashMap<String, Object> moneyToken = (LinkedHashMap<String, Object>) keyToInfo.get(token);
					//System.out.println("money==>"+moneyQuantity);
					//System.out.println("moneyQuantity==>"+moneyQuantityCategory);
					if(moneyToken.get("moneyQualityDes")==null||moneyToken.get("moneyQualityDes").toString().isEmpty()){	
						moneyToken.put("moneyQualityDes",  moneyQuantity);
					}
					if(moneyToken.get("moneyQualityCategory")==null||(Integer)moneyToken.get("moneyQualityCategory") == 0){
						moneyToken.put("moneyQualityCategory", moneyQuantityCategory);
						//money.put("moneyQualityDes",  moneyQuantity);
					}
					result.put(transformKey(token), moneyToken);
					if(i>0&&tokens[0].contains("变化")
							&&matchedString.contains("by")){
						if(result.containsKey("Change")){
							LinkedHashMap<String ,Object> change= (LinkedHashMap<String, Object>) result.get("Change");
							change.put("changeQuatity", ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("money"));
						}
					}
				}else if(token.contains("周期")){
					result.put(transformKey(token), keyToInfo.get(token));
				}else if(token.contains("时间")){
					result.put(transformKey(token), keyToInfo.get(token));
				}else if(token.contains("收入")){
					if(token.contains("收入")){
						if (keyToInfo.get(token) instanceof LinkedHashMap<?, ?>){
							LinkedHashMap<String, Object> cashFlowToken = (LinkedHashMap<String, Object>) keyToInfo.get(token);	
							if(cashFlowToken!=null){
								result.put(transformKey(token), (cashFlowToken.get("cashflow").toString()));
								moneyQuantity = (String) cashFlowToken.get("cfDescripWord");
								moneyQuantityCategory = (Integer) cashFlowToken.get("cfDescripWordCategory");
								if(result.containsKey("money")){
									LinkedHashMap<String ,Object> money= (LinkedHashMap<String, Object>) result.get("Money");
									if(money!=null){
										money.put("moneyQualityCategory", moneyQuantityCategory);
										money.put("moneyQualityDes",  moneyQuantity);
									}
									
									//change.put("changeQuatity", ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("money"));
								}else if(moneyQuantity!=null && !moneyQuantity.isEmpty()){
									LinkedHashMap<String ,Object> moneyEntityMap = new LinkedHashMap<String, Object>();
									
									moneyEntityMap.put("money", null);
									moneyEntityMap.put("moneyNum", null);
									moneyEntityMap.put("moneyCurrencyType", null);
									moneyEntityMap.put("moneyModifier", null);
									moneyEntityMap.put("moneyModifierType", null);
									moneyEntityMap.put("moneyType", null);
									moneyEntityMap.put("moneyMin", null);
									moneyEntityMap.put("moneyMax", null);
									moneyEntityMap.put("moneyQualityCategory",moneyQuantityCategory);
									moneyEntityMap.put("moneyQualityDes", moneyQuantity);
									moneyEntityMap.put("moneyStartPos", 0);
									moneyEntityMap.put("moneyEndPos", 0);
									result.put("Money", moneyEntityMap);
 								}
							}
						}
					}else{
						result.put(transformKey(token),  keyToInfo.get(token));
					}
					
				}
			}
			
		}
		result.put("Tense", tense);
		//result.put("MatchedString", matchedString);
		return result;
	}
	
	public Map<String, Object> rule8(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		LinkedHashMap<String, Object> tense = new LinkedHashMap<String, Object>();
		String[] tokens = matchedString.split("\\s+");
		//for(String token: tokens){
	
			tense.put("tense", "PAST");
		
			String moneyQuantity=null;
			int moneyQuantityCategory = 0;
			String changeRate = null;
		for(int i=0 ; i< tokens.length; i++){
			String token = tokens[i];
			if(keyToInfo.containsKey(token)){
				if(token.contains("预计")){
					tense.put("tense", "FUTURE");
					tense.put("word", keyToInfo.get(token));
					
				}else
				
				if(token.contains("变化") && ConfusedExpUtil.isRightChangeSentence(matchedString, "#收入")){
					
					LinkedHashMap<String, Object> change = (LinkedHashMap<String, Object>)keyToInfo.get(token);
					if(change.get("changeRate")==null ||change.get("changeRate").toString().isEmpty()){
						change.put("changeRate", changeRate);
					}
					
					result.put(transformKey(token), change);
				}else if(token.contains("百分比")){
					if(i>0&&(tokens[0].contains("变化")||tokens[1].contains("变化"))
							&&(matchedString.contains("by")||matchedString.contains("at"))
							|| i+1< tokens.length && tokens[i+1].contains("变化")
							|| i-1>= 0 && tokens[i-1].contains("变化")
							|| i-4 >= 0 && tokens[i-4].contains("变化")&& tokens[i-3].contains("时间")&& tokens[i-2].contains("averaging")&&(matchedString.contains("by")||matchedString.contains("at")||tokens[i-1].contains("收入")||tokens[i-1].contains("of"))
							|| i-3 >= 0 && tokens[i-3].contains("变化")&& tokens[i-2].contains("时间")&&(matchedString.contains("by")||matchedString.contains("at")||tokens[i-1].contains("收入")||tokens[i-1].contains("of"))		

							|| i-1>= 0 && tokens[i-1].contains("at") && tokens[1].contains("变化")
							|| i-2>= 0 && tokens[i-2].contains("变化")){//后面要作修改
						changeRate = (String) ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("percentText");
						if(result.containsKey("Change")){
							LinkedHashMap<String ,Object> change= (LinkedHashMap<String, Object>) result.get("Change");
							change.put("changeRate", changeRate);
						}
						
					}
				}else if(token.contains("钱数")){
					//result.put(transformKey(token), keyToInfo.get(token));
					LinkedHashMap<String, Object> moneyToken = (LinkedHashMap<String, Object>) keyToInfo.get(token);
					//System.out.println("money==>"+moneyQuantity);
					//System.out.println("moneyQuantity==>"+moneyQuantityCategory);
					
					if(i>0&&(tokens[0].contains("变化")||tokens[1].contains("变化"))
							&&matchedString.contains("by")
							&&(matchedString.contains("by")||matchedString.contains("at"))
							|| i+1< tokens.length && tokens[i+1].contains("变化")
							|| i-1>= 0 && tokens[i-1].contains("变化")
							|| i-2>= 0 && tokens[i-2].contains("变化")
							|| i-4 >= 0 && tokens[i-4].contains("变化")&& tokens[i-3].contains("时间")&& tokens[i-2].contains("averaging")&&(matchedString.contains("by")||matchedString.contains("at")||tokens[i-1].contains("收入")||tokens[i-1].contains("of"))
							|| i-3 >= 0 && tokens[i-3].contains("变化")&& tokens[i-2].contains("时间")&&(matchedString.contains("by")||matchedString.contains("at")||tokens[i-1].contains("收入")||tokens[i-1].contains("of"))		
){
						if(result.containsKey("Change")){
							LinkedHashMap<String ,Object> change= (LinkedHashMap<String, Object>) result.get("Change");
							change.put("changeQuatity", ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("money"));
						}
					}else {
						if(moneyToken.get("moneyQualityDes")==null||moneyToken.get("moneyQualityDes").toString().isEmpty()){	
							moneyToken.put("moneyQualityDes",  moneyQuantity);
						}
						if(moneyToken.get("moneyQualityCategory")==null||(Integer)moneyToken.get("moneyQualityCategory") == 0){
							moneyToken.put("moneyQualityCategory", moneyQuantityCategory);
						//money.put("moneyQualityDes",  moneyQuantity);
						}
						result.put(transformKey(token), moneyToken);
					}
				}else if(token.contains("周期")){
					result.put(transformKey(token), keyToInfo.get(token));
				}else if(token.contains("时间")){
					result.put(transformKey(token), keyToInfo.get(token));
				}else if(token.contains("收入")){
					if(token.contains("收入")){
						if (keyToInfo.get(token) instanceof LinkedHashMap<?, ?>){
							LinkedHashMap<String, Object> cashFlowToken = (LinkedHashMap<String, Object>) keyToInfo.get(token);	
							if(cashFlowToken!=null){
								result.put(transformKey(token), (cashFlowToken.get("cashflow").toString()));
								moneyQuantity = (String) cashFlowToken.get("cfDescripWord");
								moneyQuantityCategory = (Integer) cashFlowToken.get("cfDescripWordCategory");
								if(result.containsKey("money")){
									LinkedHashMap<String ,Object> money= (LinkedHashMap<String, Object>) result.get("Money");
									if(money!=null){
										money.put("moneyQualityCategory", moneyQuantityCategory);
										money.put("moneyQualityDes",  moneyQuantity);
									}
									
									//change.put("changeQuatity", ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("money"));
								}else if(moneyQuantity!=null && !moneyQuantity.isEmpty()){
									LinkedHashMap<String ,Object> moneyEntityMap = new LinkedHashMap<String, Object>();
									
									moneyEntityMap.put("money", null);
									moneyEntityMap.put("moneyNum", null);
									moneyEntityMap.put("moneyCurrencyType", null);
									moneyEntityMap.put("moneyModifier", null);
									moneyEntityMap.put("moneyModifierType", null);
									moneyEntityMap.put("moneyType", null);
									moneyEntityMap.put("moneyMin", null);
									moneyEntityMap.put("moneyMax", null);
									moneyEntityMap.put("moneyQualityCategory",moneyQuantityCategory);
									moneyEntityMap.put("moneyQualityDes", moneyQuantity);
									moneyEntityMap.put("moneyStartPos", 0);
									moneyEntityMap.put("moneyEndPos", 0);
									result.put("Money", moneyEntityMap);
 								}
							}
						}
					}else{
						result.put(transformKey(token),  keyToInfo.get(token));
					}
					
				}
			}
			
		}
		result.put("Tense", tense);
		//result.put("MatchedString", matchedString);
		return result;
	}
	
	public Map<String, Object> rule9(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		
		return rule2(matchedString, keyToInfo);
	}
	
	public Map<String, Object> rule10(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		
		return rule1(matchedString, keyToInfo);
	}
	
	public Map<String, Object> rule11(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		
		return rule1(matchedString, keyToInfo);
	}
	public Map<String, Object> rule12(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		
		return rule2(matchedString, keyToInfo);
	}
	public Map<String, Object> rule13(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		
		return rule5(matchedString, keyToInfo);
	}
	public Map<String, Object> rule14(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		
		return rule2(matchedString, keyToInfo);
	}
	public Map<String, Object> rule15(String matchedString,LinkedHashMap<String, Object> keyToInfo){
	
		return rule2(matchedString, keyToInfo);
	}
	public Map<String, Object> rule16(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		
		return rule2(matchedString, keyToInfo);
	}
	public Map<String, Object> rule17(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		
		return rule3(matchedString, keyToInfo);
	}
	public Map<String, Object> rule18(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		
		return rule1(matchedString, keyToInfo);
	}
	
	public Map<String, Object> rule19(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		LinkedHashMap<String, Object> tense = new LinkedHashMap<String, Object>();
		String[] tokens = matchedString.split("\\s+");
		//for(String token: tokens){
	
			tense.put("tense", "PAST");
		
			String moneyQuantity=null;
			int moneyQuantityCategory = 0;
			String changeRate = null;
		for(int i=0 ; i< tokens.length; i++){
			String token = tokens[i];
			if(keyToInfo.containsKey(token)){
				if(token.contains("预计")){
					tense.put("tense", "FUTURE");
					tense.put("word", keyToInfo.get(token));
					
				}else
				
				if(token.contains("变化") && ConfusedExpUtil.isRightChangeSentence(matchedString, "#收入")){
					
					LinkedHashMap<String, Object> change = (LinkedHashMap<String, Object>)keyToInfo.get(token);
					if(change.get("changeRate")==null ||change.get("changeRate").toString().isEmpty()){
						change.put("changeRate", changeRate);
					}
					
					result.put(transformKey(token), change);
				}else if(token.contains("百分比")){
					if(matchedString.contains("变化")){//后面要作修改
						changeRate = (String) ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("percentText");
						if(result.containsKey("Change")){
							LinkedHashMap<String ,Object> change= (LinkedHashMap<String, Object>) result.get("Change");
							change.put("changeRate", changeRate);
						}
						
					}
				}else if(token.contains("钱数")){
					//result.put(transformKey(token), keyToInfo.get(token));
					LinkedHashMap<String, Object> moneyToken = (LinkedHashMap<String, Object>) keyToInfo.get(token);
					//System.out.println("money==>"+moneyQuantity);
					//System.out.println("moneyQuantity==>"+moneyQuantityCategory);
					
					if(matchedString.contains("变化")){
						if(result.containsKey("Change")){
							LinkedHashMap<String ,Object> change= (LinkedHashMap<String, Object>) result.get("Change");
							change.put("changeQuatity", ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("money"));
						}
					}else {
						if(moneyToken.get("moneyQualityDes")==null||moneyToken.get("moneyQualityDes").toString().isEmpty()){	
							moneyToken.put("moneyQualityDes",  moneyQuantity);
						}
						if(moneyToken.get("moneyQualityCategory")==null||(Integer)moneyToken.get("moneyQualityCategory") == 0){
							moneyToken.put("moneyQualityCategory", moneyQuantityCategory);
						//money.put("moneyQualityDes",  moneyQuantity);
						}
						result.put(transformKey(token), moneyToken);
					}
				}else if(token.contains("周期")){
					result.put(transformKey(token), keyToInfo.get(token));
				}else if(token.contains("时间")){
					result.put(transformKey(token), keyToInfo.get(token));
				}else if(token.contains("收入")){
					if(token.contains("收入")){
						if (keyToInfo.get(token) instanceof LinkedHashMap<?, ?>){
							LinkedHashMap<String, Object> cashFlowToken = (LinkedHashMap<String, Object>) keyToInfo.get(token);	
							if(cashFlowToken!=null){
								result.put(transformKey(token), (cashFlowToken.get("cashflow").toString()));
								moneyQuantity = (String) cashFlowToken.get("cfDescripWord");
								moneyQuantityCategory = (Integer) cashFlowToken.get("cfDescripWordCategory");
								if(result.containsKey("money")){
									LinkedHashMap<String ,Object> money= (LinkedHashMap<String, Object>) result.get("Money");
									if(money!=null){
										money.put("moneyQualityCategory", moneyQuantityCategory);
										money.put("moneyQualityDes",  moneyQuantity);
									}
									
									//change.put("changeQuatity", ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("money"));
								}else if(moneyQuantity!=null && !moneyQuantity.isEmpty()){
									LinkedHashMap<String ,Object> moneyEntityMap = new LinkedHashMap<String, Object>();
									
									moneyEntityMap.put("money", null);
									moneyEntityMap.put("moneyNum", null);
									moneyEntityMap.put("moneyCurrencyType", null);
									moneyEntityMap.put("moneyModifier", null);
									moneyEntityMap.put("moneyModifierType", null);
									moneyEntityMap.put("moneyType", null);
									moneyEntityMap.put("moneyMin", null);
									moneyEntityMap.put("moneyMax", null);
									moneyEntityMap.put("moneyQualityCategory",moneyQuantityCategory);
									moneyEntityMap.put("moneyQualityDes", moneyQuantity);
									moneyEntityMap.put("moneyStartPos", 0);
									moneyEntityMap.put("moneyEndPos", 0);
									result.put("Money", moneyEntityMap);
 								}
							}
						}
					}else{
						result.put(transformKey(token),  keyToInfo.get(token));
					}
					
				}
			}
			
		}
		result.put("Tense", tense);
		//result.put("MatchedString", matchedString);
		return result;
	}
	
	public Map<String, Object> rule20(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		LinkedHashMap<String, Object> tense = new LinkedHashMap<String, Object>();
		String[] tokens = matchedString.split("\\s+");
		//for(String token: tokens){
	
			tense.put("tense", "PAST");
		
			String moneyQuantity=null;
			int moneyQuantityCategory = 0;
			String changeRate = null;
		for(int i=0 ; i< tokens.length; i++){
			String token = tokens[i];
			if(keyToInfo.containsKey(token)){
				if(token.contains("预计")){
					tense.put("tense", "FUTURE");
					tense.put("word", keyToInfo.get(token));
					
				}else
				
				if(token.contains("变化") && ConfusedExpUtil.isRightChangeSentence(matchedString, "#收入")){
					
					LinkedHashMap<String, Object> change = (LinkedHashMap<String, Object>)keyToInfo.get(token);
					if(change.get("changeRate")==null ||change.get("changeRate").toString().isEmpty()){
						change.put("changeRate", changeRate);
					}
					
					result.put(transformKey(token), change);
				}else if(token.contains("百分比")){
					if(i>0&&tokens[1].contains("变化")
							&&(matchedString.contains("by")||matchedString.contains("at")||matchedString.contains(" of "))
							|| i+1< tokens.length && tokens[i+1].contains("变化")
							|| i-1>= 0 && tokens[i-1].contains("变化")
							|| i-2>= 0 && tokens[i-2].contains("变化")
							|| i-4 >= 0 && tokens[i-4].contains("变化")&& tokens[i-3].contains("时间")&& tokens[i-2].contains("averaging")&&(matchedString.contains("by")||matchedString.contains("at")||tokens[i-1].contains("收入")||tokens[i-1].contains("of"))
							|| i-3 >= 0 && tokens[i-3].contains("变化")&& tokens[i-2].contains("时间")&&(matchedString.contains("by")||matchedString.contains("at")||tokens[i-1].contains("收入")||tokens[i-1].contains("of"))		

							||i>0&&tokens[tokens.length-1].contains("变化")){//后面要作修改
						changeRate = (String) ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("percentText");
						if(result.containsKey("Change")){
							LinkedHashMap<String ,Object> change= (LinkedHashMap<String, Object>) result.get("Change");
							change.put("changeRate", changeRate);
						}else if (i+1 <= tokens.length-1 && tokens[i+1].contains("变化")) {
							LinkedHashMap<String, Object> change = (LinkedHashMap<String, Object>)keyToInfo.get(tokens[i+1]);
							if(change.get("changeRate")==null ||change.get("changeRate").toString().isEmpty()){
								change.put("changeRate", changeRate);
								//change.put("changeQuatity", ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("money"));
							}
							//result.put(transformKey(token), moneyToken);
						}
						
					}
				}else if(token.contains("钱数")){
					//result.put(transformKey(token), keyToInfo.get(token));
					LinkedHashMap<String, Object> moneyToken = (LinkedHashMap<String, Object>) keyToInfo.get(token);
					//System.out.println("money==>"+moneyQuantity);
					//System.out.println("moneyQuantity==>"+moneyQuantityCategory);
					
					if(i>0&&tokens[1].contains("变化")
							&&matchedString.contains("by")
							&&(matchedString.contains("by")||matchedString.contains("at"))
							|| i+1< tokens.length && tokens[i+1].contains("变化")
							|| i-1>= 0 && tokens[i-1].contains("变化")
							|| i-2>= 0 && tokens[i-2].contains("变化")
							|| i>0 && tokens[tokens.length-1].contains("变化")
							){
						
						if(result.containsKey("Change")){
							LinkedHashMap<String ,Object> change= (LinkedHashMap<String, Object>) result.get("Change");
							change.put("changeQuatity", ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("money"));
						}else if (i+1 <= tokens.length-1 && tokens[i+1].contains("变化")) {
							LinkedHashMap<String, Object> change = (LinkedHashMap<String, Object>)keyToInfo.get(tokens[i+1]);
							if(change.get("changeQuatity")==null ||change.get("changeQuatity").toString().isEmpty()){
								//change.put("changeRate", changeRate);
								change.put("changeQuatity", ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("money"));
							}
							//result.put(transformKey(token), moneyToken);
						}
					}else {
						if(moneyToken.get("moneyQualityDes")==null||moneyToken.get("moneyQualityDes").toString().isEmpty()){	
							moneyToken.put("moneyQualityDes",  moneyQuantity);
						}
						if(moneyToken.get("moneyQualityCategory")==null||(Integer)moneyToken.get("moneyQualityCategory") == 0){
							moneyToken.put("moneyQualityCategory", moneyQuantityCategory);
						//money.put("moneyQualityDes",  moneyQuantity);
						}
						result.put(transformKey(token), moneyToken);
					}
				}else if(token.contains("周期")){
					result.put(transformKey(token), keyToInfo.get(token));
				}else if(token.contains("时间")){
					result.put(transformKey(token), keyToInfo.get(token));
				}else if(token.contains("收入")){
					if(token.contains("收入")){
						if (keyToInfo.get(token) instanceof LinkedHashMap<?, ?>){
							LinkedHashMap<String, Object> cashFlowToken = (LinkedHashMap<String, Object>) keyToInfo.get(token);	
							if(cashFlowToken!=null){
								result.put(transformKey(token), (cashFlowToken.get("cashflow").toString()));
								moneyQuantity = (String) cashFlowToken.get("cfDescripWord");
								moneyQuantityCategory = (Integer) cashFlowToken.get("cfDescripWordCategory");
								if(result.containsKey("money")){
									LinkedHashMap<String ,Object> money= (LinkedHashMap<String, Object>) result.get("Money");
									if(money!=null){
										money.put("moneyQualityCategory", moneyQuantityCategory);
										money.put("moneyQualityDes",  moneyQuantity);
									}
									
									//change.put("changeQuatity", ((LinkedHashMap<String, Object>)keyToInfo.get(token)).get("money"));
								}else if(moneyQuantity!=null && !moneyQuantity.isEmpty()){
									LinkedHashMap<String ,Object> moneyEntityMap = new LinkedHashMap<String, Object>();
									
									moneyEntityMap.put("money", null);
									moneyEntityMap.put("moneyNum", null);
									moneyEntityMap.put("moneyCurrencyType", null);
									moneyEntityMap.put("moneyModifier", null);
									moneyEntityMap.put("moneyModifierType", null);
									moneyEntityMap.put("moneyType", null);
									moneyEntityMap.put("moneyMin", null);
									moneyEntityMap.put("moneyMax", null);
									moneyEntityMap.put("moneyQualityCategory",moneyQuantityCategory);
									moneyEntityMap.put("moneyQualityDes", moneyQuantity);
									moneyEntityMap.put("moneyStartPos", 0);
									moneyEntityMap.put("moneyEndPos", 0);
									result.put("Money", moneyEntityMap);
 								}
							}
						}
					}else{
						result.put(transformKey(token),  keyToInfo.get(token));
					}
					
				}
			}
			
		}
		result.put("Tense", tense);
		//result.put("MatchedString", matchedString);
		return result;
	}
	
}
