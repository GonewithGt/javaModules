package gt.gone.model.profitability;

import gt.gone.util.JsonTool;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.Vector;

public class ProfitAbilityExtractThread implements Runnable {
	Vector<String> inputsStrings = new Vector<String>();
	//public int start;
	//public int end;
	
	//private ThreadLocal<Integer> startLocal = new ThreadLocal<Integer>();
	//private ThreadLocal<Integer> endlocal = new ThreadLocal<Integer>();
	public ProfitAbilityExtract pae = new ProfitAbilityExtract();
	public PrintStream ps ;
	public ProfitAbilityExtractThread(Vector<String> input,int start, int end, String outPath){
		this.inputsStrings = input;
	//	this.startLocal.set(start); 
	//	this.endlocal.set(end);
		if(this.ps == null){
			try {			
				this.ps = new PrintStream(new FileOutputStream(outPath));
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		System.out.println("start =="+start);
		
	}
	

	@Override
	public void run() {
		// TODO Auto-generated method stub
		//if(this.startLocal.get()!=null && this.endlocal.get()!=null){
		//	int localStart = startLocal.get();//局部变量拷贝
		//	int localEnd = endlocal.get();		
			//System.out.println("localStart"+localStart);
			for(int i = 0 ; i< inputsStrings.size() ; i++){
				System.out.println("i="+i + Thread.currentThread().getName());
				String input = inputsStrings.get(i);
				if(input != null){
					String outputJsonStr = pae.extractProfitAbility(input);
					//ps.append(outputJsonStr);
					synchronized (ProfitAbilityExtractThread.class) {
						ps.println(i);
						ps.println(JsonTool.formatJson(outputJsonStr, "\t"));
					}	
				}
			}
		}
		


}
