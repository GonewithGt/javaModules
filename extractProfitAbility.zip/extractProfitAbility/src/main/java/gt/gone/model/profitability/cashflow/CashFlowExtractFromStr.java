package gt.gone.model.profitability.cashflow;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;

import gt.gone.model.profitability.revenue.RevenueExtract;
import gt.gone.util.FileUtil;
import gt.gone.util.JsonTool;
import gt.gone.util.PropertyUtil;

public class CashFlowExtractFromStr {
	public static void main(String[] args) throws FileNotFoundException {
		//String input = "Sold Title Insurance Agency In Ohio For Sale          SOLD - Full service real estate title insurance company provides comprehensive title insurance, title examination, closing and escrow services for residential and commercial properties.鈥?Multiple locations -modern offices 鈥?Updated technologies 鈥?Experienced and tenured staff 鈥?Dedicated marketing team 鈥?Well-known and respected in marketplace 鈥?Number of closings have grown from 347 in 2004 to 913 closings 2013 鈥?June and July 2014 monthly closings are highest in company history 鈥?Four year compound annual growth rate in revenues: 15% 鈥?Four year compound annual growth in SDE: 15.7% 鈥?Excellent percentage arrangements with national underwriters 鈥?Hoover鈥檚 forecasts 4% annual compound growth rate through 2018 鈥?Reason for Sale: Owner wishes to retire";	
		//String fileTest2 = "C:\\Users\\nlp\\workspace\\extractCashFlow3\\src\\main\\resources\\wrongSentence.txt";
		String fileTest2 = PropertyUtil.getValue("profitablity.input");
		String input = FileUtil.importData(fileTest2, 3700);
		//input = "Gross income restaurant: $ 3.7 M, cash flow: 12%, asking price: 1.4 M. Restaurant and office bldg + large parking lot: $ 3,4 M ( Bldg cash flow : + $ 200 K./year.";
		PrintStream ps = new PrintStream(new FileOutputStream("C:\\tmp.txt"));
		if(input!=null){
			CashFlowExtract cfe = new CashFlowExtract();
			String ans = cfe.extractCashFlow(input);
			//JsonFormatTool jst = new JsonFormatTool();
			ps.println(JsonTool.formatJson(ans, "\t"));
			ps.println();
			ps.println();
			System.out.println(JsonTool.formatJson(ans, "\t"));
			System.out.println();
			System.out.println();
		}
		
	}

}
