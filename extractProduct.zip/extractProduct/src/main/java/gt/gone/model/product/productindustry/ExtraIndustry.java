package gt.gone.model.product.productindustry;

import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import gt.gone.util.FileUtil;
import gt.gone.util.JsonTool;
import gt.gone.util.MongoDBUtil;
import gt.gone.util.PropertyUtil;
import gt.gone.util.WordTree;
import gt.gone.util.WordTreeCase;
import net.sf.json.JSONObject;

public class ExtraIndustry {
	public static String preProcess(String str) {
		return str.replaceAll(", |!|\\?|\"|\\|/", " ").replace("\\.", " .");
	}

	public static void main(String[] args) throws Exception {
		//PrintStream ps = new PrintStream(new FileOutputStream("C:\\extractIndustry.txt"));
		PrintStream ps = new PrintStream(new FileOutputStream(PropertyUtil.getValue("product.industry.output")));
		System.setOut(ps);
		//String fileTest = "C:\\Users\\nlp\\workspace\\extractCashFlow3\\src\\main\\resources\\industry.txt";
		String fileTest = PropertyUtil.getValue("product.industry.input");
		Map<String, String> map = new HashMap<String, String>();
		WordTree industryWordTree = new WordTree();
		industryWordTree = MongoDBUtil.getIndustryWordTreeFromMongoDB();
		HashMap<String, String> industryHashMap = MongoDBUtil.getIndustryHashMapFromMongoDB();
		for (int i = 1; i < 22; i++) {
			String input = preProcess(FileUtil.importData(fileTest, i));
			System.out.println(input);
			System.out.println(JsonTool.formatJson(
					JSONObject.fromObject(extractIndustry(input, industryWordTree, industryHashMap)).toString(), "\t"));
			System.out.println();
		}
	}

	public static LinkedHashMap<String, Object> extractIndustry(String input, WordTree industryWordTree,
			HashMap<String, String> industryHashMap) {
		LinkedHashMap<String, Object> resultMap = new LinkedHashMap<String, Object>(); // 抽取的信息

		List industryList = new LinkedList<String>();
		if (input != null) {

			String[] industrys = input.split("\\.");
			for (String industry : industrys) {
				if (industry.toLowerCase().contains("industry") || industry.toLowerCase().contains("industries")
						|| industry.toLowerCase().contains("industrial") || industry.toLowerCase().contains("use")
						|| industry.toLowerCase().contains("used") || industry.toLowerCase().contains("company")
						|| industry.toLowerCase().contains("companys")) {

					// 抽取应用领域
					ArrayList<String> extractedStringList = (ArrayList<String>) MongoDBUtil
							.extract(preProcess(industry), industryWordTree);
					if (extractedStringList.size() == 0) {
						industryList.add("");
					} else {
						for (String str : extractedStringList) {
							HashMap<String, String> industryAndCodeHashMap = new HashMap<String, String>();
							if (industryHashMap.containsKey(str)) {
								industryAndCodeHashMap.put(industryHashMap.get(str), str);
								industryList.add(industryAndCodeHashMap);
							}

						}
					}
				}

			}

			resultMap.put("industry", industryList);

		}
		return resultMap;
	}

}
