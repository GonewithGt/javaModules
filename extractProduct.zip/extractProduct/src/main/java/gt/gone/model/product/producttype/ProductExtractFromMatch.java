package gt.gone.model.product.producttype;

import gt.gone.util.JsonTool;
import gt.gone.util.MongoDBUtil;
import gt.gone.util.PropertyUtil;
import gt.gone.util.WordTree;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.ByteOrderMark;
import org.apache.commons.io.input.BOMInputStream;

import net.sf.json.JSONObject;

public class ProductExtractFromMatch {
	
	public static WordTree productWordTree =  MongoDBUtil.getProductFromMongoDB();
	
	public static String extractProduct(String oldInput,
			WordTree productWordTree
			) throws Exception {
		LinkedHashMap<String, Object> resultMap = new LinkedHashMap<String, Object>(); // 抽取的信息
		// List locationList = new LinkedList<String>();
	//	String productsStr[] = oldInput.split("\\. ");
		//for(String productStr: productsStr){
			String resultStr = "";
			ArrayList<String> extractedProductsList = (ArrayList<String>) MongoDBUtil
					.extract(oldInput, productWordTree);
			resultMap.put("input", oldInput);
			resultMap.put("productType", extractedProductsList);
	//	}	
			resultStr = JSONObject.fromObject(resultMap).toString();
		return resultStr;

	}
	
	public static String extractProduct(String oldInput			
			) throws Exception {
		LinkedHashMap<String, Object> resultMap = new LinkedHashMap<String, Object>(); // 抽取的信息
		// List locationList = new LinkedList<String>();
	//	String productsStr[] = oldInput.split("\\. ");
		//for(String productStr: productsStr){
			String resultStr = "";
			ArrayList<String> extractedProductsList = (ArrayList<String>) MongoDBUtil
					.extract(oldInput, productWordTree);
			resultMap.put("input", oldInput);
			resultMap.put("productType", extractedProductsList);
	//	}
			resultStr = JSONObject.fromObject(resultMap).toString();
		return resultStr;

	}
	
	public static void main(String[] args){
		 PrintStream ps;
			try {
				//ps = new PrintStream(new FileOutputStream("C:\\TestData\\extractProductJson2.txt"));
				ps = new PrintStream(new FileOutputStream(PropertyUtil.getValue("product.type.output")));
				//System.setOut(ps);  
				//String fileTestProduct = "C:\\Users\\nlp\\workspace\\extractCashFlow3\\src\\main\\resources\\testProduct.txt";
				//String fileTestProduct2 = "C:\\TestData\\TestProductAll.txt";
				String fileTestProduct = PropertyUtil.getValue("product.type.input");
				String line = null;
				  //  int n = 3;//从第三行开始读取
				    try {
				    	//FileInputStream fileInputStream  = new FileInputStream(filePath);
				    	//InputStreamReader isr = new InputStreamReader(fileInputStream, "UTF-8");
				    	// ClassLoader classLoader = XmlUtil.class.getClassLoader();
				    	// FileInputStream fis = (FileInputStream) classLoader.getResourceAsStream(filePath); 
				    	ProductTypeExtract pe = new ProductTypeExtract();
				    //	XmlUtil xml = new XmlUtil("product","producttype","product.xml");
				    	FileInputStream fis = new FileInputStream(fileTestProduct);
			        	   //可检测多种类型，并剔除bom
			        	BOMInputStream bomIn = new BOMInputStream(fis, false,ByteOrderMark.UTF_8, ByteOrderMark.UTF_16LE, ByteOrderMark.UTF_16BE);
			        	String charset = "utf-8";
			        	   //若检测到bom，则使用bom对应的编码
			        	if(bomIn.hasBOM()){
			        		charset = bomIn.getBOMCharsetName();
			        	 }
			        	BufferedReader br = new BufferedReader(new InputStreamReader(bomIn, charset));
						//br = new BufferedReader(new InputStreamReader(new FileInputStream(filePath), "UTF-8"));
						int i = 1;
						 while ((line = br.readLine()) != null) {
							 String ans = extractProduct(line);
								//JsonFormatTool jst = new JsonFormatTool();
							 	ps.println("LineNum" + i++);
							 	System.out.println(i);
							 	ps.println(JsonTool.formatJson(ans, "\t"));
							 	ps.println();
							 	ps.println();
							}
						 br.close();
						 
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				/*for(int i = 1 ; i < 30 ; i++){
					
					String input = FileUtil.importData(fileTestProduct, i);	
					if(input!=null){
						ProductTypeExtract pe = new ProductTypeExtract();
						String ans = pe.extractProduct(input);
						//JsonFormatTool jst = new JsonFormatTool();
						System.out.println(JsonTool.formatJson(ans, "\t"));
						System.out.println();
						System.out.println();
					}
					
				}*/ catch (Exception e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
		
			/*	String input = FileUtil.importData(fileTestProduct, 1);
				ProductExtract pe = new ProductExtract();
				String ans = pe.extractProduct(input);
				JsonFormatTool jst = new JsonFormatTool();
				System.out.println(JsonTool.formatJson(ans, " "));*/
				
			
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
	}

}
