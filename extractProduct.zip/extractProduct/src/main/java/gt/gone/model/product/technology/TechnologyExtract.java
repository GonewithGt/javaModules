package gt.gone.model.product.technology;

import gt.gone.model.product.producttype.ProductTypeExtract;
import gt.gone.util.FileUtil;
import gt.gone.util.JsonTool;
import gt.gone.util.PropertyUtil;
import gt.gone.util.XmlUtil;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;

import org.apache.commons.io.ByteOrderMark;
import org.apache.commons.io.input.BOMInputStream;

import net.sf.json.JSONObject;

public class TechnologyExtract {

	public String extractTech(String input) {
		Technology tech = new Technology(input);
		String resultStr = "";
		// resultStr =
		// JSONObject.fromObject(sentence.getEntityNameToEntityMap()).toString();
		resultStr = JSONObject.fromObject(tech.getResultList()).toString();
		// System.out.println(JsonTool.formatJson(sentence.getKeyToInfoMap().toString(),
		// " "));
		return resultStr;
	}

	public String extractTech(String input, XmlUtil xml) {
		Technology tech = new Technology(input, xml);
		String resultStr = "";
		// resultStr =
		// JSONObject.fromObject(sentence.getEntityNameToEntityMap()).toString();
		resultStr = JSONObject.fromObject(tech.getResultList()).toString();
		// System.out.println(JsonTool.formatJson(sentence.getKeyToInfoMap().toString(),
		// " "));
		return resultStr;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		// String fileTest2 =
		// "D:\\java\\cashFlow\\extractCashFlow3\\src\\main\\resources\\test2.txt";
		// String input = FileUtil.importData(fileTest2, 1);

		PrintStream ps;
		try {
			//ps = new PrintStream(new FileOutputStream(
			//		"C:\\TestData\\extractTechJson.txt"));
			ps = new PrintStream(new FileOutputStream(PropertyUtil.getValue("product.technology.output")));
			System.setOut(ps);
			//String fileTestTech = "C:\\TestData\\TestTechnologyAll.txt";
			String fileTestTech = PropertyUtil.getValue("product.technology.input");
			try {
				// FileInputStream fileInputStream = new
				// FileInputStream(filePath);
				// InputStreamReader isr = new
				// InputStreamReader(fileInputStream, "UTF-8");
				// ClassLoader classLoader = XmlUtil.class.getClassLoader();
				// FileInputStream fis = (FileInputStream)
				// classLoader.getResourceAsStream(filePath);
				TechnologyExtract pe = new TechnologyExtract();
				XmlUtil xml = new XmlUtil("product","technology","technology.xml");
				FileInputStream fis = new FileInputStream(fileTestTech);
				// 可检测多种类型，并剔除bom
				BOMInputStream bomIn = new BOMInputStream(fis, false,
						ByteOrderMark.UTF_8, ByteOrderMark.UTF_16LE,
						ByteOrderMark.UTF_16BE);
				String charset = "utf-8";
				// 若检测到bom，则使用bom对应的编码
				if (bomIn.hasBOM()) {
					charset = bomIn.getBOMCharsetName();
				}
				BufferedReader br = new BufferedReader(new InputStreamReader(
						bomIn, charset));
				// br = new BufferedReader(new InputStreamReader(new
				// FileInputStream(filePath), "UTF-8"));
				String line = "";
				int i = 1;
				while ((line = br.readLine()) != null) {
					String ans = pe.extractTech(line, xml);
					// JsonFormatTool jst = new JsonFormatTool();
					System.out.println("LineNum:" + i++);
					System.out.println(JsonTool.formatJson(ans, "\t"));
					System.out.println();
					System.out.println();
				}
				br.close();

			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			/*
			 * for(int i = 1 ; i < 30 ; i++){
			 * 
			 * String input = FileUtil.importData(fileTestTech, i);
			 * if(input!=null){ TechnologyExtract pe = new TechnologyExtract();
			 * String ans = pe.extractTech(input); //JsonFormatTool jst = new
			 * JsonFormatTool(); System.out.println(JsonTool.formatJson(ans,
			 * "\t")); System.out.println(); System.out.println(); }
			 * 
			 * }
			 */

			/*
			 * String input = FileUtil.importData(fileTestProduct, 1);
			 * ProductExtract pe = new ProductExtract(); String ans =
			 * pe.extractProduct(input); JsonFormatTool jst = new
			 * JsonFormatTool(); System.out.println(JsonTool.formatJson(ans,
			 * " "));
			 */

		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
