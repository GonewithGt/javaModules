package gt.gone.model.product.technology;

import gt.gone.util.FileUtil;
import gt.gone.util.JsonTool;
import gt.gone.util.PropertyUtil;

public class TechnologyExtractFromStr {
	
	public static void main(String[] args){
		//String fileTest2 = "C:\\Users\\nlp\\workspace\\extractCashFlow3\\src\\main\\resources\\TestProfitMargin.txt";
		//String fileTest2 = "C:\\TestData\\TestTechnologyAll.txt";
		//String fileTest2 = "C:\\Users\\nlp\\workspace\\extractCashFlow3\\src\\main\\resources\\seller_4w.txt";
		String fileTest2= PropertyUtil.getValue("product.technology.input");
		int i = 0 ;
		String input = FileUtil.importData(fileTest2, 33);
		if(input!=null){
			TechnologyExtract cfe = new TechnologyExtract();
			String ans = cfe.extractTech(input);
			//JsonFormatTool jst = new JsonFormatTool();
			System.out.println(JsonTool.formatJson(ans, "\t"));
			System.out.println();
			System.out.println();
		}
	}
	
}
	