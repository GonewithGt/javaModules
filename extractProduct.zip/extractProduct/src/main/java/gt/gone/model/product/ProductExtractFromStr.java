package gt.gone.model.product;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.LinkedHashMap;
import gt.gone.model.product.productclient.ExtraClient;
import gt.gone.model.product.productindustry.ExtraIndustry;
import gt.gone.model.product.productmarket.ExtraMarket;
import gt.gone.model.product.producttype.ProductType;
import gt.gone.model.product.technology.Technology;
import gt.gone.util.FileUtil;
import gt.gone.util.JsonTool;
import gt.gone.util.MongoDBUtil;
import gt.gone.util.PreProcess;
import gt.gone.util.Word2VEC;
import gt.gone.util.WordTree;
import gt.gone.util.WordTreeCase;
import net.sf.json.JSONObject;

public class ProductExtractFromStr {

	public static void main(String[] args) throws Exception {
	
			ProductExtract proe = new ProductExtract();
			String input = "Deshun Technology, established in 2001, is manufacturer and exporter of the LED replacement flashlight bulbs, automotive LED bulbs, residential and commercial LED lamps, and audio equipments etc. " 
			+ "It's a new generation of video transmission technology representing a trillion-dollar global market. "
					+ "The client retention of is astounding, being maintained for decades. "
					+"Well-established in the California area for over 25 plus years, this company has a long list of repeat clients and currently has several millions of dollars in projected and scheduled projects for throughout 2015/ Established over 25 years with multitude of long-standing clients/High number of clients where the business is prequalified and has long-term contracts. "
					+"Huge potential in China market. "
					+"High precision CNC engineering company with a particular presence in the aerospace, nuclear, motorsports and defence sectors. "
					
					;
				if (input != null) {
					String ans = proe.extractProduct(input);
					// JsonFormatTool jst = new JsonFormatTool();
					System.out.println(JsonTool.formatJson(ans, "\t"));
					System.out.println();
					System.out.println();
				}
	}
}
