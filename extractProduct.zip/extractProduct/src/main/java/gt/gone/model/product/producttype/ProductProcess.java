package gt.gone.model.product.producttype;

import gt.gone.util.ConfusedExpUtil;
import gt.gone.util.KeyWordReplaceUtil;
import gt.gone.util.Word2VEC;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.regex.Matcher;

public class ProductProcess {
	
	public ArrayList<String> productsSplit(String productToken, String houzui){
		ArrayList<String> products = new ArrayList<String>();
		//System.out.println("before"+productStr);
		if(productToken.contains(" to ")){
			productToken = productToken.substring(0, productToken.indexOf(" to "));
			//System.out.println("after"+productStr);
		}
		String[] productStrs = productToken.split(", and|, |- ");
		
		for(String productStr: productStrs){
			productStr = productStr.trim();
			if(!productStr.trim().equals("etc")&&!productStr.equals("et")&&!productStr.equals(".")&&!productStr.isEmpty()){
				if(productStr.trim().endsWith(" etc")){
					productStr = productStr.replace(" etc", "");
				}else if(productStr.trim().endsWith(" et")){
					productStr = productStr.replace(" et", "");
				}
				//System.out.println("productStr:"+productStr);
				if(productStr.contains(" and ")){
					String[] productTokens = productStr.split("\\s+");
					//System.out.println(productTokens.length);
					String beforeAnd = productStr.substring(0,productStr.indexOf(" and ")).trim();
					String afterAnd = productStr.substring(productStr.indexOf(" and ")+" and ".length()).trim();
					//System.out.println("beforeAnd:"+beforeAnd);
					//System.out.println("afterAnd:"+afterAnd);
					//System.out.println(houzui);
					if(productTokens.length >= 4 && productTokens[1].trim().equals("and")){
						if((Word2VEC.distanceWith2Words(productTokens[0].trim(), productTokens[2].trim())> 0.4 
								||productTokens[productTokens.length-1].trim().equals("services")
								||productTokens[productTokens.length-1].trim().equals("service"))
								&&!productTokens[0].trim().equals(productTokens[2].trim())){
							products.add(afterAnd.replaceFirst(productTokens[2].trim(), productTokens[0].trim()));
							products.add(afterAnd.trim());
						}else if(!houzui.isEmpty()){
							products.add(beforeAnd+" "+houzui.trim());
							products.add(afterAnd.trim());	
						}else{
							products.add(beforeAnd);
							products.add(afterAnd);
						}
					}else if(productTokens.length >= 4 && productTokens[productTokens.length-2].trim().equals("and")){
						if(Word2VEC.distanceWith2Words(productTokens[productTokens.length-3].trim(), productTokens[productTokens.length-1].trim())> 0.4 
								&&!productTokens[productTokens.length-3].trim().equals(productTokens[productTokens.length-1].trim())){
							products.add(beforeAnd.replaceFirst(productTokens[productTokens.length-3], productTokens[productTokens.length-1]));
							products.add(beforeAnd.trim());
						}else if(!houzui.isEmpty()){
							products.add(beforeAnd+" "+houzui.trim());
							products.add(afterAnd.trim());
						}else{
							products.add(beforeAnd);
							products.add(afterAnd);
						}
					}else{
						products.add(beforeAnd);
						products.add(afterAnd);
					}
				}else{
					products.add(productStr);
				}
				/*if(!houzui.isEmpty()){
					if(productStr.contains(houzui)){
						products.add(productStr);
					}else {
						products.add(productStr+" "+houzui);
					}
					
				}else{
					products.add(productStr);
				}*/
				
				
			}
			
		}
		
		return products;
	}
	

	public LinkedHashMap<String, Object> commonProcess(String matchedString, Matcher matcher, LinkedHashMap<String, Object> keyToInfo, int []groupNums){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		ArrayList<String> products = new ArrayList<String>();
		ArrayList<String> productsSplited = new ArrayList<String>();
		ArrayList<String> actions = new ArrayList<String>();
		ArrayList<String> actionsSplited = new ArrayList<String>();
		for(int i = 0 ;i < groupNums.length; i++){
			//String productToken = matcher.group(groupNums[i]).replaceAll("#冠词\\d*", KeyWordReplaceUtil.getKeyWordValue(matchedString, "#冠词", keyToInfo)).trim();
			String productToken = KeyWordReplaceUtil.keyWordReplace(matcher.group(groupNums[i]), "#冠词", keyToInfo);
			if(productToken!=null && !productToken.isEmpty() && ConfusedExpUtil.isRightProductExpress(productToken)){
				products.add(productToken);
				productsSplited.addAll(productsSplit(productToken,""));
			}
			
		}
		
		String[] matchedTokens = matchedString.split(" ");
		for(String token : matchedTokens){
			if(token!= null && !token.isEmpty()){
				if(token.contains("行为")){
					String actionToken = keyToInfo.get(token.trim()).toString();
					if(actionToken!= null && !actionToken.isEmpty()){
						actions.add(actionToken);
						actionsSplited.addAll(productsSplit(actionToken,""));
					}
				}
			}
		}
		
		
		//result.put("sentencePre", matchedString);
		if(products.size() > 0){
			result.put("productCategory", products);
			result.put("productsSplit", productsSplited);
			result.put("action", actions);
			result.put("actionSplit", actionsSplited);
		}
		
		return result;
	}
	
	public Map<String, Object> rule1(String matchedString, Matcher matcher, LinkedHashMap<String, Object> keyToInfo){
	
		int[] groupNums = {2};
		LinkedHashMap<String, Object> result = commonProcess( matchedString, matcher, keyToInfo, groupNums);
		return result;
	}
	
	public Map<String, Object> rule2(String matchedString, Matcher matcher, LinkedHashMap<String, Object> keyToInfo){
		
		int[] groupNums = {2};
		LinkedHashMap<String, Object> result = commonProcess( matchedString, matcher, keyToInfo, groupNums);
		return result;
		
	}
	
	public Map<String, Object> rule3(String matchedString, Matcher matcher, LinkedHashMap<String, Object> keyToInfo){
	
		int[] groupNums = {4};
		LinkedHashMap<String, Object> result = commonProcess( matchedString, matcher, keyToInfo, groupNums);
		return result;
	}
	
	public Map<String, Object> rule4(String matchedString, Matcher matcher, LinkedHashMap<String, Object> keyToInfo){
		
		int[] groupNums = {3};
		LinkedHashMap<String, Object> result = commonProcess( matchedString, matcher, keyToInfo, groupNums);
		return result;
	}
	
	public Map<String, Object> rule5(String matchedString, Matcher matcher, LinkedHashMap<String, Object> keyToInfo){
		
		int[] groupNums = {2, 4};
		LinkedHashMap<String, Object> result = commonProcess( matchedString, matcher, keyToInfo, groupNums);
		return result;
	}
	
	public Map<String, Object> rule6(String matchedString, Matcher matcher, LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		ArrayList<String> products = new ArrayList<String>();
		//String resultStr = matcher.group(1).replaceAll("#冠词\\d*", KeyWordReplaceUtil.getKeyWordValue(matchedString, "#冠词", keyToInfo)).trim();
		String resultStr = KeyWordReplaceUtil.keyWordReplace(matcher.group(1), "#冠词", keyToInfo);

		
		String houzui = "";
		
		if(resultStr.contains("产品")){
			String[] tokens = resultStr.split(" ");
			for(String token :tokens){
				if(token.contains("产品")){
					houzui = (String) keyToInfo.get(token);
					resultStr = resultStr.replaceAll(token, houzui);
				}
			}
		}
		if(resultStr.length() > 0 && ConfusedExpUtil.isRightProductExpress(resultStr)){
			products.add(resultStr);
		
		
		//result.put("sentencePre", matchedString);
		result.put("productCategory", products);
		result.put("productsSplit", productsSplit(resultStr,houzui));
		
		ArrayList<String> actions = new ArrayList<String>();
		ArrayList<String> actionsSplited = new ArrayList<String>();
		
		if(matchedString.contains("行为")){
			String[] matchedTokens = matchedString.split(" ");
			for(String token : matchedTokens){
				if(token!= null && !token.isEmpty()){
					if(token.contains("行为")){
						String actionToken = keyToInfo.get(token.trim()).toString();
						if(actionToken!= null && !actionToken.isEmpty() ){
							actions.add(actionToken);
							actionsSplited.addAll(productsSplit(actionToken,""));
						}
						
					}
				}
			}
		}
		
		result.put("action", actions);
		result.put("actionSplit", actionsSplited);
		}
		
		return result;
	}
	
	public Map<String, Object> rule7(String matchedString, Matcher matcher, LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		ArrayList<String> products = new ArrayList<String>();
		//String resultStr = matcher.group(1).replaceAll("#冠词\\d*", KeyWordReplaceUtil.getKeyWordValue(matchedString, "#冠词", keyToInfo)).trim();
		String resultStr = KeyWordReplaceUtil.keyWordReplace(matcher.group(1), "#冠词", keyToInfo);
		String houzui = "";
		if(resultStr.contains("产品")){
			String[] tokens = matchedString.split("\\s");
			for(String token :tokens){
				if(token.contains("产品")){
					houzui = (String) keyToInfo.get(token.trim());
					resultStr = resultStr.replaceAll(token, houzui);
				}
			}
		}
		if(resultStr.length() > 0 && ConfusedExpUtil.isRightProductExpress(resultStr)){
			products.add(resultStr);
		
		//result.put("sentencePre", matchedString);
		result.put("productCategory", products);
		result.put("productsSplit", productsSplit(resultStr,houzui));
		
		ArrayList<String> actions = new ArrayList<String>();
		ArrayList<String> actionsSplited = new ArrayList<String>();
		//System.out.println("matchedString====>"+matchedString);
		if(matchedString.contains("行为")){
			String[] matchedTokens = matchedString.split("\\s");
			for(String token : matchedTokens){
				//System.out.println("Token====>"+token);
				if(token!= null && !token.trim().isEmpty()){
					if(token.contains("行为") && keyToInfo.containsKey(token.trim())){
						String actionToken = keyToInfo.get(token.trim()).toString().trim();
						//System.out.println("actionToken===>"+actionToken);
					//	System.out.println("actionToken===>"+actionToken);
						if(actionToken!= null && !actionToken.isEmpty()){
							actions.add(actionToken);
							actionsSplited.addAll(productsSplit(actionToken,""));
						}
					}
				}
			}
		}
		
		result.put("action", actions);
		result.put("actionSplit", actionsSplited);
		}
		return result;
	}
	
	public Map<String, Object> rule8(String matchedString, Matcher matcher, LinkedHashMap<String, Object> keyToInfo){
		
		int[] groupNums = {4, 6};
		LinkedHashMap<String, Object> result = commonProcess( matchedString, matcher, keyToInfo, groupNums);
		return result;
	}
	
	public Map<String, Object> rule9(String matchedString, Matcher matcher, LinkedHashMap<String, Object> keyToInfo){
	
		
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		ArrayList<String> products = new ArrayList<String>();
		//String resultStr = matcher.group(2).replaceAll("#冠词\\d*", KeyWordReplaceUtil.getKeyWordValue(matchedString, "#冠词", keyToInfo)).trim();
		String resultStr = KeyWordReplaceUtil.keyWordReplace(matcher.group(2), "#冠词", keyToInfo);
		String houzui = "";
		
		if(matchedString.contains("产品")){
			String[] tokens = matchedString.split(" ");
			for(String token :tokens){
				if(token.contains("产品")){
					houzui = (String) keyToInfo.get(token.trim());
					resultStr = resultStr.replaceAll(token, houzui);
				}
			}
		}
		
		if(resultStr.length() > 0 && ConfusedExpUtil.isRightProductExpress(resultStr)){
			products.add(resultStr+" "+houzui);
			//result.put("sentencePre", matchedString);
			result.put("productCategory", products);
			result.put("productsSplit", productsSplit(resultStr,houzui));
		
		
		
		ArrayList<String> actions = new ArrayList<String>();
		ArrayList<String> actionsSplited = new ArrayList<String>();
		
		if(matchedString.contains("行为")){
			String[] matchedTokens = matchedString.split("\\s");
			for(String token : matchedTokens){
				if(token!= null && !token.trim().isEmpty()){
					if(token.contains("行为")&&keyToInfo.containsKey(token.trim())){
						String actionToken = keyToInfo.get(token.trim()).toString().trim();
						if(actionToken!= null && !actionToken.isEmpty()){
							actions.add(actionToken);
							actionsSplited.addAll(productsSplit(actionToken,""));
						}
					}
				}
			}
		}
		
		result.put("action", actions);
		result.put("actionSplit", actionsSplited);
		}
		return result;
	}
	
	public Map<String, Object> rule10(String matchedString, Matcher matcher, LinkedHashMap<String, Object> keyToInfo){
		

		int[] groupNums = {1};
		LinkedHashMap<String, Object> result = commonProcess( matchedString, matcher, keyToInfo, groupNums);
		return result;
	}
	
	public Map<String, Object> rule11(String matchedString, Matcher matcher, LinkedHashMap<String, Object> keyToInfo){
		
		int[] groupNums = {1, 4};
		LinkedHashMap<String, Object> result = commonProcess( matchedString, matcher, keyToInfo, groupNums);
		return result;
	}
	
	public Map<String, Object> rule12(String matchedString, Matcher matcher, LinkedHashMap<String, Object> keyToInfo){
		
		int[] groupNums = {1};
		LinkedHashMap<String, Object> result = commonProcess( matchedString, matcher, keyToInfo, groupNums);
		return result;
	}
	
	public Map<String, Object> rule13(String matchedString, Matcher matcher, LinkedHashMap<String, Object> keyToInfo){
		
		int[] groupNums = {2};
		LinkedHashMap<String, Object> result = commonProcess( matchedString, matcher, keyToInfo, groupNums);
		return result;
		
	}
	
	public Map<String, Object> rule14(String matchedString, Matcher matcher, LinkedHashMap<String, Object> keyToInfo){
	
		
		int[] groupNums = {2};
		LinkedHashMap<String, Object> result = commonProcess( matchedString, matcher, keyToInfo, groupNums);
		return result;
	}
	
	public Map<String, Object> rule15(String matchedString, Matcher matcher, LinkedHashMap<String, Object> keyToInfo){
	
		
		int[] groupNums = {1};
		LinkedHashMap<String, Object> result = commonProcess( matchedString, matcher, keyToInfo, groupNums);
		return result;
	}
	
	public Map<String, Object> rule16(String matchedString, Matcher matcher, LinkedHashMap<String, Object> keyToInfo){
		
		int[] groupNums = {3};
		LinkedHashMap<String, Object> result = commonProcess( matchedString, matcher, keyToInfo, groupNums);
		return result;
	}
	
	public Map<String, Object> rule17(String matchedString, Matcher matcher, LinkedHashMap<String, Object> keyToInfo){
	
		int[] groupNums = {1};
		LinkedHashMap<String, Object> result = commonProcess( matchedString, matcher, keyToInfo, groupNums);
		return result;
	}
	
	public Map<String, Object> rule18(String matchedString, Matcher matcher, LinkedHashMap<String, Object> keyToInfo){
		
		int[] groupNums = {6};
		LinkedHashMap<String, Object> result = commonProcess( matchedString, matcher, keyToInfo, groupNums);
		return result;
	}
	
public Map<String, Object> rule19(String matchedString, Matcher matcher, LinkedHashMap<String, Object> keyToInfo){
	
		
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		ArrayList<String> products = new ArrayList<String>();
		//String resultStr = matcher.group(2).replaceAll("#冠词\\d*", KeyWordReplaceUtil.getKeyWordValue(matchedString, "#冠词", keyToInfo)).trim();
		String resultStr = KeyWordReplaceUtil.keyWordReplace(matcher.group(2), "#冠词", keyToInfo);
		
		String productStr = "";
		String houzui = "";
		if(matchedString.contains("产品")){
			String[] tokens = matchedString.split(" ");
			for(String token :tokens){
				if(token.contains("产品")){
					productStr = (String) keyToInfo.get(token.trim());
					resultStr = resultStr.replaceAll(token, productStr);
				}
			}
		}
		//products.add(e)
		
		if(resultStr.length() > 0 && ConfusedExpUtil.isRightProductExpress(resultStr)){
			products.add(resultStr);
		
		//result.put("sentencePre", matchedString);
		result.put("productCategory", products);
		result.put("productsSplit", productsSplit(resultStr,houzui));
		
		ArrayList<String> actions = new ArrayList<String>();
		ArrayList<String> actionsSplited = new ArrayList<String>();
		
		if(matchedString.contains("行为")){
			String[] matchedTokens = matchedString.split("\\s");
			for(String token : matchedTokens){
				if(token!= null && !token.trim().isEmpty()){
					if(token.contains("行为")&&keyToInfo.containsKey(token.trim())){
						String actionToken = keyToInfo.get(token.trim()).toString().trim();
						//System.out.println("gtt"+actionToken);
						if(actionToken!= null && !actionToken.trim().isEmpty()){
							actions.add(actionToken);
							actionsSplited.addAll(productsSplit(actionToken,""));
						}
					}
				}
			}
		}
		
		result.put("action", actions);
		result.put("actionSplit", actionsSplited);
		}
		return result;
	}

	public Map<String, Object> rule20(String matchedString, Matcher matcher, LinkedHashMap<String, Object> keyToInfo){
	
		int[] groupNums = {1};
		LinkedHashMap<String, Object> result = commonProcess( matchedString, matcher, keyToInfo, groupNums);
		return result;
	}
	
public Map<String, Object> rule21(String matchedString, Matcher matcher, LinkedHashMap<String, Object> keyToInfo){
	
		
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		ArrayList<String> products = new ArrayList<String>();
		//String resultStr = matcher.group(2).replaceAll("#冠词\\d*", KeyWordReplaceUtil.getKeyWordValue(matchedString, "#冠词", keyToInfo)).trim();
		String resultStr = KeyWordReplaceUtil.keyWordReplace(matcher.group(2), "#冠词", keyToInfo);
		
		String productStr = "";
		String houzui = "";
		if(matchedString.contains("产品")){
			String[] tokens = matchedString.split(" ");
			for(String token :tokens){
				if(token.contains("产品")){
					productStr = (String) keyToInfo.get(token.trim());
					resultStr = resultStr.replaceAll(token, productStr);
				}
			}
		}
		//products.add(e)
		
		if(resultStr.length() > 0 && ConfusedExpUtil.isRightProductExpress(resultStr)){
			products.add(resultStr);
		
		//result.put("sentencePre", matchedString);
		result.put("productCategory", products);
		result.put("productsSplit", productsSplit(resultStr,houzui));
		
		ArrayList<String> actions = new ArrayList<String>();
		ArrayList<String> actionsSplited = new ArrayList<String>();
		
		if(matchedString.contains("行为")){
			String[] matchedTokens = matchedString.split("\\s");
			for(String token : matchedTokens){
				if(token!= null && !token.trim().isEmpty()){
					if(token.contains("行为")&&keyToInfo.containsKey(token.trim())){
						String actionToken = keyToInfo.get(token.trim()).toString().trim();
						if(actionToken!= null && !actionToken.isEmpty()){
							actions.add(actionToken);
							actionsSplited.addAll(productsSplit(actionToken,""));
						}
					}
				}
			}
		}
		
		result.put("action", actions);
		result.put("actionSplit", actionsSplited);
		}
		return result;
	}
	//和规则6处理相同
	public Map<String, Object> rule22(String matchedString, Matcher matcher, LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		ArrayList<String> products = new ArrayList<String>();
		//String resultStr = matcher.group(1).replaceAll("#冠词\\d*", KeyWordReplaceUtil.getKeyWordValue(matchedString, "#冠词", keyToInfo)).trim();
		String resultStr = KeyWordReplaceUtil.keyWordReplace(matcher.group(1), "#冠词", keyToInfo);
		String houzui = "";
		
		if(resultStr.contains("产品")){
			String[] tokens = resultStr.split(" ");
			for(String token :tokens){
				if(token.contains("产品")){
					houzui = (String) keyToInfo.get(token);
					resultStr = resultStr.replaceAll(token, houzui);
				}
			}
		}
		if(resultStr.length() > 0 && ConfusedExpUtil.isRightProductExpress(resultStr)){
			products.add(resultStr);
		
		//result.put("sentencePre", matchedString);
		result.put("productCategory", products);
		result.put("productsSplit", productsSplit(resultStr,houzui));
		
		ArrayList<String> actions = new ArrayList<String>();
		ArrayList<String> actionsSplited = new ArrayList<String>();
		
		if(matchedString.contains("行为")){
			String[] matchedTokens = matchedString.split(" ");
			for(String token : matchedTokens){
				if(token!= null && !token.isEmpty()){
					if(token.contains("行为")){
						String actionToken = keyToInfo.get(token.trim()).toString();
						if(actionToken!= null && !actionToken.isEmpty()){
							actions.add(actionToken);
							actionsSplited.addAll(productsSplit(actionToken,""));
						}
						
					}
				}
			}
		}
		
		result.put("action", actions);
		result.put("actionSplit", actionsSplited);
		
		}
		return result;
	}
	
	public Map<String, Object> rule23(String matchedString, Matcher matcher, LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		ArrayList<String> products = new ArrayList<String>();
		//String resultStr = matcher.group(1).replaceAll("#冠词\\d*", KeyWordReplaceUtil.getKeyWordValue(matchedString, "#冠词", keyToInfo)).trim();
		String resultStr = KeyWordReplaceUtil.keyWordReplace(matcher.group(1), "#冠词", keyToInfo);

		
		String houzui = "";
		
		if(resultStr.contains("产品")){
			String[] tokens = resultStr.split(" ");
			for(String token :tokens){
				if(token.contains("产品")){
					houzui = (String) keyToInfo.get(token);
					resultStr = resultStr.replaceAll(token, houzui);
				}
			}
		}
		if(resultStr.length() > 0 && ConfusedExpUtil.isRightProductExpress(resultStr)){
			products.add(resultStr);
		
		//result.put("sentencePre", matchedString);
		result.put("productCategory", products);
		result.put("productsSplit", productsSplit(resultStr,houzui));
		
		ArrayList<String> actions = new ArrayList<String>();
		ArrayList<String> actionsSplited = new ArrayList<String>();
		
		if(matchedString.contains("行为")){
			String[] matchedTokens = matchedString.split(" ");
			for(String token : matchedTokens){
				if(token!= null && !token.isEmpty()){
					if(token.contains("行为")){
						String actionToken = keyToInfo.get(token.trim()).toString();
						if(actionToken!= null && !actionToken.isEmpty()){
							actions.add(actionToken);
							actionsSplited.addAll(productsSplit(actionToken,""));
						}
						
					}
				}
			}
		}
		
		result.put("action", actions);
		result.put("actionSplit", actionsSplited);
		}
		
		return result;
	}

}
