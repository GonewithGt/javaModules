package gt.gone.model.product.producttype;

import java.io.FileOutputStream;
import java.io.PrintStream;

import gt.gone.util.FileUtil;
import gt.gone.util.JsonTool;
import gt.gone.util.PropertyUtil;

public class ProductTypeExtractFromStr {
	
	public static void main(String[] args) throws Exception{

		//String fileTest2 = "C:\\Users\\nlp\\workspace\\extractCashFlow3\\src\\main\\resources\\TestRevenue.txt";
		//String fileTest2 = "C:\\Users\\nlp\\workspace\\extractCashFlow3\\src\\main\\resources\\testProduct.txt";
		String fileTest2 = PropertyUtil.getValue("product.type.input");
		int i = 0 ;
		String input = FileUtil.importData(fileTest2, 29);
		//String input = "Fitness brand provides home-based fitness equipment, sports outdoor products, full exercise video tutorials, and other quality health & fitness information offerings.";
		PrintStream ps = new PrintStream(new FileOutputStream("C:\\tmp.txt"));
		if(input!=null){
			ProductTypeExtract cfe = new ProductTypeExtract();
			//ProductExtractFromMatch cfe = new ProductExtractFromMatch();
			String ans = cfe.extractProduct(input);
			
			ps.println(JsonTool.formatJson(ans, "\t"));
			ps.println();
			ps.println();
			//JsonFormatTool jst = new JsonFormatTool();
			System.out.println(JsonTool.formatJson(ans, "\t"));
			System.out.println();
			System.out.println();
		}
	}
	

}

