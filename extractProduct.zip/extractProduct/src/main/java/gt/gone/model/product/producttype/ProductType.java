package gt.gone.model.product.producttype;

import gt.gone.model.common.Intention;
import gt.gone.model.common.Template;
import gt.gone.util.ChangeUtil;
import gt.gone.util.FrequencyUtil;
import gt.gone.util.KeyWordReplaceUtil;
import gt.gone.util.MapUtil;
import gt.gone.util.MoneyUtil;
import gt.gone.util.PatternUtil;
import gt.gone.util.PreProcess;
import gt.gone.util.TimeUtil;
import gt.gone.util.WordCountUtil;
import gt.gone.util.XmlUtil;

import java.awt.Point;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class ProductType {
	
	private String inputString ; //原句
	private String changedString ; //关键词替换后的句子
	private LinkedHashMap<String ,Object> entityNameToEntityMap; //实体名 到实体的映射
	private LinkedHashMap<String ,Object> keyToInfoMap; //抽取的信息
	private  LinkedHashMap<String ,Object> resultMap; //最终抽取的信息
	private List<LinkedHashMap<String, Object> > resultList ;
	public List<LinkedHashMap<String, Object>> getResultList() {
		return resultList;
	}
	public void setResultList(List<LinkedHashMap<String, Object>> resultList) {
		this.resultList = resultList;
	}
	public ProductType(String input){
		this.setInputString(input);
		this.changedString = input;
		this.entityNameToEntityMap = new LinkedHashMap<String ,Object>();
		this.keyToInfoMap= new LinkedHashMap<String, Object>();
		this.resultMap= new LinkedHashMap<String, Object>();
		this.resultList = new ArrayList<LinkedHashMap<String, Object> >();
		process(input, null);
	}
	
	public ProductType(String input, XmlUtil xml){
		this.setInputString(input);
		this.changedString = input;
		this.entityNameToEntityMap = new LinkedHashMap<String ,Object>();
		this.keyToInfoMap= new LinkedHashMap<String, Object>();
		this.resultMap= new LinkedHashMap<String, Object>();
		this.resultList = new ArrayList<LinkedHashMap<String, Object> >();
		process(input, xml);
	}
	
	private void process(String sentence, XmlUtil xml) {
		// TODO Auto-generated method stub
		if(xml==null){
			xml = new XmlUtil("product","producttype","product.xml");
		}
		Map<Point ,Object> positionToEntity = new HashMap<Point ,Object>();
		String changedSentence = new String(sentence);
		//this.setResultMap(new LinkedHashMap<String, Object>());
		/*PatternUtil pu = new PatternUtil();
		LinkedHashMap<String ,String> keyWordToRegex = pu.toRegex(xml.conceptMap);
		String changedSentence = new String(sentence);
		
		//Set<Point> matchedPos = new HashSet<Point>();
		boolean flag = false;
		for (Map.Entry<String, String> entry :keyWordToRegex.entrySet()) {   
		  // System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue()); 
		   Pattern r = Pattern.compile(entry.getValue().toLowerCase());
		   Matcher m = r.matcher(sentence.toLowerCase());
		   //Matcher change = r.matcher(sentence);
		   int count = 0 ;	   
		   int matchLength = 0;
		   int start = 0;
		   int end = 0;
		   while(m.find()) {
			   	flag = true;
		         count++;
		         start = m.start();
		         end = m.end();
		         
		         if(end > 0 && sentence.charAt(end-1)==' '){
		        	 end = end - 1;
		         }
		         matchLength = end - start;
		        // System.out.println(sentence.substring(start,end)+" "+start+" "+end); //gt
		         Point currentMatchPos = new Point(start,end);
		         List<Point> jiaoChaPoints = selectJiaochaPoint(currentMatchPos , positionToEntity.keySet()); //和当前点有交叉的区域
		         
		         if(jiaoChaPoints.isEmpty()){
		        	 positionToEntity.put(currentMatchPos, entry.getKey());
		        	
		         }else if(!jiaoChaPoints.isEmpty() ){
		        	 for(Point jiaoChaPoint: jiaoChaPoints){
		        		// System.out.println("jiaochapoints: "+sentence.substring(jiaoChaPoint.x, jiaoChaPoint.y)+" x:"+jiaoChaPoint.x+" y:"+jiaoChaPoint.y);//gt
		        		 
		        		 // System.out.println("x:"+jiaoChaPoint.x);
		        		// System.out.println("y:"+jiaoChaPoint.y);
		        		 if(matchLength > (jiaoChaPoint.y- jiaoChaPoint.x)){
		        			// System.out.println("matchLength:"+matchLength);
		        			 positionToEntity.remove(jiaoChaPoint);
		        		 }
		        	
		        	 }
		        	
		        	 
		        	 positionToEntity.put(currentMatchPos, entry.getKey());
		         }
		   
		      }
			
			
		}
		positionToEntity = MapUtil.getOrder(positionToEntity);*/
		
		
		positionToEntity = KeyWordReplaceUtil.getTokenPositionByRegex(sentence, xml, positionToEntity, changedSentence);
		for(Point point: positionToEntity.keySet()){
			System.out.println("point: "+sentence.substring(point.x, point.y)+" x:"+point.x+" y:"+point.y);//gt	
		}
		
		if(positionToEntity.size()>0){
			changedSentence = sentenceReplacedWithKeyWord(sentence, (LinkedHashMap<Point, Object>) positionToEntity, xml);	
		}	
		//this.resultMap.put("productCategory", matchTemplate(xml,preProcess(sentence)));
		
		
	}
	
	//将原句中匹配的部分进行关键字替换
	private String sentenceReplacedWithKeyWord(String sentence, LinkedHashMap<Point, Object> positionToEntity, XmlUtil xml) {
			// TODO Auto-generated method stub
			String sentenceTmp = new String(sentence);
			PatternUtil pu = new PatternUtil();
			if(xml==null){
				xml = new XmlUtil("product","producttype","product.xml");
			}
			//LinkedHashMap<String,String> regexs = pu.toRegex(xml.conceptMap);
			int count = 0;
			StringBuilder sentenceReplacedSb = new StringBuilder();
			int startPos = 0;
			for( Map.Entry<Point,Object> entry : positionToEntity.entrySet()){
				
				int start = entry.getKey().x;
				int end = entry.getKey().y;
				String oldChar = sentenceTmp.substring(start,end);
				String keyToken = entry.getValue().toString();
				
				
				boolean flag = false;
				String keyTokenTmp = new String(keyToken);
				boolean tokenToDisplayFlag =false;
				if(keyToken.contains("行为名词")
						||keyToken.contains("行为动词")
						||keyToken.contains("企业")
						||keyToken.contains("冠词")
						||keyToken.contains("产品")
						||keyToken.contains("动词")
						||keyToken.contains("介词")
						||keyToken.contains("形容词")
						||keyToken.contains("指示性动词")
						||keyToken.contains("剔除词")
						){
	
					tokenToDisplayFlag = true;
					count++;
					keyToken = keyToken+count;
					keyTokenTmp = keyToken;
				}
				//按词进行替换 消除一个词被部分截断的问题
				/*if(tokenToDisplayFlag){
					if(sentence.contains(" "+oldChar.trim()+" ")){
						//sentence = sentence.replace(" "+oldChar.trim()+" " , " "+"#"+ keyTokenTmp +" ");
						flag = true;
					}else if(sentence.contains(oldChar.trim()+" ")){
						if(start==0 ||start>0&& sentenceTmp.charAt(start-1)=='.'||sentenceTmp.charAt(start-1)=='('||sentenceTmp.charAt(start-1)==')'||sentenceTmp.charAt(start-1)==','
								||sentenceTmp.charAt(start-1)=='\"'
								||sentenceTmp.charAt(start-1)==':'
								||sentenceTmp.charAt(start-1)=='/'
								||sentenceTmp.charAt(start-1)=='!'){
							if(!keyTokenTmp.contains("介词")&&
									!keyTokenTmp.contains("动词")&&
									!keyTokenTmp.contains("冠词")
									){ //这些词比较短，可能会作为其它词的一部分，不能直接这样替代
							flag = true;
							//sentence = sentence.replace(oldChar.trim()+" " , " "+"#"+ keyTokenTmp +" ");
							}
						}				
					}else if(sentence.contains(" "+oldChar.trim())){
						//System.out.println(" "+oldChar.trim() );
						//System.out.println(start);
						//System.out.println(end);
						//System.out.println(sentenceTmp.charAt(end));
						//System.out.println(sentenceTmp.length());
						if(end ==sentenceTmp.length()||end>0 && end < sentenceTmp.length() && (sentenceTmp.charAt(end)=='.'||sentenceTmp.charAt(end)==')'
								||sentenceTmp.charAt(end)=='-'&& end+1 < sentenceTmp.length()&&sentenceTmp.charAt(end+1)==' '
								||sentenceTmp.charAt(end)==','
								||sentenceTmp.charAt(end)=='\"'
								||sentenceTmp.charAt(end)=='/'
								||sentenceTmp.charAt(end)=='('
								||sentenceTmp.charAt(end)==':'
								||sentenceTmp.charAt(end)=='!')){
							if(!keyTokenTmp.contains("介词")&&
									!keyTokenTmp.contains("动词")&&
									!keyTokenTmp.contains("冠词")
									){ //这些词比较短，可能会作为其它词的一部分，不能直接这样替代
							flag = true;
							//sentence = sentence.replace(" "+oldChar.trim(), " "+"#"+ keyTokenTmp +" ");
							}
						}
					}else if(sentence.contains(oldChar.trim())){
						if(start==0 && end==sentenceTmp.length() 
								||sentenceTmp.contains(oldChar.trim()+",")
								||sentenceTmp.contains(oldChar.trim()+"\"")
								||sentenceTmp.contains("\""+oldChar.trim())
								||sentenceTmp.contains("("+oldChar.trim())
								||sentenceTmp.contains(oldChar.trim()+")")
								||sentenceTmp.contains(oldChar.trim()+":")
								||sentenceTmp.contains(oldChar.trim()+"!")
								||sentenceTmp.contains(oldChar.trim()+"2")){
							if(!keyTokenTmp.contains("介词")&&
									!keyTokenTmp.contains("动词")&&
									!keyTokenTmp.contains("冠词")
									){ //这些词比较短，可能会作为其它词的一部分，不能直接这样替代
								flag = true;
								//sentence = sentence.replace(oldChar.trim(), " "+"#"+ keyTokenTmp +" ");
							}
							
						}
					}
				
					
				}*/
				
				if(tokenToDisplayFlag){
					flag = KeyWordReplaceUtil.isCorrectToken(sentenceTmp, start, end, keyTokenTmp, oldChar);
				}	
				/*System.out.println("sentenceLength:"+sentenceTmp.length());
				System.out.println("startPos: "+ startPos);
				System.out.println("start: "+ start);
				System.out.println("end: "+ end);
				System.out.println("flag: "+ flag);*/
				if(flag && tokenToDisplayFlag){
					sentenceReplacedSb.append(sentenceTmp.substring(startPos,start));
					sentenceReplacedSb.append(" "+"#"+ keyTokenTmp +" ");
					startPos = end;
					this.keyToInfoMap.put("#"+keyToken.trim(), oldChar);		
				}
			}
			if(startPos < sentenceTmp.length()){
				sentenceReplacedSb.append(sentenceTmp.substring(startPos));
			}
			sentence = sentenceReplacedSb.toString();
			String[] sensStrings = PreProcess.splitInput(sentence);
			for(String sen : sensStrings){
				sen = sen.trim()+ " .";
				if(sen!=null && !sen.isEmpty()){
					System.out.println("preProcess===>"+preProcess(sen));
					LinkedHashMap<String ,Object> entityResultMap = matchTemplate(xml, preProcess(sen), this.keyToInfoMap);
					if(entityResultMap!=null && entityResultMap.size() > 0 &&
							(((ArrayList<String>)entityResultMap.get("productCategory")).size()>0
									||((ArrayList<String>)entityResultMap.get("action")).size()>0)){
						this.resultList.add(entityResultMap);
					}
				}
				
			}
			
			
			/*this.resultMap.put("productIndustry", "");
			this.resultMap.put("productTechnology", "");
			this.resultMap.put("productMarket","");
			this.resultMap.put("productClient","");*/
			//resultMap.put("Sentence", sentenceTmp);
			//resultMap.put("SentenceReplaced", preProcess(sentence));
			System.out.println("SentenceReplaced===>"+preProcess(sentence));
			return sentence;
		}
		
	
	public static String preProcess(String str){
		
		str = str.replaceAll("\\.", " \\.").replaceAll(",", " ,").replaceAll("!", " !").replaceAll("\\?", " ?").replaceAll(":-", " ").replaceAll(":", " :").replaceAll("\\/", " \\/ ");
		
		return str;
	}
	
	private List<Point> selectJiaochaPoint(Point currentPosPoint, Set<Point> keySet) {
		// TODO Auto-generated method stub
		List<Point> jiaoChaPoints = new ArrayList<Point>();
			for(Point p : keySet){
				if(p.x < currentPosPoint.x && currentPosPoint.x < p.y || p.x < currentPosPoint.y && currentPosPoint.y < p.y ||p.x >= currentPosPoint.x && currentPosPoint.y >= p.y 
						)
					//return p;
					jiaoChaPoints.add(p);
				
			}
		return jiaoChaPoints;
	}
	
	private LinkedHashMap<String, Object> matchTemplate(XmlUtil xml, String changedSentence, LinkedHashMap<String, Object> keyToInfoMap){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		//System.out.println("反射调用之前"+changedSentence);
		//Intention longestIntention = new Intention();
		String longestMatchString = "";
		String longestMatchTemplate = "";
		String methodName = "";
		String className = "";
		Matcher matcherBest = null;
		for(Intention intention : xml.intentionList){			
			for(Template template: intention.getTemplates()){
				Pattern pattern = Pattern.compile(template.getTemplatetext());
				Matcher matcher = pattern.matcher(preProcess(changedSentence));
				
				if(matcher.find()){
					if(matcher.group(0).length() > longestMatchString.length()){
					//if(WordCountUtil.countEntityNum(matcher.group(0)) > WordCountUtil.countEntityNum(longestMatchString)
				//			||WordCountUtil.countEntityNum(matcher.group(0)) == WordCountUtil.countEntityNum(longestMatchString)&& WordCountUtil.countWordNum(matcher.group(0))< WordCountUtil.countWordNum(longestMatchString)){

						/*System.out.println(template.getTemplatetext());
						System.out.println(matcher.group(0));
						System.out.println(matcher.group(0).length());
						System.out.println(longestMatchString);
						System.out.println(longestMatchString.length());*/
						longestMatchString = matcher.group(0);
						className = intention.getName();
						methodName = template.getName();
						matcherBest=matcher;
						longestMatchTemplate = template.getName()+" : "+template.getTemplatetext();
					}
				}
			}
		}
		
		System.out.println("template===>"+longestMatchTemplate);
		System.out.println("matchedStr===>"+longestMatchString);
		if(longestMatchString!=null&& !longestMatchString.isEmpty()
			&&className!=null&& !className.isEmpty()
			&&methodName!=null&& !methodName.isEmpty()
			&matcherBest!=null){
			try {
				//String matchedString  = matcher.group(0);
				Class cls = Class.forName(className);
				Object process = cls.newInstance(); 
				Method processMethod = cls.getDeclaredMethod(methodName, String.class, Matcher.class, LinkedHashMap.class);  
				result = (LinkedHashMap<String, Object>) processMethod.invoke(process, longestMatchString, matcherBest, keyToInfoMap);//调用xml中对应的方法  					              
				return result;
			} catch (ClassNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
				System.out.println(className+"类未定义");
			} catch (InstantiationException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalAccessException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (IllegalArgumentException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (InvocationTargetException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (NoSuchMethodException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} catch (SecurityException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
		}
			
	
		return result;
		
	}

	

	public LinkedHashMap<String ,Object> getResultMap() {
		return resultMap;
	}

	public void setResultMap(LinkedHashMap<String ,Object> resultMap) {
		this.resultMap = resultMap;
	}

	public String getInputString() {
		return inputString;
	}

	public void setInputString(String inputString) {
		this.inputString = inputString;
	}

	public String getChangedString() {
		return changedString;
	}

	public void setChangedString(String changedString) {
		this.changedString = changedString;
	}

	public LinkedHashMap<String ,Object> getEntityNameToEntityMap() {
		return entityNameToEntityMap;
	}

	public void setEntityNameToEntityMap(LinkedHashMap<String ,Object> entityNameToEntityMap) {
		this.entityNameToEntityMap = entityNameToEntityMap;
	}

	public LinkedHashMap<String ,Object> getKeyToInfoMap() {
		return keyToInfoMap;
	}

	public void setKeyToInfoMap(LinkedHashMap<String ,Object> keyToInfoMap) {
		this.keyToInfoMap = keyToInfoMap;
	}

}
