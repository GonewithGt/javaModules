package gt.gone.model.product.producttype;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.LinkedHashMap;

import org.apache.commons.io.ByteOrderMark;
import org.apache.commons.io.input.BOMInputStream;

import gt.gone.util.FileUtil;
import gt.gone.util.JsonFormatTool;
import gt.gone.util.JsonTool;
import gt.gone.util.PatternUtil;
import gt.gone.util.PreProcess;
import gt.gone.util.PropertyUtil;
import gt.gone.util.Word2VEC;
import gt.gone.util.XmlUtil;
import net.sf.json.JSONObject;

public class ProductTypeExtract {
	
	
	 public static String word2VecPath2 = PropertyUtil.getValue("word2VecPath");
	 public static Word2VEC w1 = new Word2VEC(word2VecPath2);
	 public static XmlUtil productxml = new XmlUtil("product","producttype","product.xml");
	 public static PatternUtil pu = new PatternUtil();
	 public static String productRegex = pu.templateToRegex("企业", productxml.conceptMap).getReg()
			 +"|"+pu.templateToRegex("行为名词", productxml.conceptMap).getReg()
			 +"|"+pu.templateToRegex("行为动词", productxml.conceptMap).getReg()
			 +"|"+pu.templateToRegex("产品", productxml.conceptMap).getReg()
			;
	
	public  String extractProduct(String input){
		String productInputStr = PreProcess.getKeySentences(input, productRegex);
		ProductType product = new ProductType(productInputStr,this.productxml);
		String resultStr ="";
		//resultStr = JSONObject.fromObject(sentence.getEntityNameToEntityMap()).toString();
		LinkedHashMap<String ,Object> resultMap = new LinkedHashMap<String ,Object>();
		resultMap.put("Sentence", input);
		resultMap.put("productType", product.getResultList());
		resultStr = JSONObject.fromObject(resultMap).toString();
		//resultStr = JSONObject.fromObject(product.getResultMap()).toString();
		//System.out.println(JsonTool.formatJson(sentence.getKeyToInfoMap().toString(), " "));
		return resultStr;
	}
	
	public  String extractProduct(String input, XmlUtil xml){
		String productInputStr = PreProcess.getKeySentences(input, productRegex);
		ProductType product = new ProductType(productInputStr,xml);
		String resultStr ="";
		LinkedHashMap<String ,Object> resultMap = new LinkedHashMap<String ,Object>();
		resultMap.put("Sentence", input);
		resultMap.put("productType", product.getResultList());
		resultStr = JSONObject.fromObject(resultMap).toString();
		//resultStr = JSONObject.fromObject(sentence.getEntityNameToEntityMap()).toString();
		//resultStr = JSONObject.fromObject(product.getResultMap()).toString();
		//System.out.println(JsonTool.formatJson(sentence.getKeyToInfoMap().toString(), " "));
		return resultStr;
	}
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		//String fileTest2 = "D:\\java\\cashFlow\\extractCashFlow3\\src\\main\\resources\\test2.txt";
		//String input = FileUtil.importData(fileTest2, 1);
		// String word2VecPath2 = "D:\\whh-spaces\\extractCashFlow3\\src\\main\\resources\\vector.mod";
		// String word2VecPath2 = PropertyUtil.getValue("word2VecPath");
	//	 Word2VEC w1 = new Word2VEC(word2VecPath2);
		
		 PrintStream ps;
			try {
				//ps = new PrintStream(new FileOutputStream("C:\\TestData\\extractProductJson2.txt"));
				ps = new PrintStream(new FileOutputStream(PropertyUtil.getValue("product.type.output")));
				//System.setOut(ps);  
				//String fileTestProduct = "C:\\Users\\nlp\\workspace\\extractCashFlow3\\src\\main\\resources\\testProduct.txt";
				//String fileTestProduct2 = "C:\\TestData\\TestProductAll.txt";
				String fileTestProduct = PropertyUtil.getValue("product.type.input");
				String line = null;
				  //  int n = 3;//从第三行开始读取
				    try {
				    	//FileInputStream fileInputStream  = new FileInputStream(filePath);
				    	//InputStreamReader isr = new InputStreamReader(fileInputStream, "UTF-8");
				    	// ClassLoader classLoader = XmlUtil.class.getClassLoader();
				    	// FileInputStream fis = (FileInputStream) classLoader.getResourceAsStream(filePath); 
				    	ProductTypeExtract pe = new ProductTypeExtract();
				    //	XmlUtil xml = new XmlUtil("product","producttype","product.xml");
				    	FileInputStream fis = new FileInputStream(fileTestProduct);
			        	   //可检测多种类型，并剔除bom
			        	BOMInputStream bomIn = new BOMInputStream(fis, false,ByteOrderMark.UTF_8, ByteOrderMark.UTF_16LE, ByteOrderMark.UTF_16BE);
			        	String charset = "utf-8";
			        	   //若检测到bom，则使用bom对应的编码
			        	if(bomIn.hasBOM()){
			        		charset = bomIn.getBOMCharsetName();
			        	 }
			        	BufferedReader br = new BufferedReader(new InputStreamReader(bomIn, charset));
						//br = new BufferedReader(new InputStreamReader(new FileInputStream(filePath), "UTF-8"));
						int i = 1;
						 while ((line = br.readLine()) != null) {
							 String ans = pe.extractProduct(line,productxml);
								//JsonFormatTool jst = new JsonFormatTool();
							 	ps.println("LineNum" + i++);
							 	System.out.println(i);
							 	ps.println(JsonTool.formatJson(ans, "\t"));
							 	ps.println();
							 	ps.println();
							}
						 br.close();
						 
					} catch (FileNotFoundException e1) {
						// TODO Auto-generated catch block
						e1.printStackTrace();
					} catch (IOException e) {
						// TODO Auto-generated catch block
						e.printStackTrace();
					}
				/*for(int i = 1 ; i < 30 ; i++){
					
					String input = FileUtil.importData(fileTestProduct, i);	
					if(input!=null){
						ProductTypeExtract pe = new ProductTypeExtract();
						String ans = pe.extractProduct(input);
						//JsonFormatTool jst = new JsonFormatTool();
						System.out.println(JsonTool.formatJson(ans, "\t"));
						System.out.println();
						System.out.println();
					}
					
				}*/
		
			/*	String input = FileUtil.importData(fileTestProduct, 1);
				ProductExtract pe = new ProductExtract();
				String ans = pe.extractProduct(input);
				JsonFormatTool jst = new JsonFormatTool();
				System.out.println(JsonTool.formatJson(ans, " "));*/
				
			
			} catch (FileNotFoundException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 

	}


}
