package gt.gone.model.common;

public class ExtractTarget {
	private String extractName; // extract name 
	private String extractRegex;// extract regex
	
	
	public ExtractTarget(String extractName, String extractRegex) {
		this.extractName = extractName;
		this.extractRegex = extractRegex;
	}
	public String getExtractName() {
		return extractName;
	}
	public void setExtractName(String extractName) {
		this.extractName = extractName;
	}
	public String getExtractRegex() {
		return extractRegex;
	}
	public void setExtractRegex(String extractRegex) {
		this.extractRegex = extractRegex;
	}
	
	
	

}
