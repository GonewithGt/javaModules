package gt.gone.model.product.productclient;

import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


import gt.gone.util.FileUtil;
import gt.gone.util.JsonTool;
import gt.gone.util.MongoDBUtil;
import gt.gone.util.PropertyUtil;
import gt.gone.util.WordTree;
import gt.gone.util.WordTreeCase;
import net.sf.json.JSONObject;

public class ExtraClient {

	// public static String preProcess(String str) {
	// return str.replaceAll(", |\"|\\|/", " ").replaceAll("\\.|\\?|!", " .");
	// }

	public static String preProcess(String str) {
		return str.replaceAll("\\?|!", " .").replace(",", " ,")
				.replace("\"", " \"").replace("\\", " \\").replace("/", " /")
				.replace(".", " .");
	}

	// 计算结果出现的次数
	public static int count(String text, String sub) {
		int count = 0;
		int start = 0;
		while (((start = text.indexOf(sub, start))) >= 0) {
			start += sub.length();
			count++;
		}
		return count;
	}

	public static LinkedHashMap<String, Object> extractClient(String oldInput,
			WordTree locationWordTree, WordTree scaleWordTree,
			WordTree growWordTree, WordTree steadyFeaturesWordTree,
			WordTree loyalFeaturesWordTree,
			WordTree highQualityFeaturesWordTree,
			WordTree variousFeaturesWordTree) throws Exception {
		LinkedHashMap<String, Object> resultMap = new LinkedHashMap<String, Object>(); // 抽取的信息
		// List locationList = new LinkedList<String>();
		Set locationSet = new LinkedHashSet();
		List scaleList = new LinkedList<String>();
		List growList = new LinkedList<String>();
		List featuresList = new LinkedList<String>();

		// 数据的统一预处理
		String input = preProcess(oldInput);

		List steadyFeaturesList = new LinkedList<String>();
		List loyalFeaturesList = new LinkedList<String>();
		List highQualityFeaturesList = new LinkedList<String>();
		List variousFeaturesList = new LinkedList<String>();
		Map steadyFeaturesMap = new HashMap<String, Object>();
		Map loyalFeaturesMap = new HashMap<String, Object>();
		Map highQualityFeaturesMap = new HashMap<String, Object>();
		Map variousFeaturesMap = new HashMap<String, Object>();
		if (input != null) {

			// 一段文本进行分句
			String[] clients = input.split("\\.");
			ArrayList clientList = new ArrayList<Object>();
			for (String client : clients) {

				// 句号分割的是否含有种子词
				if (client.toLowerCase().contains("client")
						|| client.toLowerCase().contains("clients")
						|| client.toLowerCase().contains("clientele")
						|| client.toLowerCase().contains("customer")
						|| client.toLowerCase().contains("customers")) {

					// 判断是否有市场的位置
					if (client.toLowerCase().contains("market")
							|| client.toLowerCase().contains("markets")
							|| client.toLowerCase().contains("marketing")) {
						// 将一些固定的搭配替换
						client = client
								.replaceAll(
										"(market|markets|marketing)(\\s)*(\\b\\w*\\s+){0,3}(\\s)*located\\sin(\\s)*(\\b\\w*\\s+){0,3}(\\s)*serving",
										"");

					}

					// 抽取地理位置(客户)
					String[] clientLocationReg = {
							"(\\b\\w*\\s+){1,3}(\\s)*(Client|Clients|client|clients)(\\s)*(\\b\\w*\\s+){0,3}",
							"(Client|Clients|client|clients)(\\s)*(come|comes|came)(\\s)*from(\\s)*(all over\\s)?(the\\s)?(\\b\\w*\\s+){1,3}",
							"(\\b\\w*\\s+){1,3}(\\s)*and(\\b\\w*\\s+){1,3}(\\s)*(Client|Clients|client|clients)",
							"(Client|Clients|client|clients)(\\s)*(\\b\\w*\\s+){0,3}(\\s)*(throughout\\s|around\\s)(all over\\s)?(the\\s)?(\\b\\w*\\s+){1,3}",
							"(Client|Clients|client|clients)(\\s)*(in\\s|within\\s)both(\\s)*(\\b\\w*\\s+){1,3}(\\s)*and\\s(\\b\\w*\\s+){1,3}",
							"(Client|Clients|client|clients)(\\s)*(\\b\\w*\\s+){0,3}(\\s)*located\\sin(\\s)*(\\b\\w*\\s+){1,3}(\\s)*and\\s(\\b\\w*\\s+){1,3}"
					// "(Southeast|southeast|South|south)?\\s(Asia|asia|Asian|asian|European|european|State|state|Australia|(the)?USA)",
					// "(domestic|International|Northern Rocky Mountains|Connecticut)"
					// "(Broad overall|Nationwide|Domestic|local)(\\s)*(\\b\\w*\\s+|,\\s+){0,2}(\\s)*(clients|client)",
					// "United States|the USA"
					};
					// 通过规则抽取的list
					ArrayList<String> extractedStringList0 = (ArrayList<String>) MongoDBUtil
							.extractByReg(client, clientLocationReg);

					// 对规则抽取的list进行拼接
					StringBuilder match = new StringBuilder();
					for (String location : extractedStringList0) {
						match.append(location);
						match.append(" ");
					}

					// 将拼接后的字符串与词库匹配
					ArrayList<String> extractedStringList1 = (ArrayList<String>) MongoDBUtil
							.extract(match.toString(), locationWordTree);

					//后期可以放到工具类teamAddAdjectiveUtil里面去
					// 如果匹配上
					if (extractedStringList1.size() != 0) {

//						System.out.print(extractedStringList1);

						// 去除包含的情况
//						StringBuilder locationString = new StringBuilder();
//						for (String str : extractedStringList1) {
//							locationString.append(str);
//							locationString.append(" ");
//						}
//
//						Set newSet = new HashSet<>();
//						for (String str : extractedStringList1) {
//							if (count(locationString.toString(), str) == 1) {
//								newSet.add(str);
//							}
//						}

						for (Object str : extractedStringList1) {
							// 后期用正则匹配，将匹配到的结果加上固定的搭配与原句比较
							String[] regs = {
									"(Southeast|south|southern|Southeastern)\\s"
											+ str.toString(),
									"(all over|around|throughout)\\s(the\\s)?(Southeast\\s|south\\s|southern\\s|Southeastern\\s)?"
											+ str.toString(),

							};
							int count = 0;
							for (String reg : regs) {
								Pattern pattern = Pattern.compile(reg);
								Matcher matcher = pattern.matcher(client);

								while (matcher.find()) {
									count++;
									locationSet.add(matcher.group());
								}

							}
							if (count == 0)
								locationSet.add(str);
						}
					}

					// 抽取规模(客户)

					ArrayList<String> extractedScaleList = (ArrayList<String>) MongoDBUtil
							.extractClientScale(client, scaleWordTree);
					if (extractedScaleList.size() == 0)
						;
					// scaleList.add("");
					else {
						for (String str : extractedScaleList) {
							scaleList.add(str);
						}
					}

					// 抽取增长(客户)
					ArrayList<String> extractedGrowList = (ArrayList<String>) MongoDBUtil
							.extract(client, growWordTree);
					if (extractedGrowList.size() == 0)
						;
					// growList.add("");
					else {
						for (String str : extractedGrowList) {
							growList.add(str);
						}
					}

					// 抽取稳定特征(客户)
					ArrayList<String> extractedSteadyFeaturesList = (ArrayList<String>) MongoDBUtil
							.extract(client, steadyFeaturesWordTree);
					if (extractedSteadyFeaturesList.size() == 0)
						;
					// steadyFeaturesList.add("");
					else {
						for (String str : extractedSteadyFeaturesList) {
							steadyFeaturesList.add(str);
						}
					}
					

					// 抽取忠诚特征(客户)
					ArrayList<String> extractedLoyalFeaturesList = (ArrayList<String>) MongoDBUtil
							.extract(client, loyalFeaturesWordTree);
					if (extractedLoyalFeaturesList.size() == 0)
						;
					// loyalFeaturesList.add("");
					else {
						for (String str : extractedLoyalFeaturesList) {
							loyalFeaturesList.add(str);
						}
					}
					

					// 抽取优质特征(客户)
					ArrayList<String> extractedHighQualityFeaturesList = (ArrayList<String>) MongoDBUtil
							.extract(client, highQualityFeaturesWordTree);
					if (extractedHighQualityFeaturesList.size() == 0)
						;
					// highQualityFeaturesList.add("");
					else {
						for (String str : extractedHighQualityFeaturesList) {
							highQualityFeaturesList.add(str);
						}
					}
					

					// 抽取多样特征(客户)
					ArrayList<String> extractedVariousFeaturesList = (ArrayList<String>) MongoDBUtil
							.extract(client, variousFeaturesWordTree);
					if (extractedVariousFeaturesList.size() == 0)
						;
					// variousFeaturesList.add("");
					else {
						for (String str : extractedVariousFeaturesList) {
							variousFeaturesList.add(str);
						}
					}
					

				}

			}
			if (steadyFeaturesList.size() != 0) {
				steadyFeaturesMap.put("steadyFeature",
						steadyFeaturesList);
				featuresList.add(steadyFeaturesMap);
			}
			
			if (loyalFeaturesList.size() != 0) {
				loyalFeaturesMap.put("loyalFeature", loyalFeaturesList);
				featuresList.add(loyalFeaturesMap);
			}
			
			if (highQualityFeaturesList.size() != 0) {
				highQualityFeaturesMap.put("highQualityFeature",
						highQualityFeaturesList);
				featuresList.add(highQualityFeaturesMap);
			}
			
			if (variousFeaturesList.size() != 0) {
				variousFeaturesMap.put("variousFeature",
						variousFeaturesList);
				featuresList.add(variousFeaturesMap);
			}
			
			// 去除包含的情况
			if (locationSet == null)
				resultMap.put("location", new HashMap<>());
			else {
				StringBuilder locationString = new StringBuilder();
				for (Object setObject : locationSet) {
					locationString.append(setObject.toString());
					locationString.append(" ");
				}

				Set newSet = new LinkedHashSet<>();
				for (Object setObject : locationSet) {
					if (count(locationString.toString(), setObject.toString()) == 1) {
						newSet.add(setObject);
					}
				}
				resultMap.put("location", newSet);
			}

			if (scaleList == null)
				resultMap.put("scale", new HashMap<>());
			else
				resultMap.put("scale", scaleList);
			if (growList == null)
				resultMap.put("scale", new HashMap<>());
			else
				resultMap.put("grow", growList);
			resultMap.put("features", featuresList);

		}
		return resultMap;

	}

	public static void main(String[] args) throws Exception {
		//PrintStream ps = new PrintStream(new FileOutputStream(
		//		"C:\\extractClient.txt"));
		PrintStream ps = new PrintStream(new FileOutputStream(PropertyUtil.getValue("product.client.output")));
		System.setOut(ps);
		//String fileTest = "C:\\Users\\nlp\\workspace1\\extractCashFlow3\\src\\main\\resources\\client.txt";
		String fileTest = PropertyUtil.getValue("product.client.input");
		Map<String, String> map = new HashMap<String, String>();
		WordTree locationWordTree = new WordTree();
		WordTree scaleWordTree = new WordTree();
		WordTree growWordTree = new WordTree();
		WordTree steadyFeaturesWordTree = new WordTree();
		WordTree loyalFeaturesWordTree = new WordTree();
		WordTree highQualityFeaturesWordTree = new WordTree();
		WordTree variousFeaturesWordTree = new WordTree();

		locationWordTree = MongoDBUtil.getLocationFromMongoDB();
		scaleWordTree = WordTreeCase.getClientScaleWordTree();
		growWordTree = WordTreeCase.getClientGrowWordTree();
		steadyFeaturesWordTree = WordTreeCase.getSteadyClientFeaturesWordTree();
		loyalFeaturesWordTree = WordTreeCase.getLoyalClientFeaturesWordTree();
		highQualityFeaturesWordTree = WordTreeCase
				.getHighQualityClientFeaturesWordTree();
		variousFeaturesWordTree = WordTreeCase
				.getVariousClientFeaturesWordTree();
		for (int i = 1; i < 36; i++) {
			String input = FileUtil.importData(fileTest, i);
			System.out.println(input);
			System.out.println(JsonTool.formatJson(
					JSONObject.fromObject(
							extractClient(input, locationWordTree,
									scaleWordTree, growWordTree,
									steadyFeaturesWordTree,
									loyalFeaturesWordTree,
									highQualityFeaturesWordTree,
									variousFeaturesWordTree)).toString(), "\t")

			);
			System.out.println();
		}
	}

}
