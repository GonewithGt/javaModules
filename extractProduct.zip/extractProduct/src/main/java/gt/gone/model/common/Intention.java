package gt.gone.model.common;

import java.util.List;

import gt.gone.model.common.Template;

public class Intention {
	private String name; //意图对应的名字
	private String id; //意图对应的id
	private List<Template> templates; //意图对应的模板
	//private String template ;
	
	public Intention(String name, String id, List<Template> templates){
		this.name = name;
		this.id = id;
		this.templates = templates;
	}
	
	
	public Intention() {
		// TODO Auto-generated constructor stub
	}


	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public List<Template> getTemplates() {
		return templates;
	}
	public void setTemplates(List<Template> templates) {
		this.templates = templates;
	}

}
