package gt.gone.model.product;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.Map;

import org.apache.commons.io.ByteOrderMark;
import org.apache.commons.io.input.BOMInputStream;

import gt.gone.model.product.productclient.ExtraClient;
import gt.gone.model.product.productindustry.ExtraIndustry;
import gt.gone.model.product.productmarket.ExtraMarket;
import gt.gone.model.product.producttype.ProductType;
import gt.gone.model.product.technology.Technology;
import gt.gone.util.FileUtil;
import gt.gone.util.JsonTool;
import gt.gone.util.MongoDBUtil;
import gt.gone.util.PreProcess;
import gt.gone.util.PropertyUtil;
import gt.gone.util.Word2VEC;
import gt.gone.util.WordTree;
import gt.gone.util.WordTreeCase;
import gt.gone.util.XmlUtil;
import net.sf.json.JSONObject;

public class ProductExtract {

	public static WordTree industryWordTree = WordTreeCase.getIndustryWordTree();
	public static WordTree locationWordTree = MongoDBUtil.getLocationFromMongoDB();
	public static WordTree scaleWordTree = WordTreeCase.getClientScaleWordTree();
	public static WordTree clientGrowWordTree = WordTreeCase.getClientGrowWordTree();
	public static WordTree steadyFeaturesWordTree = WordTreeCase.getSteadyClientFeaturesWordTree();
	public static WordTree loyalFeaturesWordTree = WordTreeCase.getLoyalClientFeaturesWordTree();
	public static WordTree highQualityFeaturesWordTree = WordTreeCase.getHighQualityClientFeaturesWordTree();
	public static WordTree variousFeaturesWordTree = WordTreeCase.getVariousClientFeaturesWordTree();
	//public static String word2VecPath = "C:\\Users\\nlp\\workspace1\\extractCashFlow3\\src\\main\\resources\\vector.mod";
	public static String word2VecPath = PropertyUtil.getValue("word2VecPath");
	public static Word2VEC w1 = new Word2VEC(word2VecPath);
	public static WordTree potentialWordTree = WordTreeCase.getPotentialWordTree();
	public static WordTree growWordTree = WordTreeCase.getMarketGrowWordTree();
	public static HashMap<String, String> industryHashMap = MongoDBUtil.getIndustryHashMapFromMongoDB();
	public static XmlUtil productTypeXml = new XmlUtil("product","producttype","product.xml");
	public static XmlUtil techXml = new XmlUtil("product","technology","technology.xml");
	
	public String extractProduct(String input) throws Exception {

		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		ProductType productType = new ProductType(input, productTypeXml);
		Technology technology = new Technology(input, techXml);
		result.put("inputSentence", input);
		input = PreProcess.preProcess(input);
		result.put("productType", productType.getResultList());
		result.put("productTechnology", technology.getResultList());

		if (input.toLowerCase().contains("industry") || input.toLowerCase().contains("industries")
				|| input.toLowerCase().contains("industrial") || input.toLowerCase().contains("use")
				|| input.toLowerCase().contains("used") || input.toLowerCase().contains("company")
				|| input.toLowerCase().contains("companys"))
			result.put("productIndusty", ExtraIndustry.extractIndustry(input, industryWordTree, industryHashMap));
		else
			result.put("productIndusty", new HashMap());

		if (input.toLowerCase().contains("market") || input.toLowerCase().contains("markets")
				|| input.toLowerCase().contains("marketing"))
			result.put("productMarket",
					ExtraMarket.extractMarket(input, locationWordTree, growWordTree, potentialWordTree));
		else
			result.put("productMarket", new HashMap());

		if (input.toLowerCase().contains("client") || input.toLowerCase().contains("clients")
				|| input.toLowerCase().contains("clientele") || input.toLowerCase().contains("clienteles")
				|| input.toLowerCase().contains("customer") || input.toLowerCase().contains("customers"))
			result.put("productClient",
					ExtraClient.extractClient(input, locationWordTree, scaleWordTree, clientGrowWordTree,
							steadyFeaturesWordTree, loyalFeaturesWordTree, highQualityFeaturesWordTree,
							variousFeaturesWordTree));
		else
			result.put("productClient", new HashMap());

		return JSONObject.fromObject(result).toString();
	}

	public static void main(String[] args) throws Exception {

		PrintStream ps;
		try {
			//ps = new PrintStream(new FileOutputStream("C:\\extractProductMongo10.txt"));
			ps = new PrintStream(new FileOutputStream(PropertyUtil.getValue("product.output")));
			//System.setOut(ps); 
			String fileTest = "D:\\Codes\\javacode\\extractCashFlow3\\src\\main\\resources\\test2.txt";
			//String fileTest2 = "C:\\Users\\nlp\\workspace1\\extractCashFlow3\\src\\main\\resources\\seller_4w.txt";
			String fileTest3 = "D:\\cashFlow.txt";
			String fileTest2 = PropertyUtil.getValue("product.input");
			// String wrongWordTest =
			// "E:\\workspace\\extractCashFlow3\\src\\main\\resources\\wrongSentence.txt";
			ProductExtract proe = new ProductExtract();
			String line = null;
			  //  int n = 3;//从第三行开始读取
			    try {
			    	//FileInputStream fileInputStream  = new FileInputStream(filePath);
			    	//InputStreamReader isr = new InputStreamReader(fileInputStream, "UTF-8");
			    	// ClassLoader classLoader = XmlUtil.class.getClassLoader();
			    	// FileInputStream fis = (FileInputStream) classLoader.getResourceAsStream(filePath); 
			    	 
			    	FileInputStream fis = new FileInputStream(fileTest2);
		        	   //可检测多种类型，并剔除bom
		        	BOMInputStream bomIn = new BOMInputStream(fis, false,ByteOrderMark.UTF_8, ByteOrderMark.UTF_16LE, ByteOrderMark.UTF_16BE);
		        	String charset = "utf-8";
		        	   //若检测到bom，则使用bom对应的编码
		        	if(bomIn.hasBOM()){
		        		charset = bomIn.getBOMCharsetName();
		        	 }
		        	BufferedReader br = new BufferedReader(new InputStreamReader(bomIn, charset));
					//br = new BufferedReader(new InputStreamReader(new FileInputStream(filePath), "UTF-8"));
		        	 int i=0;
					 while ((line = br.readLine()) != null) {
						
						 String ans = proe.extractProduct(line);
						 i++;
						
							//JsonFormatTool jst = new JsonFormatTool();
							System.out.println(JsonTool.formatJson(ans, "\t"));
							System.out.println();
							System.out.println();
							if(i == 100){
								break;
							}
						}
					 br.close();
					 
				} catch (FileNotFoundException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}

			/*for (int i = 1; i < 116; i++) {

				// String input =
				// PreProcess.preProcess(FileUtil.importData(fileTest2, i));
				String input = FileUtil.importData(fileTest2, i);
				if (input != null) {
					String ans = proe.extractProduct(input);
					// JsonFormatTool jst = new JsonFormatTool();
					System.out.println(JsonTool.formatJson(ans, "\t"));
					System.out.println();
					System.out.println();
				}

			}
*/
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}

}
