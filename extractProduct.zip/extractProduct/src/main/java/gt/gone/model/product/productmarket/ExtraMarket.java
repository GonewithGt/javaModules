package gt.gone.model.product.productmarket;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.print.attribute.Size2DSyntax;

import org.apache.commons.io.ByteOrderMark;
import org.apache.commons.io.input.BOMInputStream;

import gt.gone.util.FileUtil;
import gt.gone.util.JsonTool;
import gt.gone.util.MongoDBUtil;
import gt.gone.util.PropertyUtil;
import gt.gone.util.WordTree;
import gt.gone.util.WordTreeCase;
import net.sf.json.JSONObject;

public class ExtraMarket {

	public static String preProcess(String str) {
		return str.replaceAll("\\?|!", " .").replace(",", " ,")
				.replace("\"", " \"").replace("\\", " \\").replace("/", " /")
				.replace(".", " .");
	}

	// 计算结果出现的次数
	public static int count(String text, String sub) {
		int count = 0;
		int start = 0;
		while (((start = text.indexOf(sub, start))) >= 0) {
			start += sub.length();
			count++;
		}
		return count;
	}

	public static LinkedHashMap<String, Object> extractMarket(String oldInput,
			WordTree locationWordTree, WordTree growWordTree,
			WordTree potentialWordTree) throws Exception {
		LinkedHashMap<String, Object> resultMap = new LinkedHashMap<String, Object>(); // 抽取的信息
//		List locationList = new LinkedList<String>();
		Set locationSet = new LinkedHashSet<>();
		List growList = new LinkedList<String>();
		List potentialList = new LinkedList<String>();

		// 地理位置的set
		Set newSet = new LinkedHashSet<>();

		// 数据的统一预处理
		String input = preProcess(oldInput);
		if (input != null) {

			// 一段文本进行分句
			String[] markets = input.split("\\.");
			for (String market : markets) {

				// 句号分割的是否含有种子词
				if (market.toLowerCase().contains("market")
						|| market.toLowerCase().contains("markets")
						|| market.toLowerCase().contains("marketing")) {

					// 抽取地理位置(市场)

					/*
					 * 之前是正则跟词匹配两个的结果合并 String[] marketLocationReg = {
					 * "(southern)?\\s(state|Asian|European|the USA|Australia)"
					 * ,"(domestic|International)\\s(market)?" };
					 * ArrayList<String> extractedStringList0 =
					 * (ArrayList<String>) MongoDBUtil.extractByReg(input,
					 * marketLocationReg);
					 * 
					 * ArrayList<String> extractedStringList1 =
					 * (ArrayList<String>) MongoDBUtil.extract(market,
					 * locationWordTree);
					 * extractedStringList1.addAll(extractedStringList0);
					 */

					// 现在用正则匹配， 匹配到的在词库里面匹配
					// 语料将所有的标点处理成空格+标点
					String[] marketLocationReg = {
							"(market|markets|marketing)(\\s)*(including|such as|like)((\\s)*(\\b\\w*\\s+){0,3},)*(\\s)*(\\b\\w*\\s+){0,3}(\\s)*(and)?(\\s)*(\\b\\w*\\s+){0,3}",
							"(in|the)?(\\s)*(\\b\\w*\\s+){0,3}(\\s)*(marketing|markets|market|products|product)(\\s)*(\\b\\w*\\s+){0,1}?(\\s)*(within\\s|in\\s)?(the\\s)?(\\b\\w*\\s+){0,3}" };
					// 通过规则抽取的list
					ArrayList<String> extractedStringList0 = (ArrayList<String>) MongoDBUtil
							.extractByReg(market, marketLocationReg);
					System.out.println("extractedStringList0:"
							+ extractedStringList0);
					// 对规则抽取的list进行拼接
					StringBuilder match = new StringBuilder();
					int size = extractedStringList0.size();
					if (size > 0) {
						for (String location : extractedStringList0) {
							// size--;
							match.append(location);
							// if (size != 0)
							match.append(" ");
						}

						// 将拼接后的字符串与词库匹配
						ArrayList<String> extractedStringList1 = (ArrayList<String>) MongoDBUtil
								.extract(match.toString(), locationWordTree);
						System.out.println("extractedStringList1:"
								+ extractedStringList1);
						// 如果没有匹配上
						if (extractedStringList1.size() != 0) {

							for (String str : extractedStringList1) {
								// 后期用正则匹配，将匹配到的结果加上固定的搭配与原句比较
								String reg = "(Southeast|south|southern)\\s"
										+ str;
								Pattern pattern = Pattern.compile(reg);
								Matcher matcher = pattern.matcher(market);
								int count = 0;
								while (matcher.find()) {
									count++;
									locationSet.add(matcher.group());
								}
								if (count == 0)
									locationSet.add(str);

							}

						}

						// 去重
						StringBuilder locationString = new StringBuilder();
						for (Object setObject : locationSet) {
							locationString.append(setObject.toString());
							locationString.append(" ");
						}

						for (Object setObject : locationSet) {
							if (count(locationString.toString(),
									setObject.toString()) == 1) {
								newSet.add(setObject);
							}
						}

					}

					// 抽取增长(市场)
					ArrayList<String> extractedGrowStringList = (ArrayList<String>) MongoDBUtil
							.extract(market, growWordTree);
					if (extractedGrowStringList.size() == 0){
						//growList.add("");
					}
						
					else {
						for (String str : extractedGrowStringList) {
							growList.add(str);
						}
					}

					// 抽取潜力(市场)
					ArrayList<String> extractedPotentialList = (ArrayList<String>) MongoDBUtil
							.extract(market, potentialWordTree);
					if (extractedPotentialList.size() == 0){
					//	potentialList.add("");
					}
						
					else {
						for (String str : extractedPotentialList) {
							potentialList.add(str);
						}
					}

				}
			}
			resultMap.put("grow", growList);
			resultMap.put("location", newSet);
			resultMap.put("potential", potentialList);
		}
		return resultMap;
	}

	public static void main(String[] args) throws Exception {
		//PrintStream ps = new PrintStream(new FileOutputStream(
		//		"C:\\extractMarket.txt"));
		PrintStream ps = new PrintStream(new FileOutputStream(PropertyUtil.getValue("product.market.output")));
		System.setOut(ps);
		//String fileTest = "C:\\Users\\nlp\\workspace1\\extractCashFlow3\\src\\main\\resources\\market.txt";
		String fileTest = PropertyUtil.getValue("product.market.input");
		Map<String, String> map = new HashMap<String, String>();
		WordTree locationWordTree = MongoDBUtil.getLocationFromMongoDB();
		WordTree growWordTree = WordTreeCase.getMarketGrowWordTree();
		WordTree potentialWordTree = WordTreeCase.getPotentialWordTree();
		ExtraMarket extraMarket = new ExtraMarket();
		String line = null;
		try {
			// FileInputStream fileInputStream = new FileInputStream(filePath);
			// InputStreamReader isr = new InputStreamReader(fileInputStream,
			// "UTF-8");
			// ClassLoader classLoader = XmlUtil.class.getClassLoader();
			// FileInputStream fis = (FileInputStream)
			// classLoader.getResourceAsStream(filePath);

			FileInputStream fis = new FileInputStream(fileTest);
			// 可检测多种类型，并剔除bom
			BOMInputStream bomIn = new BOMInputStream(fis, false,
					ByteOrderMark.UTF_8, ByteOrderMark.UTF_16LE,
					ByteOrderMark.UTF_16BE);
			String charset = "utf-8";
			// 若检测到bom，则使用bom对应的编码
			if (bomIn.hasBOM()) {
				charset = bomIn.getBOMCharsetName();
			}
			BufferedReader br = new BufferedReader(new InputStreamReader(bomIn,
					charset));
			// br = new BufferedReader(new InputStreamReader(new
			// FileInputStream(filePath), "UTF-8"));

			while ((line = br.readLine()) != null) {
				System.out.println(line);
				String ans = JSONObject.fromObject(
						extraMarket.extractMarket(line, locationWordTree,
								growWordTree, potentialWordTree)).toString();

				System.out.println(JsonTool.formatJson(ans, "\t"));
				System.out.println();
				System.out.println();
			}
			br.close();

		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// for (int i = 1; i < 23; i++) {
		// String input = FileUtil.importData(fileTest, i);
		// System.out.println(input);
		// System.out.println(JsonTool.formatJson(
		// JSONObject.fromObject(
		// extractMarket(input, locationWordTree,
		// growWordTree, potentialWordTree))
		// .toString(), "\t")
		//
		// );
		// System.out.println();
		// }
	}

}
