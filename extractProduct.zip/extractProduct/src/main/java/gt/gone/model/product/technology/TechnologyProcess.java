package gt.gone.model.product.technology;

import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

public class TechnologyProcess {
	public LinkedHashMap<String, Object> commonProcess(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		String[] tokens = matchedString.split("\\s");
		ArrayList<String> special = new ArrayList<String>();
		ArrayList<String> leading = new ArrayList<String>();
		ArrayList<String> first = new ArrayList<String>();
		String techStr = null;
		result.put("special", null);
		result.put("leading", null);
		result.put("latest", null);
		for(String token : tokens){
			token = token.trim();
			if(token.contains("特殊的")){
				
				special.add((String) keyToInfo.get(token));
				matchedString = matchedString.replace(token, "");
			}else if(token.contains("领先的")){
				
				leading.add((String) keyToInfo.get(token.trim()));
				matchedString = matchedString.replace(token, "");
			}else if(token.contains("创新的")){
				first.add((String) keyToInfo.get(token.trim()));
				matchedString = matchedString.replace(token, "");
			}else if(token.contains("技术")&& keyToInfo.containsKey(token.trim())){
				techStr = keyToInfo.get(token.trim()).toString().trim();
				matchedString = matchedString.replace(token, techStr);
			}else if(token.contains("be动词")){
				matchedString = matchedString.replace(token, "");
			}else if(token.contains("介词")){
				matchedString = matchedString.replace(token, "");
			}else if(token.contains("指代词")){
				matchedString = matchedString.replace(token, "");
			}else if(token.contains("动词")){
				matchedString = matchedString.replace(token, "");
			}else if(token.contains("行为名词")){
				matchedString = matchedString.replace(token, "");
			}
		}
		
		if(matchedString.trim().startsWith("and ")){
			matchedString = matchedString.substring("and ".length());
		}
		if (matchedString.trim().startsWith(" and")) {
			matchedString = matchedString.substring(0, matchedString.length()-"and ".length());
		}
		result.put("special", special);
		result.put("leading", leading);
		result.put("latest", first);
		if(techStr.equals(matchedString.trim())){
			result.put("technology", null);
		}else {
			
			result.put("technology", (" "+matchedString+" ").replaceAll(" (T|t)he | (a|A) | (a|A)n |\\s\\.","").trim());
		}
		
		return result;
	}
	
	public Map<String, Object> rule1(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		result = commonProcess(matchedString, keyToInfo);
		return result;
	}
	
	public Map<String, Object> rule2(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		String[] tokens = matchedString.split("\\s");
		ArrayList<String> special = new ArrayList<String>();
		ArrayList<String> leading = new ArrayList<String>();
		ArrayList<String> first = new ArrayList<String>();
		String techStr = null;
		result.put("special", null);
		result.put("leading", null);
		result.put("latest", null);
		for(String token : tokens){
			token = token.trim();
			if(token.contains("特殊的")){
				
				special.add((String) keyToInfo.get(token));
				matchedString = matchedString.replace(token, "");
			}else if(token.contains("领先的")){
				
				leading.add((String) keyToInfo.get(token.trim()));
				matchedString = matchedString.replace(token, "");
			}else if(token.contains("创新的")){
				first.add((String) keyToInfo.get(token.trim()));
				matchedString = matchedString.replace(token, "");
			}else if(token.contains("技术")&& keyToInfo.containsKey(token.trim())){
				techStr = keyToInfo.get(token.trim()).toString().trim();
				matchedString = matchedString.replace(token, techStr);
			}else if(token.contains("be动词")){
				matchedString = matchedString.replace(token, "");
			}else if(token.contains("介词")){
				matchedString = matchedString.replace(token, (String) keyToInfo.get(token));
			}else if(token.contains("指代词")){
				matchedString = matchedString.replace(token, "");
			}else if(token.contains("动词")){
				matchedString = matchedString.replace(token, "");
			}else if(token.contains("行为名词")){
				matchedString = matchedString.replace(token, "");
			}
		}
		result.put("special", special);
		result.put("leading", leading);
		result.put("latest", first);
		if(techStr.equals(matchedString.trim())){
			result.put("technology", null);
		}else {
			
			result.put("technology", (" "+matchedString+" ").replaceAll(" (T|t)he | (a|A) | (a|A)n |\\s\\.","").trim());
		}
		
		return result;
	}
	
	public Map<String, Object> rule3(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		result = commonProcess(matchedString, keyToInfo);
		return result;
	}
	
	public Map<String, Object> rule4(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		result = commonProcess(matchedString, keyToInfo);
		return result;
	}
	
	public Map<String, Object> rule5(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		result = commonProcess(matchedString, keyToInfo);
		return result;
	}
	
	public Map<String, Object> rule6(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		result = commonProcess(matchedString, keyToInfo);
		String techStr = (String)result.get("technology");
		if(techStr != null &&! techStr.contains("technology of")){
			result.put("technology", null);
		}
		
		return result;
	}
	
	public Map<String, Object> rule7(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		result = commonProcess(matchedString, keyToInfo);
		String[] tokens = matchedString.split("\\s");
		String beVerb = "";
		
		if(matchedString.contains("#be动词")){
			result.put("technology", matchedString.substring(0, matchedString.indexOf("#be")).trim());
		}
		return result;
	}
	
	public Map<String, Object> rule8(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		result = commonProcess(matchedString, keyToInfo);
		result.put("technology", null);
		return result;
	}
	
	public Map<String, Object> rule9(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		result = commonProcess(matchedString, keyToInfo);
		return result;
	}
	
	public Map<String, Object> rule10(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		/*LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		result = commonProcess(matchedString, keyToInfo);
		return result;*/
		
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		String[] tokens = matchedString.split("\\s");
		ArrayList<String> special = new ArrayList<String>();
		ArrayList<String> leading = new ArrayList<String>();
		ArrayList<String> first = new ArrayList<String>();
		String techStr = null;
		result.put("special", null);
		result.put("leading", null);
		result.put("latest", null);
		for(String token : tokens){
			token = token.trim();
			if(token.contains("特殊的")){
				
				special.add((String) keyToInfo.get(token));
				matchedString = matchedString.replace(token, "");
			}else if(token.contains("领先的")){
				
				leading.add((String) keyToInfo.get(token.trim()));
				matchedString = matchedString.replace(token, "");
			}else if(token.contains("创新的")){
				first.add((String) keyToInfo.get(token.trim()));
				matchedString = matchedString.replace(token, "");
			}else if(token.contains("技术")&& keyToInfo.containsKey(token.trim())){
				techStr = keyToInfo.get(token.trim()).toString().trim();
				matchedString = matchedString.replace(token, techStr);
			}else if(token.contains("be动词")){
				matchedString = matchedString.replace(token, "");
			}else if(token.contains("介词")){
				matchedString = matchedString.replace(token, "");
			}else if(token.contains("指代词")){
				matchedString = matchedString.replace(token, "");
			}else if(token.contains("动词")){
				matchedString = matchedString.replace(token, "");
			}else if(token.contains("行为名词")){
				techStr = keyToInfo.get(token.trim()).toString().trim();
				matchedString = matchedString.replace(token, techStr);
			}
		}
		result.put("special", special);
		result.put("leading", leading);
		result.put("latest", first);
		if(techStr.equals(matchedString.trim())){
			result.put("technology", null);
		}else {
			
			result.put("technology", (" "+matchedString+" ").replaceAll(" (T|t)he | (a|A) | (a|A)n |\\s\\.","").trim());
		}
		
		return result;
	}
	
	public Map<String, Object> rule11(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		String[] tokens = matchedString.split("\\s");
		ArrayList<String> special = new ArrayList<String>();
		ArrayList<String> leading = new ArrayList<String>();
		ArrayList<String> first = new ArrayList<String>();
		String techStr = null;
		result.put("special", null);
		result.put("leading", null);
		result.put("latest", null);
		for(String token : tokens){
			token = token.trim();
			if(token.contains("特殊的")){
				
				special.add((String) keyToInfo.get(token));
				matchedString = matchedString.replace(token, "");
			}else if(token.contains("领先的")){
				
				leading.add((String) keyToInfo.get(token.trim()));
				matchedString = matchedString.replace(token, "");
			}else if(token.contains("创新的")){
				first.add((String) keyToInfo.get(token.trim()));
				matchedString = matchedString.replace(token, "");
			}else if(token.contains("技术")&& keyToInfo.containsKey(token.trim())){
				techStr = keyToInfo.get(token.trim()).toString().trim();
				matchedString = matchedString.replace(token, techStr);
		
			}else if(token.contains("be动词")){
				matchedString = matchedString.replace(token, "");
			}else if(token.contains("介词")){
				matchedString = matchedString.replace(token, "");
			}else if(token.contains("指代词")){
				matchedString = matchedString.replace(token, "");
			}else if(token.contains("动词")){
				matchedString = matchedString.replace(token, "");
			}else if(token.contains("行为名词")){
				matchedString = matchedString.replace(token, "");
			}
		}
		result.put("special", special);
		result.put("leading", leading);
		result.put("latest", first);
		//这条规则中不存在the technology的表达
		if(techStr.equals(matchedString.trim())||techStr.contains("the")){
			result.put("technology", null);
		}else {
			
			result.put("technology", (" "+matchedString+" ").replaceAll(" (T|t)he | (a|A) | (a|A)n |\\s\\.","").trim());
		}
		
		return result;
	}
	
	public Map<String, Object> rule12(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		result = commonProcess(matchedString, keyToInfo);
		String[] tokens = matchedString.split("\\s");
		String beVerb = "";
		
		/*if(matchedString.contains("#be动词")){
			result.put("technology", matchedString.substring(0, matchedString.indexOf("#be")).trim());
		}*/
		return result;
	}
	
	public Map<String, Object> rule13(String matchedString,LinkedHashMap<String, Object> keyToInfo){
		LinkedHashMap<String, Object> result = new LinkedHashMap<String, Object>();
		result = commonProcess(matchedString, keyToInfo);
		String techStr = (String)result.get("technology");
		if(techStr.contains(":")&& !techStr.endsWith(":")){
			result.put("technology", techStr.substring(matchedString.indexOf(":")+1).trim());
		}
		return result;
	}
}
