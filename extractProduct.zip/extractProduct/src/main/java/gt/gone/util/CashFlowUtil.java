package gt.gone.util;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class CashFlowUtil {
	
	public static String getCashFlowStr(String oldStr,PatternUtil pu, XmlUtil xml){
		String cashflow = "现金流";
		String regex = pu.templateToRegex(cashflow,xml.conceptMap).getReg()/*+"|"+pu.templateToRegex("现金流",xml.conceptMap).getReg()*/; //+"|"+ moneyTypeKeyWord;
		//System.out.println(regex);
		Pattern pattern = Pattern.compile(regex.toLowerCase());
		Matcher matcher = pattern.matcher(oldStr.toLowerCase());
		if(matcher.find()){
			return oldStr.substring(matcher.start(),matcher.end());
		}
		
		return "";
	}
	
}
