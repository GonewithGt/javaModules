package gt.gone.util;

import java.util.HashMap;
import java.util.Vector;

public class WordTree {

	public static class Pair<T> {
		public T first;
		public T second;

		public Pair(T first, T second) {
			this.first = first;
			this.second = second;
		}
	}

	public static class WordTreeNode {
		private String word;
		private int depth;
		private boolean isWord;
		private WordTreeNode parent;
		private Vector<WordTreeNode> childs;

		public String getText() {
			return word;
		}

		public void setText(String word) {
			this.word = word;
		}

		public int getDepth() {
			return depth;
		}

		public void setDepth(int depth) {
			this.depth = depth;
		}

		public boolean isWord() {
			return isWord;
		}

		public void setWord(boolean isWord) {
			this.isWord = isWord;
		}

		public WordTreeNode getParent() {
			return parent;
		}

		public void setParent(WordTreeNode parent) {
			this.parent = parent;
		}

		public Vector<WordTreeNode> getChilds() {
			return childs;
		}

		public void setChilds(Vector<WordTreeNode> childs) {
			this.childs = childs;
		}

		public WordTreeNode() {
			word = null;
			depth = 0;
			parent = null;
			isWord = false;
			childs = null;
		}

		public WordTreeNode(String text) {
			this.word = text;
			depth = 0;
			childs = new Vector<WordTreeNode>();
		}

		public int hashCode() {
			if (word != null)
				return word.hashCode();
			return 0;
		}

		public boolean equals(Object other) {
			if (other instanceof WordTreeNode) {
				WordTreeNode o = (WordTreeNode) other;
				if (o.getText() == null || this.word == null)
					return false;
				return o.getText().equals(this.word);
			}
			return false;
		}
	}

	private HashMap<String, WordTreeNode> wordTree;

	public WordTree() {
		wordTree = new HashMap<String, WordTreeNode>();
	}

	public boolean addPhrase(String[] phrase) {
		if (phrase != null && phrase.length > 0) {
			WordTreeNode currentNode = null;
			for (int i = 0; i < phrase.length; i++) {
				if (i == 0) {
					currentNode = wordTree.get(phrase[i]);
					if (currentNode == null) {
						currentNode = new WordTreeNode(phrase[i]);
						currentNode.setDepth(1);
						wordTree.put(phrase[i], currentNode);
					}
				} else {
					WordTreeNode tempNode = new WordTreeNode(phrase[i]);
					int index = currentNode.getChilds().indexOf(tempNode);
					if (index == -1) {
						tempNode.setDepth(currentNode.getDepth() + 1);
						tempNode.setParent(currentNode);
						currentNode.getChilds().add(tempNode);
					}

					currentNode = tempNode;
				}
			}

			// 最后一个节点设置为词节点
			if (currentNode != null) {
				currentNode.setWord(true);
			}
		}
		return false;
	}

	public Vector<Pair<Integer>> findPhrase(String[] text) {
		Vector<Pair<Integer>> pos = new Vector<Pair<Integer>>();

		if (text != null && text.length > 0) {
			Vector<WordTreeNode> candidatePhrases = new Vector<WordTreeNode>();
			Vector<WordTreeNode> tempCandidatePhrases = new Vector<WordTreeNode>();

			for (int i = 0; i < text.length; i++) {
				WordTreeNode node = wordTree.get(text[i]);
				if (node != null) {
					if (node.getChilds().size() == 0) {
						pos.add(new Pair<Integer>(i - node.getDepth() + 1, i + 1));
					} else {
						tempCandidatePhrases.add(node);
					}
				}

				node = new WordTreeNode(text[i]);
				for (WordTreeNode n : candidatePhrases) {
					int index = n.getChilds().indexOf(node);
					if (index != -1) {
						node = n.getChilds().get(index);
						if (node.getChilds().size() == 0) {
							pos.add(new Pair<Integer>(i - node.getDepth() + 1, i + 1));
						} else {
							tempCandidatePhrases.add(node);
						}
					} else {
						// 获取短匹配的结果
						int backPos = i;
						node = n;
						while (node != null && backPos >= 0) {
							if (node.isWord()) {
								pos.add(new Pair<Integer>(backPos - node.getDepth(), i));
								break;
							}
							backPos--;
							node = node.getParent();
						}
					}
				}

				candidatePhrases.clear();
				candidatePhrases.addAll(tempCandidatePhrases);
				tempCandidatePhrases.clear();
			}
		}

		return pos;
	}

	public static void main(String[] args) {
		WordTree wordTree = new WordTree();
		wordTree.addPhrase("thank you".split("\\s"));
		wordTree.addPhrase("thanks you".split("\\s"));
		wordTree.addPhrase("thanks".split("\\s"));
		wordTree.addPhrase("ok fine".split("\\s"));
		wordTree.addPhrase("hello buddy".split("\\s"));
		wordTree.addPhrase("hi nice to meet you".split("\\s"));
		wordTree.addPhrase("hi how are you".split("\\s"));
		wordTree.addPhrase("all right".split("\\s"));

		String text = "At the age of 34, thank you , hi nice to meet you Uchitel became a household name thanks , but for all the wrong reasons. She and Woods were involved in a sex scandal that went on for a couple of months. Uchitel was also followed by the paparazzi wherever she went. Amid the controversy, Woods lost several endorsement deals and golf championships. His marriage to Nordegren was also dissolved, according to People.";
		Vector<WordTree.Pair<Integer>> pos = wordTree.findPhrase(text.split("\\s"));

		for (WordTree.Pair<Integer> pair : pos) {
			System.out.println(pair.first + ", " + pair.second);
		}
	}
}
