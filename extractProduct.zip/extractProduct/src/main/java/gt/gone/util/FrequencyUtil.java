package gt.gone.util;

public class FrequencyUtil {
	
	//抽取周期单位
	public static String extractFrequencyUnit(String oldChar) {
		// TODO Auto-generated method stub
		if (oldChar.toLowerCase().contains("year")||oldChar.toLowerCase().contains("annual")
				||oldChar.toLowerCase().contains("pa")
				||oldChar.toLowerCase().contains("annum")
				||oldChar.toLowerCase().contains("p.a.")) {
			return "YEAR";
		}
		if (oldChar.toLowerCase().contains("half a year")) {
			return "HALF A YEAR";
		}
		if (oldChar.toLowerCase().contains("quarter")) {
			return "QUARTER";
		}
		if (oldChar.toLowerCase().contains("month")) {
			return "MONTH";
		}
		if (oldChar.toLowerCase().contains("week")||oldChar.toLowerCase().contains("pw")
				||oldChar.toLowerCase().contains("p.w.")) {
			return "WEEK";
		}
		if (oldChar.toLowerCase().contains("day")) {
			return "DAY";
		}
		return null;
	}
	
	public static void main(String[] args){
		System.out.println("p.a.".contains("p.a."));
	}

}
