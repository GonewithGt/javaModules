package gt.gone.util;

import gt.gone.model.common.ExtractTarget;
import gt.gone.model.common.Intention;
import gt.gone.model.common.Regex;
import gt.gone.model.common.Template;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


public class PatternUtil {
		static String regEx = "[\u4e00-\u9fa5]";
		static Pattern pat = Pattern.compile(regEx);
		//
		private boolean isContainsChinese(String str)
		{
			Matcher matcher = pat.matcher(str);
			boolean flg = false;
			if (matcher.find()){
				flg = true;
			}
			return flg;
		}
		
		
		
		private String toRegex(List<String> keywords){
			String regex = "";
			for(String keyword : keywords){
				if(regex.equals("")){
					regex += keyword+"[\\s]*";
				}
				else{
					regex = regex + '|' + keyword+"[\\s]*";
				}
			}
			
			//regex = regex + ")[\\s]+";
			return regex;
		}
		
		//
		public String toRegex(List<String> keywords,LinkedHashMap<String, String> keyWordToRegexMap){
			String regex = "";
			for(String keyword: keywords){
				if(isContainsChinese(keyword)){
					String words[] = keyword.split("\\+ ");
					String s="";
					for(String word : words){
						if(isContainsChinese(word)){
							if(keyWordToRegexMap.containsKey(word))
							s = s + "("+keyWordToRegexMap.get(word).trim()+")";
							else{
								System.out.println("concept occur wrong key word");
								System.out.println("wrong string:"+ word);
								// Log.logError("concept occur wrong key word");
								// Log.logError("wrong string:"+ word);
							}
						}else{
							s = s + word.trim()+"[\\s]*";
						}
					}
					if(regex.equals("")){
						regex += s + "[\\s]*" ;
					}
					else {
						regex = regex + '|' + s +"[\\s]*" ;
					}
					
				}else{
					if(regex.equals("")){
						regex += keyword+"[\\s]*";
					}
					else {
						regex = regex + '|' + keyword+"[\\s]*";
					}
					//regex = regex + '|' +  ;
				}
			}
			
			return regex;
		}
		
		
		public LinkedHashMap<String ,String> toRegex(LinkedHashMap<String, List<String>> conceptMap){
			LinkedHashMap<String , String> keywordToRegexStringMap = new LinkedHashMap<String ,String>(); 
			String regex = "";
			for(String keyword: conceptMap.keySet()){
				List<String> words = conceptMap.get(keyword);
				boolean hasChinese = false;
				for(String word : words){
					if(isContainsChinese(word))
						hasChinese = true;
				}
				
				if(!hasChinese){
					String  s = toRegex(words);
					keywordToRegexStringMap.put(keyword, s);
				}else{
					String strConverted = toRegex(words,keywordToRegexStringMap);
					
					keywordToRegexStringMap.put(keyword, strConverted);
				}
				
			}		
			return keywordToRegexStringMap;
		}
		
		
		
		public Regex templateToRegex(String template, LinkedHashMap<String, List<String>> conceptMap){
			String reg = "";
			String temReg[] = template.split("\\+ ");
			LinkedHashMap<String , String> keywordToRegexStringMap = toRegex(conceptMap);
			List<ExtractTarget> extractTarget = new ArrayList<ExtractTarget >();
			//int k = 1;
			for(String s : temReg){
				if(s.charAt(0) != '#'){
					if(isContainsChinese(s)){
						if(keywordToRegexStringMap.containsKey(s)){
							reg = reg + "("+keywordToRegexStringMap.get(s)+")";
						}else{
							System.out.println("tmplate occur wrong keyword");
							System.out.println("wrong string:"+ s);
							//Log.logError("tmplate occur wrong keyword");
							//Log.logError("wrong string:"+ s);
						}
						
					}
					else {
						reg = reg + s +"[\\s]*"  ;
					}
				}
				else{
					String tems = s.substring(1);
					if(isContainsChinese(tems)){
						if(keywordToRegexStringMap.containsKey(tems)){
							String temp = keywordToRegexStringMap.get(tems);
							reg = reg + "(" + temp +")";
							extractTarget.add(new ExtractTarget(tems,temp));
						}else{
							System.out.println("mplate occur wrong keyword");
							System.out.println("wrong string:"+ s);
							//Log.logError("mplate occur wrong keyword");
							//Log.logError("wrong string:"+ s);
						}
					}
					else{
						reg = reg + tems +"[\\s]*"  ;
						extractTarget.add(new ExtractTarget(tems,tems));
					}
				}
			}
		
			Regex regex = new Regex(reg, extractTarget);
			return regex;
		}
		
		
		public static void main(String[] args) {
			// TODO Auto-generated method stub
			XmlUtil xml = new XmlUtil("profitability","cashflow","CashFlow.xml");
			PatternUtil pu = new PatternUtil();
			String s = "#预计类词语+ #修饰语+ ?+ 现金流+ to+ #百分比+ 时间+ ?";
			String line = "The projects are in 200, 500, & 1,000 units capacity & according to the company official the whole investment could be paid off in 2-4 years with 25% utilization, depending on the project capacity. Capacity of 200 units equals $46M-$57M in total revenue with an 18% profit margin of $8M-$10M. Required investment of $7M with working capital needed of $1.5M.";
			String regex = "(very|extremely|highly)? nice[\\s]*|(very|extremely|highly)? great[\\s]*\\d*(~|-)";
			String line2 = "THE BUSINESS:Central Business Brokers is beyond proud to bring to the market an exceptional acquisition opportunity: a wholesale, retailer and online distributor of niche homewares and furniture from Middle East and North Africa. I expected highly discounted cash flow to from 17.5% to 14.2%. Established in 2005. Only one working owner. Strong Profit Margins (75% Average). Excellent Strategic Market Position. Limited Competition. Little Marketing currently being undertaken. Multiple Revenue Streams. ";
			String line3 = "I expected highly discounted cash flow to from 17.5% to 14.2%.";
			Pattern r = Pattern.compile(pu.templateToRegex(s,xml.conceptMap).getReg());
			System.out.println(pu.templateToRegex(s,xml.conceptMap).getReg());
			Matcher m = r.matcher(line3);
			if(m.find()){
				System.out.println(m.group(0));
			}
			
			String regex2 = "from[\\s]*([0-9]?\\d*\\.?\\d*%[\\s]*)to[\\s]*([0-9]?\\d*\\.?\\d*%[\\s]*)[\\s]*";
			String regex3 = "positive[\\s]*to[\\s]*(from[\\s]*([0-9]?\\d*\\.?\\d*%[\\s]*)(over the past[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)years[\\s]*[\\s]*|over the last[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)years.[\\s]*[\\s]*|each year[\\s]*|by[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|Since[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|in the recent years[\\s]*|for[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|for .* year[\\s]*|over the last [\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)|[\\s]*([one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety|hundred|thousand|million|billion|-]*[\\s]*) years[\\s]*[\\s]*|in such for the last[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)year[\\s]*[\\s]*|for FY[\\s]*([0-9]|1[12][\\s]*)([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|before the end of[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|by the end of[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|in the next .* year[\\s]*|in past[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*) months|years[\\s]*[\\s]*|in[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|throughout the year[\\s]*|year-on-year[\\s]*|([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)—[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*)to[\\s]*([0-9]?\\d*\\.?\\d*%[\\s]*)(over the past[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)years[\\s]*[\\s]*|over the last[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)years.[\\s]*[\\s]*|each year[\\s]*|by[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|Since[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|in the recent years[\\s]*|for[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|for .* year[\\s]*|over the last [\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)|[\\s]*([one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety|hundred|thousand|million|billion|-]*[\\s]*) years[\\s]*[\\s]*|in such for the last[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)year[\\s]*[\\s]*|for FY[\\s]*([0-9]|1[12][\\s]*)([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|before the end of[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|by the end of[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|in the next .* year[\\s]*|in past[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*) months|years[\\s]*[\\s]*|in[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|throughout the year[\\s]*|year-on-year[\\s]*|([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)—[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*)[\\s]*|from[\\s]*([0-9]?\\d*\\.?\\d*%[\\s]*)to[\\s]*([0-9]?\\d*\\.?\\d*%[\\s]*)[\\s]*|(high[\\s]*|free[\\s]*|operating[\\s]*|huge[\\s]*|average weekly[\\s]*|average monthly[\\s]*|weekly[\\s]*|monthly[\\s]*|annual[\\s]*|average[\\s]*|average annual[\\s]*|excellent[\\s]*)([0-9]?\\d*\\.?\\d*%[\\s]*)[\\s]*|up to[\\s]*([0-9]?\\d*\\.?\\d*%[\\s]*)[\\s]*|(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just over[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)([0-9]?\\d*\\.?\\d*%[\\s]*)or between [\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)- [\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)%.[\\s]*[\\s]*|between [\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)% to [\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)%[\\s]*[\\s]*|(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just over[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)([0-9]?\\d*\\d*\\.?\\d*[\\s]*)percent[\\s]*[\\s]*|(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just over[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)([0-9]?\\d*\\.?\\d*%[\\s]*)[\\s]*|([0-9]?\\d*\\.?\\d*%[\\s]*)[\\s]*)";
			//String regex4 = "(expect[\s]*|expected[\s]*|forecast[\s]*|forecasted[\s]*|forecasting[\s]*|projected[\s]*|projected[\s]*|projecting[\s]*)((very|extremely|highly)? incredible[\s]*|(very|extremely|highly)? healthy[\s]*|(very|extremely|highly)? Attractive[\s]*|(very|extremely|highly)? amazing[\s]*|(very|extremely|highly)? nice[\s]*|(very|extremely|highly)? great[\s]*|(very|extremely|highly)? discounted[\s]*|(very|extremely|highly)? Considerable[\s]*|(very|extremely|highly)? highly stable[\s]*|(very|extremely|highly)? free[\s]*|(very|extremely|highly)? consistent[\s]*|(very|extremely)? high[\s]*|(very|extremely|highly)? good[\s]*|(very|extremely|highly)? excellent[\s]*|(very|extremely|highly)? healthy[\s]*|(very|extremely|highly)? normalized[\s]*|(very|extremely|highly)? normalized[\s]*|(very|extremely|highly)? outstanding[\s]*|(very|extremely|highly)? reliable[\s]*|(very|extremely|highly)? significant[\s]*|(very|extremely|highly)? significant[\s]*|(very|extremely|highly)? sizeable[\s]*|(very|extremely|highly)? sizeable[\s]*|(very|extremely|highly)? solid[\s]*|(very|extremely|highly)? stable[\s]*|(very|extremely|highly)? stable[\s]*|(very|extremely|highly)? steady[\s]*|(very|extremely|highly)? Strong[\s]*|(very|extremely|highly)? strong[\s]*|(very|extremely|highly)? Tremendous[\s]*|consistent[\s]*|Growing[\s]*|increased[\s]*|multiple of[\s]*|net[\s]*|operating[\s]*|organi[\s]*|outstanding[\s]*|positive[\s]*|potential[\s]*|proven track of[\s]*|recurring[\s]*|regular[\s]*|strong[\s]*|Sustainable[\s]*|year over year[\s]*|([0-9]?\d*\d*\.?\d*[\s]*)year track record of consistent[\s]*[\s]*)?[\d]*(Adjusted Cash Flow[\s]*|cash flow(s)?[\s]*|cash flow positive[\s]*|net cash flow[\s]*|Cash-flow positive[\s]*|cash-flow[\s]*|financial flow[\s]*|capital flow[\s]*|cash flow[\s]*|money flow[\s]*|cashflow(s)?[\s]*|SDE[\s]*)";
			String regex4 = "(expect[\\s]*|expected[\\s]*|forecast[\\s]*|forecasted[\\s]*|forecasting[\\s]*|projected[\\s]*|projected[\\s]*|projecting[\\s]*)((very|extremely|highly)? incredible[\\s]*|(very|extremely|highly)? healthy[\\s]*|(very|extremely|highly)? Attractive[\\s]*|(very|extremely|highly)? amazing[\\s]*|(very|extremely|highly)? nice[\\s]*|(very|extremely|highly)? great[\\s]*|(very|extremely|highly)? discounted[\\s]*|(very|extremely|highly)? Considerable[\\s]*|(very|extremely|highly)? highly stable[\\s]*|(very|extremely|highly)? free[\\s]*|(very|extremely|highly)? consistent[\\s]*|(very|extremely)? high[\\s]*|(very|extremely|highly)? good[\\s]*|(very|extremely|highly)? excellent[\\s]*|(very|extremely|highly)? healthy[\\s]*|(very|extremely|highly)? normalized[\\s]*|(very|extremely|highly)? normalized[\\s]*|(very|extremely|highly)? outstanding[\\s]*|(very|extremely|highly)? reliable[\\s]*|(very|extremely|highly)? significant[\\s]*|(very|extremely|highly)? significant[\\s]*|(very|extremely|highly)? sizeable[\\s]*|(very|extremely|highly)? sizeable[\\s]*|(very|extremely|highly)? solid[\\s]*|(very|extremely|highly)? stable[\\s]*|(very|extremely|highly)? stable[\\s]*|(very|extremely|highly)? steady[\\s]*|(very|extremely|highly)? Strong[\\s]*|(very|extremely|highly)? strong[\\s]*|(very|extremely|highly)? Tremendous[\\s]*|consistent[\\s]*|Growing[\\s]*|increased[\\s]*|multiple of[\\s]*|net[\\s]*|operating[\\s]*|organi[\\s]*|outstanding[\\s]*|positive[\\s]*|potential[\\s]*|proven track of[\\s]*|recurring[\\s]*|regular[\\s]*|strong[\\s]*|Sustainable[\\s]*|year over year[\\s]*|([0-9]?\\d*\\d*\\.?\\d*[\\s]*)year track record of consistent[\\s]*[\\s]*)?[\\d]*(Adjusted Cash Flow[\\s]*|cash flow(s)?[\\s]*|cash flow positive[\\s]*|net cash flow[\\s]*|Cash-flow positive[\\s]*|cash-flow[\\s]*|financial flow[\\s]*|capital flow[\\s]*|cash flow[\\s]*|money flow[\\s]*|cashflow(s)?[\\s]*|SDE[\\s]*)";
			String regex5 = "(from[\\s]*([0-9]?\\d*\\.?\\d*%[\\s]*)(over the past[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)years[\\s]*[\\s]*|over the last[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)years.[\\s]*[\\s]*|each year[\\s]*|by[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|Since[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|in the recent years[\\s]*|for[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|for .* year[\\s]*|over the last [\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)|[\\s]*([one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety|hundred|thousand|million|billion|-]*[\\s]*) years[\\s]*[\\s]*|in such for the last[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)year[\\s]*[\\s]*|for FY[\\s]*([0-9]|1[12][\\s]*)([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|before the end of[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|by the end of[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|in the next .* year[\\s]*|in past[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*) months|years[\\s]*[\\s]*|in[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|throughout the year[\\s]*|year-on-year[\\s]*|([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)—[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*)to[\\s]*([0-9]?\\d*\\.?\\d*%[\\s]*)(over the past[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)years[\\s]*[\\s]*|over the last[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)years.[\\s]*[\\s]*|each year[\\s]*|by[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|Since[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|in the recent years[\\s]*|for[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|for .* year[\\s]*|over the last [\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)|[\\s]*([one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety|hundred|thousand|million|billion|-]*[\\s]*) years[\\s]*[\\s]*|in such for the last[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)year[\\s]*[\\s]*|for FY[\\s]*([0-9]|1[12][\\s]*)([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|before the end of[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|by the end of[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|in the next .* year[\\s]*|in past[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*) months|years[\\s]*[\\s]*|in[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|throughout the year[\\s]*|year-on-year[\\s]*|([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)—[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*)[\\s]*|from[\\s]*([0-9]?\\d*\\.?\\d*%[\\s]*)to[\\s]*([0-9]?\\d*\\.?\\d*%[\\s]*)[\\s]*|(high[\\s]*|free[\\s]*|operating[\\s]*|huge[\\s]*|average weekly[\\s]*|average monthly[\\s]*|weekly[\\s]*|monthly[\\s]*|annual[\\s]*|average[\\s]*|average annual[\\s]*|excellent[\\s]*)([0-9]?\\d*\\.?\\d*%[\\s]*)[\\s]*|up to[\\s]*([0-9]?\\d*\\.?\\d*%[\\s]*)[\\s]*|(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just over[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)([0-9]?\\d*\\.?\\d*%[\\s]*)or between [\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)- [\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)%.[\\s]*[\\s]*|between [\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)% to [\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)%[\\s]*[\\s]*|(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just over[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)([0-9]?\\d*\\d*\\.?\\d*[\\s]*)percent[\\s]*[\\s]*|(above[\\s]*|over[\\s]*|about[\\s]*|around[\\s]*|more than[\\s]*|no less[\\s]*|no less than[\\s]*|no fewer than[\\s]*|nearly[\\s]*|in excess of[\\s]*|approaching[\\s]*|exceeded[\\s]*|circa[\\s]*|just over[\\s]*|at least[\\s]*|In The Vicinity Of[\\s]*|up to[\\s]*|approximately[\\s]*|[\\s]*|in the mid[\\s]*)([0-9]?\\d*\\.?\\d*%[\\s]*)[\\s]*|([0-9]?\\d*\\.?\\d*%[\\s]*)[\\s]*)(over the past[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)years[\\s]*[\\s]*|over the last[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)years.[\\s]*[\\s]*|each year[\\s]*|by[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|Since[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|in the recent years[\\s]*|for[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|for .* year[\\s]*|over the last [\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)|[\\s]*([one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|thirteen|fourteen|fifteen|sixteen|seventeen|eighteen|nineteen|twenty|thirty|forty|fifty|sixty|seventy|eighty|ninety|hundred|thousand|million|billion|-]*[\\s]*) years[\\s]*[\\s]*|in such for the last[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*)year[\\s]*[\\s]*|for FY[\\s]*([0-9]|1[12][\\s]*)([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|before the end of[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|by the end of[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|in the next .* year[\\s]*|in past[\\s]*([0-9]?\\d*\\d*\\.?\\d*[\\s]*) months|years[\\s]*[\\s]*|in[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|throughout the year[\\s]*|year-on-year[\\s]*|([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*|([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)—[\\s]*([0-2]?[0-9]?[0-9]?[0-9]?[\\s]*)[\\s]*)?[\\d]*";
			String regex6 = "cash flow positive|cash flow ";
			Pattern test= Pattern.compile(regex6);
			//System.out.println(pu.templateToRegex(s,xml.conceptMap).getReg());
			Matcher mtest = test.matcher(line3);
			if(mtest.find()){
				System.out.println(mtest.group(0));
			}
			
			//System.out.println(pu.templateToRegex(s, xml.conceptMap).getReg());
			//System.out.println(pu.templateToRegex(s, xml.conceptMap).getExtractTarget());

		/*	for(Intention intention :xml.intentionList){
				System.out.println(intention.getName());
				for(Template t : intention.getTemplates()){
					Log.logInfo(pu.templateToRegex(t.getTemplatetext(), xml.conceptMap).getReg());
					//Log.logInfo(pu.templateToRegex(t.getTemplatetext(), xml.conceptMap).getExtractTarget());
				}
				
			}
			*/
//			String t[] = s.split(regEx + "+");
//			int k = 0;
//			for(String ts:t){
//				k++;
//				System.out.println(ts);
//			}
//			System.out.println(k);
		}

}
