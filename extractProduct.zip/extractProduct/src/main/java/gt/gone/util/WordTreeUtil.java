package gt.gone.util;

public class WordTreeUtil {
	
	public static String preProcess(String str){
		
		str = str.replaceAll("\\.", " .").replaceAll(",", " ,").replaceAll("!", " !").replaceAll("\\?", " ?");
		
		return str;
	}

}
