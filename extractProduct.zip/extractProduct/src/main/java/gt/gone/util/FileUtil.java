package gt.gone.util;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;

import org.apache.commons.io.ByteOrderMark;
import org.apache.commons.io.input.BOMInputStream;

import com.mongodb.client.model.ReturnDocument;

public class FileUtil {

	public static ArrayList importData(String filePath) throws Exception {
		FileInputStream fis = new FileInputStream(filePath);
		// 可检测多种类型，并剔除bom
		BOMInputStream bomIn = new BOMInputStream(fis, false, ByteOrderMark.UTF_8, ByteOrderMark.UTF_16LE,
				ByteOrderMark.UTF_16BE);
		String charset = "utf-8";
		// 若检测到bom，则使用bom对应的编码
		if (bomIn.hasBOM()) {
			charset = bomIn.getBOMCharsetName();
		}
		BufferedReader br = new BufferedReader(new InputStreamReader(bomIn, charset));
		// br = new BufferedReader(new InputStreamReader(new
		// FileInputStream(filePath), "UTF-8"));
		String[] aStrings = null;
		ArrayList<String> arrayList = new ArrayList<>();
		String str = null;
		while((str=br.readLine())!=null){
//			aStrings = br.readLine().split("\n");
			arrayList.add(str);
		}
		br.close();
		return arrayList;

	}

	public static String importData(String filePath, int hangHao) {
		String line = null;
		// int n = 3;//从第三行开始读取
		try {
			// FileInputStream fileInputStream = new FileInputStream(filePath);
			// InputStreamReader isr = new InputStreamReader(fileInputStream,
			// "UTF-8");
			// ClassLoader classLoader = XmlUtil.class.getClassLoader();
			// FileInputStream fis = (FileInputStream)
			// classLoader.getResourceAsStream(filePath);

			FileInputStream fis = new FileInputStream(filePath);
			// 可检测多种类型，并剔除bom
			BOMInputStream bomIn = new BOMInputStream(fis, false, ByteOrderMark.UTF_8, ByteOrderMark.UTF_16LE,
					ByteOrderMark.UTF_16BE);
			String charset = "utf-8";
			// 若检测到bom，则使用bom对应的编码
			if (bomIn.hasBOM()) {
				charset = bomIn.getBOMCharsetName();
			}
			BufferedReader br = new BufferedReader(new InputStreamReader(bomIn, charset));
			// br = new BufferedReader(new InputStreamReader(new
			// FileInputStream(filePath), "UTF-8"));
			while (hangHao-- > 1) {
				br.readLine();
			}
			if ((line = br.readLine()) != null) {
				return line;
			} else {
				System.out.println("输入ID可能超出范围！");

			}
			br.close();

		} catch (FileNotFoundException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

		// br.close();
		return null;
	}
	
	public static BufferedReader quchuBom(String filePath){
		BufferedReader br = null ;
		 try {
			 FileInputStream fis = new FileInputStream(filePath);
	        	   //可检测多种类型，并剔除bom
			 BOMInputStream bomIn = new BOMInputStream(fis, false,ByteOrderMark.UTF_8, ByteOrderMark.UTF_16LE, ByteOrderMark.UTF_16BE);
			 String charset = "utf-8";
	        	   //若检测到bom，则使用bom对应的编码
	        if(bomIn.hasBOM()){
	        	charset = bomIn.getBOMCharsetName();
	        	}
	        	br = new BufferedReader(new InputStreamReader(bomIn, charset));
				return br;
					
				 
			} catch (FileNotFoundException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		 
		 return br;
		
	}
	
	


}
