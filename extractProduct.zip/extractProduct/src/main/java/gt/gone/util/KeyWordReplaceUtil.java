package gt.gone.util;

import java.awt.Point;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class KeyWordReplaceUtil {
	
	public static boolean isCorrectToken(String sentenceTmp, int start , int end, String keyTokenTmp, String oldChar){
		boolean flag = false;
		if(keyTokenTmp.contains("钱数")&&oldChar.endsWith(".")
				||keyTokenTmp.contains("时间")&&oldChar.endsWith(".")){
			oldChar=oldChar.substring(0,oldChar.length()-1);
			end = end-1;
		}
		//System.out.println(oldChar);
		//System.out.println("start==>"+start);
		//System.out.println(sentenceTmp.charAt(end));
		if(oldChar.startsWith(" ")){
			start = start+1;
		}
		
		if(oldChar.endsWith(" ")){
			end = end-1 ;
		}
		//if(sentence.contains(" "+oldChar.trim()+" ")){
		if(start>0 && end>0 && end < sentenceTmp.length() && sentenceTmp.charAt(start-1)==' ' && sentenceTmp.charAt(end)==' '){
		
			//sentence = sentence.replace(" "+oldChar.trim()+" " , " "+"#"+ keyTokenTmp +" ");
			flag = true;
		}else if((keyTokenTmp.contains("介词")||
				keyTokenTmp.contains("动词")||
				keyTokenTmp.contains("冠词")) && start!=0 && end != sentenceTmp.length()
				){ //这些词比较短，可能会作为其它词的一部分，不能直接这样替代
			return false;
		}else
//		if(sentence.contains(oldChar.trim()+" ")){
		if( end > 0 && end < sentenceTmp.length() && sentenceTmp.charAt(end)==' '){

			if(start==0 ||start>0&& sentenceTmp.charAt(start-1)=='.'
					||sentenceTmp.charAt(start-1)=='('
					||sentenceTmp.charAt(start-1)==')'
					||sentenceTmp.charAt(start-1)==','
					||sentenceTmp.charAt(start-1)=='\"'
					||sentenceTmp.charAt(start-1)==':'
					||sentenceTmp.charAt(start-1)=='/'
					||sentenceTmp.charAt(start-1)=='!'
					||sentenceTmp.charAt(start-1)=='n'
					||sentenceTmp.charAt(start-1)=='>'
					||sentenceTmp.charAt(start-1)=='<'
					||sentenceTmp.charAt(start-1)=='•'
					||sentenceTmp.charAt(start-1)=='+'
					||sentenceTmp.charAt(start-1)=='-'
					||Character.isDigit(sentenceTmp.charAt(start-1))
					||Character.isUpperCase(sentenceTmp.charAt(start))&&!Character.isUpperCase(sentenceTmp.charAt(start-1))
				//	||keyTokenTmp.contains("钱数")
					||keyTokenTmp.contains("百分比")){
			//	System.out.println(oldChar+" " +keyTokenTmp+" "+  "space at end");
				flag = true;
			//	sentence = sentence.replace(oldChar.trim()+" " , " "+"#"+ keyTokenTmp +" ");
			}				
		}else
	//	if(sentence.contains(" "+oldChar.trim())){
		if(start>0 && sentenceTmp.charAt(start-1)==' ' ){

			//System.out.println(" "+oldChar.trim() );
			//System.out.println(start);
			//System.out.println(end);
			//System.out.println(sentenceTmp.charAt(end));
			//System.out.println(sentenceTmp.length());
			if(end ==sentenceTmp.length()
					||end>0 && end < sentenceTmp.length() 
					&& (sentenceTmp.charAt(end)=='.'
					||sentenceTmp.charAt(end)==')'
					||sentenceTmp.charAt(end)=='-'
					||sentenceTmp.charAt(end)==','
					||sentenceTmp.charAt(end)=='\"'
					||sentenceTmp.charAt(end)=='/'
					||sentenceTmp.charAt(end)=='('						
					||sentenceTmp.charAt(end)==':'
					||sentenceTmp.charAt(end)=='!'
					||sentenceTmp.charAt(end)==';'
					||sentenceTmp.charAt(end)=='\\'
					||sentenceTmp.charAt(end)=='\''
					||sentenceTmp.charAt(end)=='>'
					||sentenceTmp.charAt(end)=='<'
					||sentenceTmp.charAt(end)=='•'
					||sentenceTmp.charAt(end-1)=='+'
					||Character.isDigit(sentenceTmp.charAt(end-1))
				    ||Character.isUpperCase(sentenceTmp.charAt(end))&& !Character.isUpperCase(sentenceTmp.charAt(end-1))					    
				//	||keyTokenTmp.contains("钱数")
					||keyTokenTmp.contains("百分比")
				)
					){
				
				//System.out.println(oldChar+" "+keyTokenTmp+" "+  "space at start");
				flag = true;
			//	sentence = sentence.replace(" "+oldChar.trim(), " "+"#"+ keyTokenTmp +" ");
			}
		}else if(sentenceTmp.contains(oldChar.trim())){
			if(start==0 && end==sentenceTmp.length() 
					/*||sentenceTmp.contains(oldChar.trim()+",")
					||sentenceTmp.contains(oldChar.trim()+"\"")
					||sentenceTmp.contains("\""+oldChar.trim())
					||sentenceTmp.contains("“"+oldChar.trim())
					||sentenceTmp.contains("("+oldChar.trim())
					||sentenceTmp.contains(oldChar.trim()+")")
					||sentenceTmp.contains(oldChar.trim()+":")
					||sentenceTmp.contains(oldChar.trim()+"!")
					||sentenceTmp.contains(oldChar.trim()+"2")
					||sentenceTmp.contains(oldChar.trim()+";")
					||sentenceTmp.contains(oldChar.trim()+"'")
					||sentenceTmp.contains("•"+oldChar.trim())
					||sentenceTmp.contains("\\n"+oldChar.trim())*/
					||
					start>=0 && end>0 && end < sentenceTmp.length() 
					&&(sentenceTmp.charAt(end)==',' && (start >0 &&!Character.isLetter(sentenceTmp.charAt(start-1))||start ==0)
					||sentenceTmp.charAt(end)=='\"'
					||start>0 && sentenceTmp.charAt(start-1)=='\"'
					||start>0 && sentenceTmp.charAt(start-1)=='“'
					||start>0 && sentenceTmp.charAt(start-1)=='('
					||sentenceTmp.charAt(end)==')'
					||sentenceTmp.charAt(end)==':'
					||sentenceTmp.charAt(end)=='!'
					||sentenceTmp.charAt(end)=='.'
					||sentenceTmp.charAt(end)=='2'						
					||sentenceTmp.charAt(end)==':'
					||sentenceTmp.charAt(end)==';'&& (start >0 &&!Character.isLetter(sentenceTmp.charAt(start-1))||start ==0)
					||sentenceTmp.charAt(end)=='\''
					||start>0 && sentenceTmp.charAt(start-1)=='•'
					||start>0 && sentenceTmp.charAt(start-1)=='\n'
					//||keyTokenTmp.contains("钱数")
					||keyTokenTmp.contains("百分比"))){
				flag = true;
				//System.out.println(oldChar+" "+ keyTokenTmp + "have no space");
				//sentence = sentence.replace(oldChar.trim(), " "+"#"+ keyTokenTmp +" ");
			}
		}
		
		
		//System.out.println("flag==>"+flag);
		return flag;
	}
	
	public static LinkedHashMap<Point , Object> getTokenPositionByRegex(String sentence, XmlUtil xml, Map<Point ,Object> positionToEntity, String changedSentence){
		PatternUtil pu = new PatternUtil();
		LinkedHashMap<String ,String> keyWordToRegex = pu.toRegex(xml.conceptMap);
		//String changedSentence = new String(sentence);
		//Map<Point ,Object> positionToEntity = new HashMap<Point ,Object>();
		//Set<Point> matchedPos = new HashSet<Point>();
	//	long getKeyWordPosStartTime = System.currentTimeMillis();
		boolean flag = false;
		for (Map.Entry<String, String> entry :keyWordToRegex.entrySet()) {   
			  // System.out.println("Key = " + entry.getKey() + ", Value = " + entry.getValue()); 
			   Pattern r = Pattern.compile(entry.getValue().toLowerCase());
			   Matcher m = r.matcher(sentence.toLowerCase());
			   //Matcher change = r.matcher(sentence);
			   int count = 0 ;	   
			   int matchLength = 0;
			   int start = 0;
			   int end = 0;
			   while(m.find()) {
				   	flag = true;
			         count++;
			         start = m.start();
			         end = m.end();
			         if(end <= sentence.length()){
			        	 if(end > 0 && sentence.charAt(end-1)==' '){
				        	 end = end - 1;
				         }
				         matchLength = end - start;
				        // System.out.println(sentence.substring(start,end)+" "+start+" "+end); //gt
				         Point currentMatchPos = new Point(start,end);
				         List<Point> jiaoChaPoints = selectJiaochaPoint(currentMatchPos , positionToEntity.keySet()); //和当前点有交叉的区域
				         
				         if(jiaoChaPoints.isEmpty()){
				        	 positionToEntity.put(currentMatchPos, entry.getKey());
				        	
				         }else if(!jiaoChaPoints.isEmpty() ){
				        	 boolean addEntityFlag = true;
				        	 for(Point jiaoChaPoint: jiaoChaPoints){
				        		// System.out.println("jiaochapoints: "+sentence.substring(jiaoChaPoint.x, jiaoChaPoint.y)+" x:"+jiaoChaPoint.x+" y:"+jiaoChaPoint.y);//gt
				        		 
				        		 // System.out.println("x:"+jiaoChaPoint.x);
				        		// System.out.println("y:"+jiaoChaPoint.y);
				        		 if(matchLength >= (jiaoChaPoint.y- jiaoChaPoint.x)){
				        			// System.out.println("matchLength:"+matchLength);
				        			 positionToEntity.remove(jiaoChaPoint);
				        		 }else {
				        			 addEntityFlag = false;
								}
				        	
				        	 }
				        	
				        	 if(addEntityFlag)
				        	 positionToEntity.put(currentMatchPos, entry.getKey());
				         }
			         }
			        
			   
			      }
				
				
			}
		//	long getKeyWordPosOrderStartTime = System.currentTimeMillis();
			positionToEntity = MapUtil.getOrder(positionToEntity);
		//	long getKeyWordPosOrderEndTime = System.currentTimeMillis();
		//	System.out.println("getKeyWordPosOrderStartTime:"+ (getKeyWordPosOrderEndTime - getKeyWordPosOrderStartTime));
			/*for(Point point: positionToEntity.keySet()){
				System.out.println("point: "+sentence.substring(point.x, point.y)+" x:"+point.x+" y:"+point.y);//gt	
			}*/
			
	//		long getKeyWordPosEndTime = System.currentTimeMillis();
		//	System.out.println("getKeyWordPosTime:"+ (getKeyWordPosEndTime - getKeyWordPosStartTime));
			
			
			return (LinkedHashMap<Point, Object>) positionToEntity;
	}
	
	
	private static List<Point> selectJiaochaPoint(Point currentPosPoint, Set<Point> keySet) {
		// TODO Auto-generated method stub
		List<Point> jiaoChaPoints = new ArrayList<Point>();
			for(Point p : keySet){
				if(p.x < currentPosPoint.x && currentPosPoint.x < p.y 
						|| p.x < currentPosPoint.y && currentPosPoint.y < p.y 
						||p.x >= currentPosPoint.x && currentPosPoint.y >= p.y 
					//	||p.x >= currentPosPoint.x && currentPosPoint.y <= p.y 
						)
					//return p;
					jiaoChaPoints.add(p);
				
			}
		return jiaoChaPoints;
	}
	
	
	public static String getKeyWordValue(String inputSentence, String keyWord, LinkedHashMap<String, Object> keyToInfo){
		String resultString = "";
		int indexOfKeyWord = inputSentence.indexOf(keyWord);
		if(indexOfKeyWord >= 0 ){
			String keyWordWithNumString = inputSentence.substring(indexOfKeyWord, indexOfKeyWord+keyWord.length()+2).trim();
			if(keyToInfo.containsKey(keyWordWithNumString))
			resultString = keyToInfo.get(keyWordWithNumString).toString();
			
		}
		
		
		return resultString;
	}
	
	public static String keyWordReplace(String inputSentence, String keyWord, LinkedHashMap<String, Object> keyToInfo) {
		//String resultString = "";
		String[] inputTokens = inputSentence.split("\\s+");
		for(String input : inputTokens){
			input = input.trim();
			if(input.contains(keyWord) && keyToInfo.containsKey(input)){
				inputSentence = inputSentence.replaceAll(input, keyToInfo.get(input).toString());
			}
		}
		
		return inputSentence;
	}

}
