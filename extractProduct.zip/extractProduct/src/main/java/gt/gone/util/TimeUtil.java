package gt.gone.util;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

 public class TimeUtil {
	
	 //抽取时间，如果没有月，日。以00代替
	public static String extractTimePoint(String input) {
		// TODO Auto-generated method stub
		if(extractTimeType(input) == 1){
			Pattern pattern=Pattern.compile("\\d+(,\\d+)*\\.?\\d*");
			Pattern pattern2=Pattern.compile("\\d+(,\\d+)*\\.?\\d*" + " " + "\\d+(,\\d+)*\\.?\\d*");
			Pattern pattern3=Pattern.compile("(\\d{0,2}\\.){1,2}\\d{2,4}");
			Matcher matcher = pattern.matcher(input);
			Matcher matcher2 = pattern2.matcher(input);
			Matcher matcher3 = pattern3.matcher(input);
			String year = "2017";
			String month = "00";
			String day = "00";
			if(matcher3.find()){
			//	System.out.println(input);
			//	System.out.println("time ==>"+ matcher3.group(0));
				return matcher3.group(0);
			}else if(matcher2.find() ){
				String monthAndYear = matcher2.group(0);
				if(monthAndYear.contains(" ")){
					year = monthAndYear.substring(0,monthAndYear.indexOf(" "));
					month = monthAndYear.substring(monthAndYear.indexOf(" "));
				}
				//year = matcher.group(0);
				//month = matcher.group(1);
			}else if(matcher.find() ){
				year= matcher.group(0);
			}
			if(input.toLowerCase().contains("last year")){
				year = String.valueOf((Integer.valueOf(year)-1));
			}
			return year+"."+month+"."+day;
		}
		
		return null;
	//	return null;
	}
	//如果没有指定文本生成的时间则默认为当前时间
	public static String extractTimePeriodEnd(String oldChar) {
		// TODO Auto-generated method stub
		if(!isTimeFuzzy(oldChar) && !isTimePoint(oldChar)){
			Date now = new Date();
			 SimpleDateFormat ft = new SimpleDateFormat ("yyyy.MM.dd");
			 String ndate = ft.format(now);
			 return extractTimePeriodEnd(oldChar,ndate);
		}
		return null;
		 //int year = Integer.valueOf(ft.format(now));
		
	}
	//String now的格式必须为yyyy.MM.dd
	public static String extractTimePeriodEnd(String oldChar,String now) {
		// TODO Auto-generated method stub
		String[] times = now.split(".");
		if(!isTimeFuzzy(oldChar) && !isTimePoint(oldChar)){
			if(extractTimeType(oldChar) == 2){
				if(oldChar.contains("-")){
					return oldChar.substring(oldChar.indexOf("-")+"-".length()).trim();
				}else if(oldChar.contains(" to ")){
					return oldChar.substring(oldChar.indexOf(" to ")+" to ".length()).trim();
				}else if(oldChar.contains("in the next")){
					int num = Integer.valueOf(extractNum(oldChar));
					if(times.length > 0&& times[0]!=null && !times[0].isEmpty()){
						String yearEnd = String.valueOf(num + Integer.valueOf(times[0]));
						return now.replace(times[0], yearEnd);
					}
					
				}else if(oldChar.contains("before the end of")||oldChar.contains("by the end of")){
					int num = Integer.valueOf(extractNum(oldChar));
					if(times.length>0 &&times[0]!=null && !times[0].isEmpty()){
						String yearEnd = String.valueOf(num > Integer.valueOf(times[0])?num:Integer.valueOf(times[0]));
						return now.replace(times[0], yearEnd);
					}
					
				}else if(oldChar.contains("/")){
					return oldChar.substring(oldChar.indexOf("/")+"/".length()).trim();
				}
				return now;
			}
		}
		
		return null;
	}
	
	//如果没有指定文本生成的时间则默认为当前时间
		public static String extractTimePeriodStart(String oldChar) {
			// TODO Auto-generated method stub
			if(!isTimeFuzzy(oldChar) && !isTimePoint(oldChar)){
				Date now = new Date();
				 SimpleDateFormat ft = new SimpleDateFormat ("yyyy.MM.dd");
				 String ndate = ft.format(now);
				 //int year = Integer.valueOf(ft.format(now));
				return extractTimePeriodStart(oldChar,ndate);
			}
			return null;
		}
	//now 参数表示文本出现的时间，如果没有默认是现在
	public static String extractTimePeriodStart(String oldChar,String now) {
		// TODO Auto-generated method stub
		//System.out.println("时间"+now);
		String[] times = now.split("\\.");
		//System.out.println("times length"+times.length);
		if(!isTimeFuzzy(oldChar) && !isTimePoint(oldChar)){
			if(extractTimeType(oldChar)==2){
				
				if(oldChar.contains("-")){
					return oldChar.substring(0, oldChar.indexOf("-"));
				}else if(oldChar.contains(" to ")){
					if(oldChar.contains("years")){
						return oldChar.substring(oldChar.indexOf("years")+"years".length(), oldChar.indexOf(" to ")).trim();
					}else {
						return oldChar.substring(0, oldChar.indexOf(" to ")).trim();
					}
					
				}
				else if(oldChar.contains("over the past")||
						oldChar.contains("for the last")||oldChar.contains("over the last")||oldChar.contains("in past")){
					//System.out.println("past past");
					if(extractNum(oldChar)!=null &&isNumeric(oldChar)){
					int num = Integer.valueOf(extractNum(oldChar));
					if(times.length > 0 &&times[0]!=null && !times[0].isEmpty()){
						String yearStart = String.valueOf(Integer.valueOf(times[0])-num);
						//System.out.println(yearStart);
						return now.replace(times[0], yearStart);
					}
					}
				}else if(oldChar.contains("before the end of")||oldChar.contains("by the end of")||oldChar.contains("by")||oldChar.contains("Since")){
					if(extractNum(oldChar)!=null && !extractNum(oldChar).isEmpty()&&isNumeric(oldChar)){
						int num = Integer.valueOf(extractNum(oldChar));
						if(times[0]!=null && !times[0].isEmpty()){
							String yearStart = String.valueOf(num < Integer.valueOf(times[0])?num:Integer.valueOf(times[0]));
							return now.replace(times[0], yearStart);
						}
					}
					
					
				}else if(oldChar.contains("/")){
					return oldChar.substring(0, oldChar.indexOf("/"));
				}
				return now;
			}
		}
		
		return null;
	}
	
	public static boolean isNumeric(String str){
		  for (int i = 0; i < str.length(); i++){
		   //System.out.println(str.charAt(i));
		   if (!Character.isDigit(str.charAt(i))){
		    return false;
		   }
		  }
		  return true;
		 }
	
	//1表示时间点 2表示时间段 3表示模糊时间
	public static int extractTimeType(String oldChar) {
		// TODO Auto-generated method stub
		oldChar = oldChar.toLowerCase();
		String[] timePeriodKeyWord={"over the past","over the last"
				,"by","Since","over the last","over last"
				,"for the last","before the end of","by the end of "
				,"in the next","in past","throughout the year","-", " to ","end","y/e","/","in the past","over the past"};
		String[] mohuKeyWords = {"recent","months","a few","in such for the last","over"};
		for(String periodWord: timePeriodKeyWord){
			if(oldChar.toLowerCase().contains(periodWord)){
				return 2;
			}
		}
		
		for(String mohuWord: mohuKeyWords){
			if(oldChar.contains(mohuWord)){
				return 3;
			}
		}
			return 1;
	}
	
	//需要改进
	public static String extractTimeTense(String oldChar) {
		// TODO Auto-generated method stub
		if(oldChar.contains("in")&&!oldChar.contains("past")||oldChar.contains("next")){
			return "FUTURE";
		}else if(oldChar.contains("past")||oldChar.contains("last")
				||oldChar.contains("by")||oldChar.contains("before")||oldChar.contains("Since")){
			return "PAST";
		}
		return "NOW";
	}
	public static String extractTimeUnit(String oldChar) {
		// TODO Auto-generated method stub
		if(oldChar.contains("week")){
			return "WEEK";
		}else if(oldChar.toLowerCase().contains("month")){
			return "MONTH";
		}
		return "YEAR";
	}
	public static String extractNum(String input){
		Pattern pattern=Pattern.compile("\\d+(,\\d+)*\\.?\\d*");
		Matcher matcher = pattern.matcher(input);
		if(matcher.find()){
			return matcher.group(0);
		}
		return null;
	}
	
	public static Boolean isTimePoint(String oldChar) {
		oldChar = oldChar.toLowerCase();
		if(oldChar.contains("over the")
				||oldChar.contains("by")
				||oldChar.toLowerCase().contains("since")
				||oldChar.contains("in such for the last")
				||oldChar.contains("the end of")
				||oldChar.contains("in the next")
				||oldChar.contains("in past")
				||oldChar.contains("by")
				||oldChar.contains("throughout")
				||oldChar.contains("to")
				||oldChar.contains("several")
				||oldChar.contains("end")
				||oldChar.contains("y/e")
				||oldChar.contains("/")
				||oldChar.contains("months")
				||oldChar.contains("a few")
				||oldChar.contains("over")
				||oldChar.contains("the previous"))
			return false;
		return true;
	}
	public static Boolean isTimeFuzzy(String oldChar) {
		oldChar = oldChar.toLowerCase();
		if(oldChar.contains("recent")
				||oldChar.contains("over the")
				||oldChar.toLowerCase().contains("since")
				||oldChar.contains("in such for the last")
				||oldChar.contains("the end of")
				||oldChar.contains("in the next")
				||oldChar.contains("in past")
				||oldChar.contains("throughout")
				||oldChar.contains("by year end")
				||oldChar.contains("end")
				||oldChar.contains("y/e")
				||oldChar.contains("ye ")
				||oldChar.contains("year on year")
				||oldChar.contains("a few")
				||oldChar.contains("current")
				||oldChar.contains("in ") && oldChar.contains("years")
				)
			return true;
		return false;
	}

}
